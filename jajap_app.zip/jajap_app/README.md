# JAJAP Ecosystem — 2 Apps + Database

Versi ini mempertahankan User App, Admin Panel, dan database `jajap_db` dari build sebelumnya, dengan perbaikan pada pengelolaan produk Admin.

## Perbaikan produk Admin
- Nama tempat kuliner/toko pada form produk sekarang berupa **input teks**, bukan dropdown merchant.
- Kolom kedua tetap menjadi pilihan **jenis produk**: Kuliner atau Sembako.
- Saat Admin memasukkan nama tempat yang belum ada, sistem otomatis membuat merchant dengan nama tersebut dan menghubungkan produk ke merchant itu.
- Saat nama tempat yang sama sudah ada, produk menggunakan merchant yang sudah ada.
- Saat mengedit produk, nama tempat tetap bisa diketik/diubah.
- Dengan demikian Admin dapat memisahkan produk berdasarkan jenis layanan tanpa memaksa semua tempat bernama "Dapur JAJAP" atau memilih merchant yang salah.

## Database
Gunakan satu database bersama: `jajap_db`.
`database.sql` adalah installer database bersih. `migration_send_pricing.sql` hanya diperlukan bila memasang perubahan tarif JAJAPSend pada database lama.

-- Migrasi JAJAPSend untuk database jajap_db yang sudah ada.
-- Tidak menghapus tabel atau data lama.
USE jajap_db;
INSERT IGNORE INTO system_settings (setting_key, setting_value, description)
VALUES ('send_per_km','10000','Tarif JAJAPSend per KM yang ditentukan Admin');

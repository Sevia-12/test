# JAJAP Admin Panel
Portal admin terpisah dari aplikasi pengguna.

Fitur: autentikasi admin, pengaturan tarif/komisi, CMS merchant dan produk, driver aktif/blokir, banner promo, legal, dan monitoring order.

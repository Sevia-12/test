-- JAJAP ECOSYSTEM - DATABASE BARU SIAP PAKAI
-- PERINGATAN: skrip ini MENGHAPUS jajap_db yang sudah ada. Backup dahulu jika masih dibutuhkan.
-- Gunakan SATU database saja: jajap_db
-- Import file ini satu kali pada database baru.
-- Akun login baru: admin=admin/admin123, user=user/user123, driver=driver/driver123.

DROP DATABASE IF EXISTS jajap_db;
CREATE DATABASE jajap_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jajap_db;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,phone VARCHAR(20) NOT NULL UNIQUE,email VARCHAR(150) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,
 role ENUM('customer','driver','admin') NOT NULL DEFAULT 'customer',is_driver_active TINYINT(1) NOT NULL DEFAULT 0,is_blocked TINYINT(1) NOT NULL DEFAULT 0,
 vehicle_type ENUM('bike','car') DEFAULT NULL,vehicle_plate VARCHAR(30) DEFAULT NULL,legal_consent_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_users_role(role),INDEX idx_users_driver_active(is_driver_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_users (
 id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(80) NOT NULL UNIQUE,email VARCHAR(150) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,last_login_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS system_settings (
 setting_key VARCHAR(80) PRIMARY KEY,setting_value VARCHAR(255) NOT NULL DEFAULT '',description VARCHAR(255),updated_by INT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(updated_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS legal_info (
 id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(160) NOT NULL,content LONGTEXT NOT NULL,version VARCHAR(30) NOT NULL DEFAULT '1.0',is_active TINYINT(1) NOT NULL DEFAULT 1,updated_by INT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(updated_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS merchants (
 id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,address VARCHAR(255),phone VARCHAR(30),image_url VARCHAR(500),active TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY,merchant_id INT NOT NULL,name VARCHAR(120) NOT NULL,description TEXT,price DECIMAL(12,2) NOT NULL DEFAULT 0,icon VARCHAR(20) DEFAULT '🍲',image_url VARCHAR(500),type ENUM('food','mart') NOT NULL DEFAULT 'food',active TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(merchant_id) REFERENCES merchants(id) ON DELETE CASCADE,INDEX idx_products_type(type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS banners (
 id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(160) NOT NULL,body TEXT,image_url VARCHAR(500),link_url VARCHAR(500),active TINYINT(1) NOT NULL DEFAULT 1,sort_order INT NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 driver_id INT NULL,
 order_type ENUM('bike','car','food','mart','send') NOT NULL,
 pickup_address TEXT,
 dropoff_address TEXT,
 distance_km DECIMAL(10,3) NOT NULL DEFAULT 0,
 pickup_lat DECIMAL(10,7) DEFAULT NULL,
 pickup_lng DECIMAL(10,7) DEFAULT NULL,
 dropoff_lat DECIMAL(10,7) DEFAULT NULL,
 dropoff_lng DECIMAL(10,7) DEFAULT NULL,
 total_price DECIMAL(12,2) NOT NULL DEFAULT 0,
 product_subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
 delivery_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
 driver_earning DECIMAL(12,2) NOT NULL DEFAULT 0,
 driver_share_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
 platform_earning DECIMAL(12,2) NOT NULL DEFAULT 0,
 status ENUM('pending','accepted','delivering','completed','cancelled') NOT NULL DEFAULT 'pending',
 payment_method VARCHAR(30) DEFAULT 'QRIS',
 payment_provider VARCHAR(40) DEFAULT NULL,
 payment_status ENUM('pending','paid','failed','synced') NOT NULL DEFAULT 'pending',
 payment_reference VARCHAR(100),
 payment_expires_at DATETIME DEFAULT NULL,
 assigned_at DATETIME NULL,
 completed_at DATETIME NULL,
 last_status_at DATETIME NULL,
 dispatch_attempts INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE RESTRICT,
 FOREIGN KEY(driver_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_orders_user(user_id), INDEX idx_orders_status(status), INDEX idx_orders_driver(driver_id), INDEX idx_orders_type(order_type), INDEX idx_orders_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,product_id INT NULL,product_name VARCHAR(120) NOT NULL,variant VARCHAR(120),notes TEXT,qty INT NOT NULL DEFAULT 1,unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
 FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS driver_applications (
 id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,phone VARCHAR(20) NOT NULL,email VARCHAR(150),password VARCHAR(255) NOT NULL,vehicle_type ENUM('bike','car') NOT NULL DEFAULT 'bike',vehicle_plate VARCHAR(30),status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS merchant_applications (
 id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,phone VARCHAR(20) NOT NULL,address VARCHAR(255),category VARCHAR(80) DEFAULT 'Kuliner',status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS payment_sync_logs (
 id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,action VARCHAR(40) NOT NULL DEFAULT 'sync',reference_code VARCHAR(100),synced_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(order_id),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(synced_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS reviews_driver (
 id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,user_id INT NOT NULL,driver_id INT NOT NULL,rating TINYINT NOT NULL,review TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_driver_review(order_id,user_id),CHECK(rating BETWEEN 1 AND 5),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(driver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS reviews_merchant (
 id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,user_id INT NOT NULL,merchant_id INT NOT NULL,rating TINYINT NOT NULL,review TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_merchant_review(order_id,user_id),CHECK(rating BETWEEN 1 AND 5),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(merchant_id) REFERENCES merchants(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO system_settings(setting_key,setting_value,description) VALUES
('base_delivery_fee',8000,'Ongkos kirim dasar'),('bike_per_km',2500,'Tarif JAJAPBike per KM'),('car_per_km',4500,'Tarif JAJAPCar per KM'),('merchant_commission_percent',10,'Komisi JAJAPKuliner dalam persen'),('service_bike_name','JAJAPBike','Nama layanan transportasi motor'),('service_car_name','JAJAPCar','Nama layanan transportasi mobil'),('service_food_name','Kuliner','Nama layanan makanan'),('service_mart_name','Sembako','Nama layanan belanja'),('service_send_name','JAJAPSend','Nama layanan kurir/pengantaran'),('send_delivery_fee','10000','Legacy ongkir JAJAPSend'),('send_per_km','10000','Tarif JAJAPSend per KM yang ditentukan Admin'),('send_driver_share_percent','50','Persentase total ongkir JAJAPSend untuk driver yang ditentukan Admin')
ON DUPLICATE KEY UPDATE description=VALUES(description);

INSERT INTO legal_info(title,content,version,is_active) VALUES
('Syarat & Ketentuan','Gunakan layanan JAJAP secara bertanggung jawab. Informasi akun dan pesanan harus benar.','1.0',1),
('Kebijakan Privasi','JAJAP memproses data yang diperlukan untuk akun, pesanan, keamanan, pembayaran, dan peningkatan layanan.','1.0',1);

INSERT INTO merchants(id,name,address,active) VALUES (1,'Dapur JAJAP','Kuningan City Center',1),(2,'JAJAP Mart Central','Jl. Siliwangi Kuningan',1) ON DUPLICATE KEY UPDATE name=VALUES(name),address=VALUES(address);
INSERT INTO products(id,merchant_id,name,description,price,icon,type,active) VALUES
(101,1,'Ayam Geprek Sambal','Nasi, ayam crispy, sambal',18000,'🍗','food',1),(102,1,'Nasi Goreng Spesial','Telur, ayam, sayuran',20000,'🍚','food',1),(103,1,'Mie Ayam Bakso','Mie ayam + bakso',17000,'🍜','food',1),(201,2,'Beras 5 Kg','Beras premium 5 kg',72000,'🍚','mart',1),(202,2,'Susu UHT 1L','Susu UHT 1 liter',19000,'🥛','mart',1),(203,2,'Air Mineral','Air mineral kemasan',8000,'💧','mart',1)
ON DUPLICATE KEY UPDATE name=VALUES(name),price=VALUES(price),active=VALUES(active);
INSERT INTO admin_users(username,email,password_hash,is_active) VALUES
('admin','admin@jajap.app','$2y$12$Nsxp8vSXfUQG5bwd42kFNutVWzxP2mjxVIVed1LWGUKU388RSVK/6',1)
ON DUPLICATE KEY UPDATE email=VALUES(email);

INSERT INTO users(id,name,phone,email,password,role,is_driver_active,vehicle_type,vehicle_plate) VALUES
(1,'Admin JAJAP','admin','admin@jajap.local','$2y$12$Nsxp8vSXfUQG5bwd42kFNutVWzxP2mjxVIVed1LWGUKU388RSVK/6','admin',0,NULL,NULL),
(2,'Pengguna JAJAP','user','user@jajap.local','$2y$12$KP.qLxDmS8DRO3mLzl64n.YKY9G4ajc2uy6c7xzadpN9zHswBRl5O','customer',0,NULL,NULL),
(3,'Driver JAJAP 1','driver','driver@jajap.local','$2y$12$tCBH6Y9s.3fcUKGTsvkGge3C0ikC3L2Oqm2jIH9JWI4vSNokNCS4i','driver',1,'bike','B 1234 JJP')
ON DUPLICATE KEY UPDATE name=VALUES(name),password=VALUES(password),role=VALUES(role),is_driver_active=VALUES(is_driver_active);

-- JAJAP PLATFORM UPGRADE: realtime dispatch, tracking, payment ledger, notifications, safety
CREATE TABLE IF NOT EXISTS driver_locations (driver_id INT PRIMARY KEY,latitude DECIMAL(10,7) NOT NULL,longitude DECIMAL(10,7) NOT NULL,accuracy DECIMAL(8,2) DEFAULT NULL,heading DECIMAL(7,2) DEFAULT NULL,speed DECIMAL(8,2) DEFAULT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,FOREIGN KEY(driver_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS notifications (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,order_id INT NULL,type VARCHAR(40) NOT NULL DEFAULT 'general',title VARCHAR(160) NOT NULL,body TEXT NOT NULL,read_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_notifications_user(user_id,read_at,created_at),INDEX idx_notifications_order(order_id),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS payment_transactions (id BIGINT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,provider VARCHAR(40) NOT NULL DEFAULT 'sandbox',method VARCHAR(30) NOT NULL,reference_code VARCHAR(120) NOT NULL UNIQUE,amount DECIMAL(12,2) NOT NULL DEFAULT 0,status ENUM('pending','paid','failed','refunded','expired') NOT NULL DEFAULT 'pending',expires_at DATETIME NULL,paid_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX idx_payment_order(order_id),INDEX idx_payment_status(status),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS safety_incidents (id BIGINT AUTO_INCREMENT PRIMARY KEY,order_id INT NULL,user_id INT NOT NULL,driver_id INT NULL,type ENUM('sos','incident','share_trip','support') NOT NULL DEFAULT 'incident',message TEXT,status ENUM('open','acknowledged','resolved') NOT NULL DEFAULT 'open',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_safety_order(order_id),INDEX idx_safety_user(user_id),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(driver_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

<?php
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Strict']);
session_start();
header('X-Frame-Options: DENY'); header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: no-referrer');
if (!function_exists('e')) { function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');} }
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function csrf_ok($v){return is_string($v)&&isset($_SESSION['csrf'])&&hash_equals($_SESSION['csrf'],$v);}
function admin_required(){if(empty($_SESSION['admin'])){header('Location:login.php');exit;}}

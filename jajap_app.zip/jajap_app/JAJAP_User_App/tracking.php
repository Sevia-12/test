<?php
require_once __DIR__.'/config/database.php'; require_once __DIR__.'/config/platform.php'; require_customer();
$orderId=(int)($_GET['order_id']??0); $st=$pdo->prepare("SELECT o.*,d.name driver_name,d.vehicle_type,d.vehicle_plate FROM orders o LEFT JOIN users d ON d.id=o.driver_id WHERE o.id=? AND o.user_id=?");$st->execute([$orderId,$_SESSION['user']['id']]);$order=$st->fetch();if(!$order){http_response_code(404);exit('Order tidak ditemukan.');}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pelacakan — JAJAP</title><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><link rel="stylesheet" href="app-frame.css"><style>:root{--bg:#f4f6f5;--card:#fff;--ink:#1c2520;--muted:#6f7d76;--line:#e2ece7;--green:#00a86b}body{margin:0;background:#d0d8d4;color:var(--ink);font-family:system-ui}.mobileContainer{max-width:100%;height:100vh;margin:auto;background:var(--bg);display:flex;flex-direction:column}.head{padding:14px 16px;background:var(--card);border-bottom:1px solid var(--line);display:flex;gap:12px;align-items:center}.head a{font-size:22px;text-decoration:none;color:var(--ink)}.body{padding:12px;overflow:auto}.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:13px;margin-bottom:10px}.status{color:var(--green);font-weight:900}.map{height:390px;border-radius:16px;overflow:hidden;border:1px solid var(--line)}.muted{font-size:11px;color:var(--muted)}body.dark-mode{--bg:#121816;--card:#1e2623;--ink:#e8ecea;--muted:#a0b2aa;--line:#2d3834}body.dark-mode .mobileContainer{background:var(--bg)}</style><link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head><body><div class="app-container"><div class="mobileContainer"><header class="head"><a href="aktivitas.php">‹</a><b>📍 Lacak Pesanan #<?=$orderId?></b></header><main class="body"><section class="card"><div class="status" id="status"><?=htmlspecialchars(strtoupper($order['status']))?></div><div id="driver" style="margin-top:5px;font-weight:800"><?=htmlspecialchars($order['driver_name']?:'Mencari driver...')?></div><div class="muted" id="updated">Memuat lokasi realtime…</div></section><div id="map" class="map"></div><section class="card"><div>📍 <?=htmlspecialchars($order['pickup_address']?:'Lokasi jemput')?></div><div style="margin-top:7px">🎯 <?=htmlspecialchars($order['dropoff_address']?:'Lokasi tujuan')?></div></section><a href="safety.php?order_id=<?=$orderId?>" style="display:block;text-align:center;background:#b4232f;color:#fff;padding:13px;border-radius:12px;text-decoration:none;font-weight:900">🛡️ Pusat Keamanan</a></main></div><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>const map=L.map('map').setView([-6.8794,108.5098],13);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);let marker=null;async function refresh(){try{const r=await fetch('api.php?action=tracking&order_id=<?=$orderId?>',{credentials:'same-origin'});const j=await r.json();if(!j.ok)return;const o=j.order;document.getElementById('status').textContent=(o.status||'').toUpperCase();document.getElementById('driver').textContent=o.driver_name?('👨‍✈️ '+o.driver_name+' • '+(o.vehicle_type||'')+' '+(o.vehicle_plate||'')):'Mencari driver...';if(o.updated_at)document.getElementById('updated').textContent='Lokasi terakhir: '+o.updated_at;if(o.latitude&&o.longitude){const p=[+o.latitude,+o.longitude];if(!marker)marker=L.marker(p).addTo(map);marker.setLatLng(p);map.setView(p,15);}}catch(e){}}refresh();setInterval(refresh,3000);if(localStorage.getItem('jajap_theme')==='dark')document.body.classList.add('dark-mode');</script></div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body></html>

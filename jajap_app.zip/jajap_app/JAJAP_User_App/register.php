<?php
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/security.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=trim($_POST['name']??''); $phone=trim($_POST['phone']??''); $password=(string)($_POST['password']??'');
    $consent=!empty($_POST['legal_consent']);
    if(!$consent) $error='Anda harus menyetujui Syarat & Ketentuan dan Kebijakan Privasi.';
    elseif($name===''||$phone===''||strlen($password)<8) $error='Isi semua data dan gunakan kata sandi minimal 8 karakter.';
    elseif(!preg_match('/^[0-9+\- ]{8,20}$/',$phone)) $error='Format nomor HP tidak valid.';
    elseif(!($pdo instanceof PDO)) $error='Database belum tersedia.';
    else try{
        $email=strtolower(preg_replace('/[^a-z0-9]+/i','.', $name)).'@jajap.local';
        $hash=password_hash($password,PASSWORD_DEFAULT);
        $st=$pdo->prepare("INSERT INTO users(name,phone,email,password,role,legal_consent_at) VALUES(?,?,?,?, 'customer', NOW())");
        $st->execute([$name,$phone,$email,$hash]);
        $id=(int)$pdo->lastInsertId();
        $st=$pdo->prepare('SELECT * FROM users WHERE id=?'); $st->execute([$id]);
        $_SESSION['user']=$st->fetch(PDO::FETCH_ASSOC); unset($_SESSION['guest'],$_SESSION['cart']);
        header('Location:index.php'); exit;
    }catch(Throwable $e){ $error='Nomor HP atau email sudah digunakan.'; }
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Daftar — JAJAP</title><style>
*{box-sizing:border-box}html,body{margin:0;background:#d0d8d4;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#1c2520}.mobileContainer{width:min(414px,100vw);min-height:100vh;margin:auto;background:#f4f6f5;padding:28px 20px;display:flex;flex-direction:column;justify-content:center;box-shadow:0 0 40px #0002}.logo{width:56px;height:56px;border-radius:16px;background:#00a86b;color:#fff;display:grid;place-items:center;font-weight:900;margin:0 auto 16px}.title{text-align:center;font-size:20px;font-weight:900}.sub{text-align:center;color:#6f7d76;font-size:11px;margin:6px 0 20px}.field{margin:0 0 12px}.field label{display:block;font-size:11px;font-weight:800;margin-bottom:5px}.field input{width:100%;padding:12px;border:1px solid #dce7e2;border-radius:12px}.legal{font-size:10px;line-height:1.5;color:#65736d;margin:8px 0}.legal a{color:#08794f;font-weight:800}.btn{width:100%;padding:13px;border:0;border-radius:13px;background:#00a86b;color:white;font-weight:900}.backLink{display:block;margin:20px 0 18px;padding:13px 16px;min-height:48px;font-size:1rem;font-weight:600;line-height:1.3;text-align:center;text-decoration:none;color:#08794f;background:#fff;border:1px solid #dce7e2;border-radius:12px}.err{background:#ffebe8;color:#c93443;border-radius:12px;padding:10px;font-size:11px;margin-bottom:12px}</style><link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head><body><div class="app-container"><main class="mobileContainer"><div class="logo">J</div><div class="title">Buat Akun JAJAP</div><div class="sub">Daftar untuk menggunakan layanan JAJAP</div><?php if($error):?><div class="err"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="field"><label>Nama</label><input name="name" required></div><div class="field"><label>Nomor HP</label><input name="phone" inputmode="tel" required></div><div class="field"><label>Kata Sandi</label><input name="password" type="password" minlength="8" required></div><label class="legal"><input type="checkbox" name="legal_consent" value="1" required> Saya telah membaca dan menyetujui <a href="legal.php">[Syarat &amp; Ketentuan]</a> serta <a href="legal.php">[Kebijakan Privasi]</a>.</label><button class="btn">Daftar / Register</button></form><a href="welcome.php" class="backLink">← Kembali ke Halaman Awal</a></main></div></body></html>

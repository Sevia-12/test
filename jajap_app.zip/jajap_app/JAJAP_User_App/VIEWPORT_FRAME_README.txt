JAJAP APP FRAME

The application uses one centered phone-style frame on phones, tablets, and desktop.
The frame is approximately 414px wide and up to 970px high, with visible page background around it.
It must NOT be changed back to width:100vw / height:100dvh for normal pages.
Only the map overlay fills the app frame; it does not cover the browser viewport outside the frame.

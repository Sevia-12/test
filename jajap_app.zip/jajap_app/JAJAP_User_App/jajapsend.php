<?php
require_once __DIR__.'/config/services.php';
session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/security.php';
require_once __DIR__.'/config/pricing.php';
if (!isset($_SESSION['user'])) { header('Location: welcome.php'); exit; }
if (($_SESSION['user']['role'] ?? '') === 'admin') { header('Location: welcome.php?admin=separate'); exit; }
$service = jajap_service_name('send', $pdo instanceof PDO ? $pdo : null);
$settings = jajap_settings($pdo instanceof PDO ? $pdo : null);
$sendPerKm = max(0, (float)$settings['send_per_km']);
$share = min(100, max(0, (float)$settings['send_driver_share_percent']));
$initial = jajap_send_pricing($pdo, 0, 'Kecil');
$fee = $initial['delivery_fee'];
$banners = [];
if ($pdo instanceof PDO) {
    try {
        $st = $pdo->query("SELECT title,body,image_url FROM banners WHERE active=1 ORDER BY sort_order ASC,id DESC LIMIT 5");
        $banners = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {}
}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title><?=e($service)?> — JAJAP</title>
<link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
:root{--green:#00a86b;--green-dark:#08794f;--green-soft:#e9f8f1;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#fff;--line:#e2ece7;--orange:#f57c00}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;width:100%;height:100%;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;overflow:hidden}
.mobileContainer{width:100%;max-width:100%;height:100dvh;margin:0 auto;background:var(--bg);position:relative;display:flex;flex-direction:column;overflow:hidden;border-radius:36px;border:1px solid #c2ceca;box-shadow:0 0 40px rgba(0,0,0,.2)}
.sendScroll{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding-bottom:82px;-webkit-overflow-scrolling:touch}
.header{height:54px;background:var(--card);display:flex;align-items:center;padding:0 15px;gap:10px;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:90}
.header a{text-decoration:none;color:var(--ink);font-size:24px;font-weight:900;line-height:1}.header h1{font-size:16px;margin:0;font-weight:900}
.hero{margin:0;background:linear-gradient(135deg,#08ad67,#08794f);color:#fff;min-height:138px;position:relative;overflow:hidden}
.heroSlide{display:none;height:138px;padding:22px 20px;position:relative}.heroSlide.active{display:flex;align-items:flex-end}
.heroSlide h2{margin:0 0 5px;font-size:24px;font-weight:950;position:relative;z-index:2}.heroSlide p{margin:0;font-size:11px;opacity:.92;max-width:235px;position:relative;z-index:2}
.heroVisual{position:absolute;right:12px;bottom:10px;font-size:66px;opacity:.95;filter:drop-shadow(0 6px 4px rgba(0,0,0,.14))}
.heroImage{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.heroShade{position:absolute;inset:0;background:linear-gradient(90deg,rgba(0,90,50,.7),rgba(0,90,50,.08))}
.dots{position:absolute;bottom:8px;left:0;right:0;display:flex;justify-content:center;gap:6px;z-index:5}.dot{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.65)}.dot.active{width:24px;border-radius:9px;background:#fff}
.locationCard{margin:14px 14px 10px;background:var(--card);border-radius:18px;border:1px solid var(--line);box-shadow:0 2px 8px rgba(0,0,0,.04);overflow:hidden}
.locationRows{position:relative}.locRow{display:flex;align-items:center;gap:10px;padding:12px 14px 12px 14px;padding-right:74px;border-bottom:1px dashed var(--line);min-height:58px;position:relative}.locRow:last-child{border-bottom:0}
.locIcon{width:25px;height:25px;border-radius:8px;display:grid;place-items:center;color:#fff;font-size:13px;font-weight:900;flex:none}.pickIcon{background:#9ca4a0}.dropIcon{background:var(--orange)}
.locBody{flex:1;min-width:0}.locLabel{font-size:10px;color:var(--muted);font-weight:700;margin-bottom:3px}.locInput{width:100%;border:0;outline:0;background:transparent;color:var(--ink);font-size:12px;padding:0}.locInput::placeholder{color:#a6aea9}
.mapBtn{border:0;background:var(--green-soft);color:var(--green-dark);font-size:10px;font-weight:900;padding:9px 9px;border-radius:10px;white-space:nowrap;min-width:58px;min-height:36px;cursor:pointer;position:relative;z-index:4;touch-action:manipulation}.mapBtn:active{transform:scale(.97)}
.swapStrip{height:32px;display:flex;align-items:center;justify-content:flex-end;padding:0 14px;background:var(--card);position:relative;z-index:7}.swapBtn{width:36px;height:30px;border-radius:15px;border:1px solid var(--line);background:#f2f4f3;color:var(--ink);font-size:17px;font-weight:900;box-shadow:0 2px 7px rgba(0,0,0,.12);cursor:pointer;touch-action:manipulation}.swapBtn:active{transform:scale(.94)}
.locationWrap{position:relative}.friendRow{background:#ddffdf;color:#176b39;font-size:10px;font-weight:800;padding:11px 14px;display:flex;justify-content:space-between;align-items:center}.friendRow button{border:0;background:transparent;color:#176b39;font-weight:900}
.searchResults{display:none;background:#fff;border-top:1px solid var(--line);max-height:150px;overflow:auto}.searchResults button{display:block;width:100%;text-align:left;border:0;background:#fff;padding:10px 12px;font-size:10px;border-bottom:1px solid var(--line);color:var(--ink)}
.section{margin:10px 14px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px}.sectionTitle{font-size:13px;font-weight:900;margin-bottom:11px}.sectionSub{font-size:10px;color:var(--muted);margin-top:-7px;margin-bottom:11px}
.packageGrid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.package{border:1px solid var(--line);border-radius:13px;background:#f8faf9;padding:11px 5px;text-align:center;cursor:pointer;min-height:92px;color:var(--ink);font:inherit;touch-action:manipulation;position:relative;z-index:2}.package:active{transform:scale(.98)}.package.active{border-color:var(--green);background:var(--green-soft);color:var(--green-dark);box-shadow:0 0 0 1px rgba(0,168,107,.15)}.packageIcon{font-size:25px;display:block;margin-bottom:4px}.package b{font-size:10px}.package small{display:block;font-size:8px;color:var(--muted);margin-top:2px}.package.active small{color:var(--green-dark)}
.note{width:100%;min-height:58px;resize:none;border:1px solid var(--line);border-radius:12px;padding:10px;background:#f8faf9;color:var(--ink);font-size:11px;outline:none;margin-top:10px}
.tariff{display:flex;align-items:center;justify-content:space-between;gap:10px;background:var(--green-soft);border:1px dashed #9bd9bd;border-radius:13px;padding:12px}.tariffLabel{font-size:10px;color:var(--muted)}.tariffValue{font-size:17px;color:var(--green-dark);font-weight:950}.driverInfo{font-size:9px;color:var(--muted);margin-top:5px}
.continue{position:sticky;bottom:0;margin:0 14px 12px;width:calc(100% - 28px);height:48px;border:0;border-radius:14px;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;font-size:13px;font-weight:950;box-shadow:0 5px 14px rgba(0,130,80,.2)}
.bottomNav{height:66px;background:rgba(255,255,255,.98);border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(4,1fr);z-index:110;flex:none}.navTab{border:0;background:transparent;color:var(--muted);font-size:9px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;text-decoration:none}.navTab.active{color:var(--green-dark)}
.mapOverlay{position:fixed;inset:0;background:#f4f6f5;z-index:5000;display:none;max-width:100%;margin:0 auto;touch-action:manipulation}.mapOverlay.active{display:block}.mapCanvas{position:absolute;inset:0}.mapTop{position:absolute;top:12px;left:12px;right:12px;z-index:5010;display:flex;gap:8px}.mapTop input{flex:1;border:1px solid #ddd;border-radius:13px;padding:12px;background:#fff;font-size:12px;box-shadow:0 3px 10px rgba(0,0,0,.12);outline:0}.mapTop button{border:0;border-radius:13px;padding:0 13px;background:#fff;font-weight:900;box-shadow:0 3px 10px rgba(0,0,0,.12)}.mapClose{position:absolute;top:66px;left:12px;z-index:5010;border:0;border-radius:12px;background:#fff;padding:9px 12px;font-weight:900;box-shadow:0 3px 10px rgba(0,0,0,.12)}.mapCenterPin{position:absolute;left:50%;top:50%;transform:translate(-50%,-100%);z-index:5010;font-size:43px;filter:drop-shadow(0 2px 2px rgba(0,0,0,.25));pointer-events:none}.mapBottom{position:absolute;left:12px;right:12px;bottom:14px;z-index:5010;background:#fff;border-radius:18px;padding:12px;box-shadow:0 4px 16px rgba(0,0,0,.15)}.mapBottomText{font-size:10px;color:var(--muted);margin-bottom:9px}.mapActions{display:grid;grid-template-columns:1fr 1.4fr;gap:8px}.mapActions button{height:42px;border:0;border-radius:12px;font-weight:900}.gps{background:#f0f4f2;color:var(--green-dark)}.confirm{background:var(--green);color:#fff}
body.dark-mode{--bg:#121816;--card:#1e2623;--ink:#e8ecea;--muted:#9aa8a1;--line:#2d3834;--green-soft:#183329}body.dark-mode .locInput,body.dark-mode .note{color:#fff}body.dark-mode .locInput::placeholder{color:#89958f}body.dark-mode .searchResults,body.dark-mode .searchResults button{background:var(--card);color:var(--ink)}body.dark-mode .bottomNav{background:rgba(30,38,35,.98)}
@media(min-width:601px){.mobileContainer{height:844px;margin:20px auto;border-radius:36px}}
</style>
<link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body><div class="app-container">
<div class="mobileContainer" id="app">
  <main class="sendScroll">
    <header class="header"><a href="index.php" aria-label="Kembali">‹</a><h1>📦 <?=e($service)?></h1></header>
    <section class="hero" id="hero">
      <?php if ($banners): foreach ($banners as $i=>$b): ?>
        <div class="heroSlide <?=$i===0?'active':''?>">
          <?php if (!empty($b['image_url'])): ?><img class="heroImage" src="<?=e($b['image_url'])?>" alt=""><span class="heroShade"></span><?php endif; ?>
          <div><h2><?=e($b['title'] ?: $service)?></h2><p><?=e($b['body'] ?: 'Kirim barang dengan mudah bersama JAJAP.')?></p></div>
          <?php if (empty($b['image_url'])): ?><div class="heroVisual">📦</div><?php endif; ?>
        </div>
      <?php endforeach; else: ?>
        <div class="heroSlide active"><div><h2>Kirim barang dengan mudah</h2><p>Masukkan lokasi pengirim dan penerima. Jarak dihitung otomatis dari lokasi yang kamu pilih.</p></div><div class="heroVisual">📦🛵</div></div>
      <?php endif; ?>
      <div class="dots" id="dots"><?php $count=max(1,count($banners)); for($i=0;$i<$count;$i++): ?><span class="dot <?=$i===0?'active':''?>"></span><?php endfor; ?></div>
    </section>

    <form id="sendForm" method="get" action="pesanan.php" onsubmit="return submitSend()">
      <input type="hidden" name="action" value="send">
      <input type="hidden" name="distance_km" id="distanceKm" value="0">
      <input type="hidden" name="package_type" id="packageType" value="Kecil">
      <input type="hidden" name="notes" id="notesHidden" value="">
      <section class="locationCard">
        <div class="locationRows">
          <div class="locRow"><span class="locIcon pickIcon">↑</span><div class="locBody"><div class="locLabel">Ambil paket dari mana?</div><input class="locInput" id="pickup" name="pick" placeholder="Cari alamat pengirim" autocomplete="off" required></div><button type="button" class="mapBtn" onclick="openMap('pickup')" aria-label="Pilih lokasi pengambilan lewat Maps">Maps</button></div>
          <div class="swapStrip"><button type="button" class="swapBtn" onclick="swapLocations()" aria-label="Tukar lokasi pengirim dan penerima" title="Tukar lokasi">↕</button></div>
          <div class="locRow"><span class="locIcon dropIcon">↓</span><div class="locBody"><div class="locLabel">Kirim paket ke mana?</div><input class="locInput" id="dropoff" name="drop" placeholder="Cari alamat penerima" autocomplete="off" required></div><button type="button" class="mapBtn" onclick="openMap('dropoff')" aria-label="Pilih lokasi penerima lewat Maps">Maps</button></div>
        </div>
        <div class="searchResults" id="pickupResults"></div><div class="searchResults" id="dropoffResults"></div>
        <div class="friendRow"><span>📍 Pakai lokasi saya untuk titik pengambilan</span><button type="button" onclick="useGPSForPickup()">Pakai</button></div>
      </section>

      <section class="section"><div class="sectionTitle">Pilih layanan sesuai ukuran paket</div><div class="sectionSub">Pilih perkiraan ukuran barang. Tarif pengiriman mengikuti pengaturan Admin JAJAP.</div>
        <div class="packageGrid">
          <button type="button" class="package active" data-value="Kecil" onclick="choosePackage(this)" aria-pressed="true"><span class="packageIcon">📄</span><b>Kecil</b><small>Dokumen / kecil</small></button>
          <button type="button" class="package" data-value="Sedang" onclick="choosePackage(this)" aria-pressed="false"><span class="packageIcon">📦</span><b>Sedang</b><small>Paket sedang</small></button>
          <button type="button" class="package" data-value="Besar" onclick="choosePackage(this)" aria-pressed="false"><span class="packageIcon">🧰</span><b>Besar</b><small>Barang besar</small></button>
        </div>
        <textarea class="note" id="notes" maxlength="500" placeholder="Catatan paket, misalnya: barang mudah pecah, letakkan di bagian depan..." oninput="document.getElementById('notesHidden').value=this.value"></textarea>
      </section>

      <section class="section"><div class="sectionTitle">Ringkasan pengiriman</div><div class="tariff"><div><div class="tariffLabel" id="fareLabel">Tentukan kedua lokasi terlebih dahulu</div><div class="driverInfo" id="fareInfo">Tarif <?=number_format($sendPerKm,0,',','.')?>/KM • Kecil +Rp 1.000 • Sedang +Rp 2.000 • Besar +Rp 3.000 • Driver <?=number_format($share,2,',','.')?>%</div></div><div class="tariffValue" id="fareValue">Rp 0</div></div></section>
      <button class="continue" id="continueBtn" type="submit">Tentukan lokasi untuk melihat ongkir</button>
    </form>
  </main>
  <nav class="bottomNav"><a href="index.php" class="navTab"><i>⌂</i>Beranda</a><a href="pesanan.php" class="navTab"><i>🛒</i>Pesanan</a><a href="aktivitas.php" class="navTab"><i>◷</i>Aktivitas</a><a href="profil.php" class="navTab"><i>👤</i>Profil</a></nav>
</div>

<div class="mapOverlay" id="mapOverlay" aria-hidden="true"><div id="mapCanvas" class="mapCanvas"></div><div class="mapTop"><input id="mapSearch" type="search" placeholder="Cari alamat atau tempat..."><button type="button" onclick="searchMap()">Cari</button></div><button type="button" class="mapClose" onclick="closeMap()">‹ Kembali</button><div class="mapCenterPin">📍</div><div class="mapBottom"><div class="mapBottomText" id="mapLabel">Geser peta sampai pin berada di lokasi yang dipilih.</div><div class="mapActions"><button type="button" class="gps" onclick="useGPS()">⌖ Lokasi saya</button><button type="button" class="confirm" onclick="confirmMapLocation()">Konfirmasi lokasi</button></div></div></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
let map=null,activeField='pickup',pick=null,drop=null,slide=0;
const bannerCount=<?=count($banners)?>;
const sendPerKm=<?=json_encode($sendPerKm)?>;
const packageFees={Kecil:1000,Sedang:2000,Besar:3000};
function calculateSendFee(distanceKm,packageType){const km=Math.max(0,Number(distanceKm)||0);const billableKm=km>0?Math.ceil(km):0;const pkg=packageFees[packageType]||1000;return {billableKm,distanceFee:billableKm*sendPerKm,packageFee:billableKm>0?pkg:0,total:billableKm>0?(billableKm*sendPerKm+pkg):0};}
function refreshFare(distanceKm){const packageType=document.getElementById('packageType').value||'Kecil';const calc=calculateSendFee(distanceKm,packageType);document.getElementById('distanceKm').value=Number(distanceKm||0).toFixed(3);document.getElementById('fareLabel').textContent=calc.billableKm?('Jarak '+calc.billableKm+' KM × Rp '+Math.round(sendPerKm).toLocaleString('id-ID')+' + paket '+packageType+' Rp '+calc.packageFee.toLocaleString('id-ID')):'Tentukan kedua lokasi terlebih dahulu';document.getElementById('fareValue').textContent='Rp '+calc.total.toLocaleString('id-ID');document.getElementById('continueBtn').textContent=calc.total?'Lanjut ke Pesanan — Rp '+calc.total.toLocaleString('id-ID'):'Tentukan lokasi untuk melihat ongkir';return calc.total;}
function choosePackage(el){document.querySelectorAll('.package').forEach(x=>{x.classList.remove('active');x.setAttribute('aria-pressed','false')});el.classList.add('active');el.setAttribute('aria-pressed','true');document.getElementById('packageType').value=el.dataset.value;if(pick&&drop)refreshRouteFare();else refreshFare(0)}
async function swapLocations(){const p=document.getElementById('pickup'),d=document.getElementById('dropoff');const pv=p.value;p.value=d.value;d.value=pv;const tmp=pick;pick=drop;drop=tmp;if(pick&&drop)refreshRouteFare();else refreshFare(0);}
async function geocode(q){if(!q)return null;try{const u='https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q='+encodeURIComponent(q);const a=await fetch(u).then(r=>r.json());return a[0]?{lat:+a[0].lat,lng:+a[0].lon,name:a[0].display_name}:null}catch(e){return null}}
async function reverse(lat,lng){try{const a=await fetch('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='+lat+'&lon='+lng).then(r=>r.json());return a.display_name||('Titik '+lat.toFixed(5)+', '+lng.toFixed(5))}catch(e){return 'Titik '+lat.toFixed(5)+', '+lng.toFixed(5)}}
function haversine(a,b){if(!a||!b)return 0;const R=6371,rad=Math.PI/180,dLat=(b.lat-a.lat)*rad,dLon=(b.lng-a.lng)*rad;const x=Math.sin(dLat/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(x))}
async function routeDistance(a,b){if(!a||!b)return 0;try{const u='https://router.project-osrm.org/route/v1/driving/'+a.lng+','+a.lat+';'+b.lng+','+b.lat+'?overview=false&alternatives=false';const r=await fetch(u);if(!r.ok)throw new Error('route');const j=await r.json();if(j.routes&&j.routes[0]&&Number(j.routes[0].distance)>0)return j.routes[0].distance/1000}catch(e){}return haversine(a,b)}
async function refreshRouteFare(){if(!pick||!drop){refreshFare(0);return 0}document.getElementById('fareLabel').textContent='Menghitung jarak perjalanan...';const km=await routeDistance(pick,drop);refreshFare(km);return km}
async function resolveLocations(){if(!pick)pick=await geocode(document.getElementById('pickup').value);if(!drop)drop=await geocode(document.getElementById('dropoff').value);const km=await refreshRouteFare();return km}
async function submitSend(){if(!document.getElementById('pickup').value.trim()||!document.getElementById('dropoff').value.trim()){alert('Isi lokasi pengirim dan penerima terlebih dahulu.');return false}const km=await resolveLocations();if(km<=0){alert('Pilih lokasi pengirim dan penerima melalui Maps atau hasil pencarian agar jarak dapat dihitung.');return false}return true}
function openMap(field){activeField=field;const ov=document.getElementById('mapOverlay');ov.classList.add('active');ov.setAttribute('aria-hidden','false');setTimeout(()=>{if(!map){map=L.map('mapCanvas',{zoomControl:true}).setView(field==='pickup'&&pick?[pick.lat,pick.lng]:field==='dropoff'&&drop?[drop.lat,drop.lng]:[-6.9175,107.6191],15);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);map.on('moveend',updateMapLabel)}else{map.invalidateSize(true);const c=field==='pickup'&&pick?pick:field==='dropoff'&&drop?drop:null;if(c)map.setView([c.lat,c.lng],16,{animate:false});}updateMapLabel()},60)}
function closeMap(){document.getElementById('mapOverlay').classList.remove('active');document.getElementById('mapOverlay').setAttribute('aria-hidden','true')}
function updateMapLabel(){if(!map)return;const c=map.getCenter();document.getElementById('mapLabel').textContent=(activeField==='pickup'?'Pengambilan: ':'Penerima: ')+c.lat.toFixed(5)+', '+c.lng.toFixed(5)}
async function confirmMapLocation(){if(!map)return;const c=map.getCenter(),name=await reverse(c.lat,c.lng);const val={lat:c.lat,lng:c.lng};if(activeField==='pickup'){pick=val;document.getElementById('pickup').value=name}else{drop=val;document.getElementById('dropoff').value=name}refreshRouteFare();closeMap()}
async function searchMap(){const q=document.getElementById('mapSearch').value.trim();if(!q)return;const r=await geocode(q);if(r&&map)map.setView([r.lat,r.lng],16,{animate:true});else document.getElementById('mapLabel').textContent='Lokasi tidak ditemukan.'}
function useGPS(){if(!navigator.geolocation)return alert('GPS tidak tersedia di perangkat ini.');navigator.geolocation.getCurrentPosition(async p=>{const c={lat:p.coords.latitude,lng:p.coords.longitude},name=await reverse(c.lat,c.lng);if(activeField==='pickup'){pick=c;document.getElementById('pickup').value=name}else{drop=c;document.getElementById('dropoff').value=name}refreshRouteFare();if(map)map.setView([c.lat,c.lng],17);updateMapLabel()},()=>alert('Izin lokasi belum diberikan.'))}
function useGPSForPickup(){activeField='pickup';useGPS()}
function searchField(field){const input=document.getElementById(field),box=document.getElementById(field+'Results'),q=input.value.trim();if(!q)return;geocodeMany(q,field,box)}
async function geocodeMany(q,field,box){try{const a=await fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=4&q='+encodeURIComponent(q)).then(r=>r.json());box.innerHTML='';a.forEach(x=>{const b=document.createElement('button');b.type='button';b.textContent=x.display_name;b.onclick=()=>{document.getElementById(field).value=x.display_name;const point={lat:+x.lat,lng:+x.lon};if(field==='pickup'){pick=point}else{drop=point}box.style.display='none';if(pick&&drop)refreshRouteFare();else refreshFare(0)};box.appendChild(b)});box.style.display=a.length?'block':'none'}catch(e){box.style.display='none'}}
['pickup','dropoff'].forEach(f=>{document.getElementById(f).addEventListener('change',()=>searchField(f));document.getElementById(f).addEventListener('blur',()=>setTimeout(async()=>{document.getElementById(f+'Results').style.display='none';const q=document.getElementById(f).value.trim();if(q){const r=await geocode(q);if(r){if(f==='pickup')pick={lat:r.lat,lng:r.lng};else drop={lat:r.lat,lng:r.lng};if(pick&&drop)refreshRouteFare();else refreshFare(0);}}},250));});
refreshFare(0);
if(bannerCount>1){setInterval(()=>{const slides=document.querySelectorAll('.heroSlide'),dots=document.querySelectorAll('.dot');if(!slides.length)return;slides[slide]?.classList.remove('active');dots[slide]?.classList.remove('active');slide=(slide+1)%slides.length;slides[slide]?.classList.add('active');dots[slide]?.classList.add('active')},3500)}
(function(){if(localStorage.getItem('jajap_theme')==='dark')document.body.classList.add('dark-mode')})();
</script>
</div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body></html>

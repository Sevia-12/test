<?php
require_once __DIR__.'/config/services.php';
session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/pricing.php';
require_once __DIR__.'/config/platform.php';

$user = $_SESSION['user'] ?? ['id' => 0, 'name' => 'Tamu / Guest', 'role' => 'guest'];
$isGuest = (isset($_SESSION['guest']) && $_SESSION['guest']) || ($user['role'] === 'guest');

// Handle Action Clear Cart
if (isset($_GET['action']) && $_GET['action'] === 'clear') {
    unset($_SESSION['cart']);
    header('Location: pesanan.php');
    exit;
}

// Handle Action Delete Specific Item
if (isset($_GET['action']) && $_GET['action'] === 'remove' && isset($_GET['index'])) {
    $idx = (int)$_GET['index'];
    if (isset($_SESSION['cart'][$idx])) {
        array_splice($_SESSION['cart'], $idx, 1);
    }
    header('Location: pesanan.php');
    exit;
}

// Handle Ride Order Injection from Index
if (isset($_GET['action']) && $_GET['action'] === 'send') {
    $pick = trim($_GET['pick'] ?? 'Lokasi Pengirim');
    $drop = trim($_GET['drop'] ?? 'Lokasi Penerima');
    $distanceKm = max(0, (float)($_GET['distance_km'] ?? 0));
    $packageType = trim((string)($_GET['package_type'] ?? 'Kecil'));
    if (!in_array($packageType, ['Kecil','Sedang','Besar'], true)) $packageType = 'Kecil';
    $sendNotes = trim((string)($_GET['notes'] ?? ''));
    $send = jajap_send_pricing($pdo, $distanceKm, $packageType);
    $_SESSION['cart'] = [[
        'id' => 998,
        'name' => '📦 '.jajap_service_name('send', $pdo instanceof PDO ? $pdo : null),
        'price' => $send['delivery_fee'], 'qty' => 1,
        'variant' => "Dari: $pick | Ke: $drop | Jarak: {$distanceKm} KM | Paket: $packageType | Ongkir: Rp {$send['delivery_fee']}",
        'notes' => $sendNotes, 'type' => 'Send', 'transport_type' => 'send'
    ]];
    header('Location: pesanan.php'); exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'ride') {
    $type = ($_GET['type'] ?? 'bike') === 'car' ? 'car' : 'bike';
    $pick = trim($_GET['pick'] ?? 'Lokasi Jemput');
    $drop = trim($_GET['drop'] ?? 'Lokasi Tujuan');
    $distanceKm = max(0, (float)($_GET['distance_km'] ?? 0));
    $fare = jajap_transport_fare($pdo, $type, $distanceKm);

    $_SESSION['cart'] = [[
        'id' => 999,
        'name' => ($type === 'bike') ? '🛵 '.jajap_service_name('bike',$pdo instanceof PDO ? $pdo : null) : '🚗 '.jajap_service_name('car',$pdo instanceof PDO ? $pdo : null),
        'price' => $fare,
        'qty' => 1,
        'variant' => "Dari: $pick | Ke: $drop | Jarak: {$distanceKm} KM",
        'notes' => '',
        'type' => 'Transport'
    ]];
    header('Location: pesanan.php');
    exit;
}

$cart = $_SESSION['cart'] ?? [];

$paymentSuccess = false;
$paymentError = '';
$paymentMethod = 'QRIS';
$deliveryFee = jajap_setting('base_delivery_fee');
$driverEarning = $deliveryFee; // default untuk pengantaran barang; tarif transport dihitung terpisah.

// Handle Payment Simulation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_payment'])) {
    if (!$isGuest) {
        $paymentMethod = $_POST['payment_method'] ?? 'QRIS';
        $selectedIndices = $_POST['selected_items'] ?? [];
        
        if ($cart && !empty($selectedIndices)) {
            $selectedIndices = array_map('intval', $selectedIndices);
            try {
                if (!($pdo instanceof PDO)) {
                    throw new RuntimeException('Koneksi database tidak tersedia.');
                }

                // Simpan order sungguhan ke database + acak driver yang sedang aktif.
                $pdo->beginTransaction();
                $feeApplied = false;
                foreach ($selectedIndices as $idx) {
                    if (!isset($_SESSION['cart'][$idx])) continue;
                    $item = $_SESSION['cart'][$idx];
                    $qty = max(1, (int)($item['qty'] ?? 1));
                    $typeRaw = strtolower((string)($item['type'] ?? 'food'));
                    $orderType = $typeRaw === 'send' ? 'send' : ($typeRaw === 'transport' ? (($item['transport_type'] ?? 'bike') === 'car' ? 'car' : 'bike') : (($item['catalog_type'] ?? '') === 'mart' ? 'mart' : 'food'));
                    $productSubtotal = (float)($item['price'] ?? 0) * $qty;
                    $isSend = ($orderType === 'send');
                    $itemDistance = 0.0;
                    if (preg_match('/Jarak:\s*([0-9.]+)\s*KM/i', (string)($item['variant'] ?? ''), $dm)) $itemDistance = max(0, (float)$dm[1]);
                    $isTransport = ($orderType === 'bike' || $orderType === 'car');
                    if ($isTransport) {
                        $item['price'] = jajap_transport_fare($pdo, $orderType, $itemDistance);
                        $productSubtotal = $item['price'] * $qty;
                    }
                    // Transport memakai tarif perjalanan sebagai total. JAJAPSend memakai
                    // ongkir Admin sebagai delivery_fee agar tidak terhitung dua kali.
                    $sendPackageType = 'Kecil';
                    if ($isSend && preg_match('/Paket:\s*(Kecil|Sedang|Besar)/i', (string)($item['variant'] ?? ''), $pm)) $sendPackageType = ucfirst(strtolower($pm[1]));
                    $sendPricing = $isSend ? jajap_send_pricing($pdo, $itemDistance, $sendPackageType) : null;
                    if ($isSend) {
                        $productSubtotal = 0.0;
                    }
                    $itemDeliveryFee = $isTransport ? 0.0 : ($feeApplied ? 0.0 : ($isSend ? $sendPricing['delivery_fee'] : $deliveryFee));
                    $itemDriverEarning = $isTransport ? $productSubtotal : ($feeApplied ? 0.0 : ($isSend ? $sendPricing['driver_earning'] : min($driverEarning, $itemDeliveryFee)));
                    $driverSharePercent = $isSend ? $sendPricing['driver_share_percent'] : ($itemDeliveryFee > 0 ? min(100, ($itemDriverEarning / $itemDeliveryFee) * 100) : 0);
                    $total = $productSubtotal + $itemDeliveryFee;
                    $feeApplied = true;
                    $pick = ''; $drop = '';
                    if ($orderType === 'bike' || $orderType === 'car' || $orderType === 'send') {
                        $variant = (string)($item['variant'] ?? '');
                        if (preg_match('/Dari:\s*(.*?)\s*\|\s*Ke:\s*(.*?)\s*(?:\|\s*Jarak:.*)?$/i', $variant, $m)) { $pick=$m[1]; $drop=$m[2]; }
                    }

                    // Dispatch engine: pilih driver berdasarkan beban order, jenis kendaraan, lalu lokasi bila tersedia.
                    $driverId = jajap_assign_driver($pdo, $orderType);
                    $status = $driverId ? 'accepted' : 'pending';
                    $assignedAt = $driverId ? date('Y-m-d H:i:s') : null;
                    $stmtOrder = $pdo->prepare("INSERT INTO orders (user_id,driver_id,order_type,pickup_address,dropoff_address,distance_km,total_price,product_subtotal,delivery_fee,driver_earning,driver_share_percent,platform_earning,status,payment_method,payment_provider,payment_status,payment_reference,assigned_at,last_status_at,dispatch_attempts) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'sandbox','pending',NULL,?,?,?)");
                    $platformEarning = $isSend ? max(0, $total - $itemDriverEarning) : 0.0;
                    $stmtOrder->execute([$user['id'],$driverId,$orderType,$pick,$drop,$itemDistance,$total,$productSubtotal,$itemDeliveryFee,$itemDriverEarning,$driverSharePercent,$platformEarning,$status,$paymentMethod,$assignedAt,date('Y-m-d H:i:s'),$driverId ? 1 : 0]);
                    $orderId=(int)$pdo->lastInsertId();
                    // Payment ledger adapter. Saat ini provider sandbox menjaga perilaku lama tanpa mengklaim gateway eksternal.
                    $reference=jajap_create_payment($pdo,$orderId,$paymentMethod,$total);
                    $orderRow=['id'=>$orderId,'user_id'=>(int)$user['id']];
                    jajap_order_status_notify($pdo,$orderRow,$status);
                    if($driverId){ jajap_platform_notify($pdo,$driverId,'driver_order','Order baru masuk','Anda mendapat order baru. Buka dashboard driver untuk melihat detail.', $orderId); }
                }
                $pdo->commit();

                rsort($selectedIndices);
                foreach ($selectedIndices as $idx) {
                    if (isset($_SESSION['cart'][$idx])) array_splice($_SESSION['cart'], $idx, 1);
                }
                $_SESSION['last_payment_reference'] = $reference;
                $paymentSuccess = true;
            } catch (Throwable $e) {
                if ($pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
                $paymentError = 'Pembayaran belum dapat diselesaikan. Silakan coba lagi.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>JAJAP — Keranjang & Pembayaran</title>
<style>
:root{--green:#00a86b;--green-dark:#08794f;--green-soft:#e9f8f1;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#ffffff;--line:#e2ece7}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}

.mobileContainer{width:100%;max-width:100%;min-height:100vh;margin:20px auto;background:var(--bg);position:relative;padding-bottom:88px;box-shadow:0 0 40px rgba(0,0,0,.2);overflow:hidden;border-radius:28px;border:1px solid #c2ceca}

.pageHeader{background:var(--card);padding:14px 16px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between}
.pageHeader h1{font-size:15px;margin:0;font-weight:900}
.backBtn{text-decoration:none;color:var(--ink);font-size:18px;font-weight:900}

.content{padding:14px}
.cartCard{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px;margin-bottom:14px;box-shadow:0 2px 8px rgba(0,0,0,.02)}

.cartItemRow{padding:12px 0;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px}
.cartItemRow:last-child{border-bottom:0}
.cartCheck{width:18px;height:18px;accent-color:var(--green);cursor:pointer}
.cartItemDetails{flex:1}
.btnRemoveItem{color:#ef4f5f;background:none;border:0;font-size:14px;cursor:pointer;padding:4px}

.payMethodGroup{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:10px 0}
.payRadio{border:1px solid var(--line);background:#f8faf9;border-radius:12px;padding:10px 6px;text-align:center;font-size:11px;font-weight:800;cursor:pointer}
.payRadio input{display:none}
.payRadio.active{border-color:var(--green);background:var(--green-soft);color:var(--green-dark)}

.summaryRow{display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px;color:var(--muted)}
.summaryTotal{display:flex;justify-content:space-between;font-size:14px;font-weight:900;color:var(--ink);border-top:1px dashed var(--line);padding-top:10px;margin-top:8px}

.btnPay{width:100%;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;border:0;padding:14px;border-radius:14px;font-weight:900;font-size:13px;cursor:pointer;margin-top:14px;box-shadow:0 6px 16px rgba(0,168,107,.2)}
.btnPay:disabled{background:#b2c8be;box-shadow:none;cursor:not-allowed}

/* POPUP MODAL (PAYMENT / GUEST LOGIN PROMPT) */
.payModal{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.6);z-index:2000;display:none;place-items:center;padding:20px;box-sizing:border-box}
.payModal.active{display:grid}
.payBox{background:var(--card);width:100%;max-width:360px;border-radius:24px;padding:24px;text-align:center;box-shadow:0 10px 30px rgba(0,0,0,.2)}

.bottomNav{position:absolute;bottom:0;left:0;width:100%;height:66px;background:rgba(255,255,255,.98);border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(4,1fr);z-index:110}
.navTab{border:0;background:transparent;color:var(--muted);font-size:9px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;text-decoration:none}
.navTab.active{color:var(--green-dark)}

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow-x: hidden;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh; /* Dynamic Viewport Height for mobile browsers */
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    overflow-y: auto; /* PERMOHONAN: BISA DI SCROLL DARI ATAS KE BAWAH / BAWAH KE ATAS */
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    box-sizing: border-box;
    padding-bottom: 90px; /* Space for fixed bottomNav */
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px; /* Standard iPhone / Android height on desktop view */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}


/* FIKSASI UKURAN HP & BOTTOM NAVIGATION MENETAP DI BAWAH */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden; /* Mencegah seluruh layar web di luar HP ikut ter-scroll */
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden; /* Area luar dikunci */
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 780px; /* Ukuran tinggi HP ideal agar tidak terlalu panjang */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

/* MENETAPKAN BOTTOM NAV DI BAWAH TIGHT & TIDAK IKUT SCROLL */
.bottomNav {
    position: relative !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 62px !important;
    min-height: 62px !important;
    background: rgba(255,255,255,0.98) !important;
    border-top: 1px solid var(--line, #e2ece7) !important;
    display: grid !important;
    grid-template-columns: repeat(4, 1fr) !important;
    z-index: 9999 !important;
    box-shadow: 0 -4px 12px rgba(0,0,0,0.05) !important;
    flex-shrink: 0 !important;
}

/* AREA KONTEN UTAMA YANG BISA DI-SCROLL BERADA DI ANTARA HEADER & BOTTOM NAV */
.scrollableMainContent {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 20px;
}


/* DARK MODE ENGINE GLOBAL */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #9aa8a1 !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}
body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}
body.dark-mode .bottomNav {
    background: rgba(30, 38, 35, 0.98) !important;
    border-top-color: var(--line) !important;
}
body.dark-mode .navTab {
    color: var(--muted) !important;
}
body.dark-mode .navTab.active {
    color: #00d084 !important;
}
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #fff !important;
    border-color: var(--line) !important;
}


/* ENHANCED DARK MODE & LAYOUT UNIFORMITY FIX */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden !important;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow: hidden !important;
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px !important; /* DISAMAKAN PERSIS DENGAN INDEX.PHP (844px) */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

.scrollableMainContent {
    flex: 1 !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch;
}

/* DARK MODE CONTRAST FIXES */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #a0b2aa !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}

body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}

body.dark-mode .welcomeText h2,
body.dark-mode .welcomeText p,
body.dark-mode .brandTitle,
body.dark-mode label,
body.dark-mode b,
body.dark-mode span,
body.dark-mode h1, body.dark-mode h2, body.dark-mode h3 {
    color: #e8ecea !important;
}

/* FIX KHUSUS TOMBOL MODE TAMU (.btnGuest) DI TEMA GELAP */
body.dark-mode .btnGuest {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

/* FIX KHUSUS BANNER MODE TAMU DI INDEX.PHP */
body.dark-mode .guestBanner {
    background: #2a2518 !important;
    border-color: #483d22 !important;
    color: #ffc107 !important;
}

/* FIX KHUSUS INPUT & SELECT DI TEMA GELAP */
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

body.dark-mode input::placeholder {
    color: #889890 !important;
}


/* ===== JAJAP CUSTOMER UNIFIED APP FRAME =====
   Satu sistem frame untuk seluruh halaman customer.
   Frame selalu setinggi viewport, konten panjang scroll di dalam frame,
   dan tidak ada aturan 780/844px yang dapat membuat frame terpotong.
*/
html, body {
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  overflow: hidden !important;
  background: #d0d8d4 !important;
}

.mobileContainer {
  width: 100% !important;
  max-width: 414px !important;
  height: 100dvh !important;
  min-height: 0 !important;
  margin: 0 auto !important;
  padding: 0 !important;
  box-sizing: border-box !important;
  position: relative !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  border-radius: 36px !important;
  border: 1px solid #c2ceca !important;
  box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
}

.scrollableMainContent {
  flex: 1 1 auto !important;
  min-height: 0 !important;
  width: 100% !important;
  max-width: 100% !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  -webkit-overflow-scrolling: touch !important;
  box-sizing: border-box !important;
}

/* Semua navigasi bawah berada di dalam frame dan terbagi rata. */
.bottomNav {
  flex: 0 0 auto !important;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  z-index: 9999 !important;
}

/* Desktop/tablet: tetap ada jarak luar seperti desain Profil. */
@media (min-width: 415px) {
  .mobileContainer {
    height: calc(100dvh - 40px) !important;
    min-height: 0 !important;
    margin: 20px auto !important;
    border-radius: 36px !important;
  }
}

/* Mobile: frame memenuhi tinggi viewport tanpa menjadi 780/844px. */
@media (max-width: 414px) {
  .mobileContainer {
    height: 100dvh !important;
    min-height: 0 !important;
    margin: 0 auto !important;
    border-radius: 36px !important;
  }
}


/* ===== JAJAP UNIVERSAL MOBILE VIEWPORT FRAME v3 ===== */
html, body {
  margin: 0 !important;
  width: 100% !important;
  min-height: 100% !important;
}
body {
  background: #d0d8d4 !important;
  overflow: hidden !important;
}
.mobileContainer {
  position: fixed !important;
  inset: 0 auto 0 50% !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  height: auto !important;
  min-height: 0 !important;
  margin: 0 !important;
  padding-bottom: 0 !important;
  box-sizing: border-box !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  -webkit-overflow-scrolling: touch !important;
  border-radius: 0 !important;
  border: 0 !important;
}
/* The app shell itself stays phone-sized on larger screens. */
@media (min-width: 415px) {
  .mobileContainer {
    width: 414px !important;
    max-width: 414px !important;
    border-radius: 28px !important;
    border: 1px solid #c2ceca !important;
    box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
  }
}
/* Bottom navigation belongs to the phone viewport, never to the page scroll. */
.mobileContainer > .bottomNav,
.bottomNav {
  position: fixed !important;
  left: 50% !important;
  right: auto !important;
  bottom: 0 !important;
  top: auto !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  margin: 0 !important;
  z-index: 9999 !important;
  flex-shrink: 0 !important;
}
@media (min-width: 415px) {
  .mobileContainer > .bottomNav,
  .bottomNav {
    width: 414px !important;
    max-width: 414px !important;
  }
}
/* Keep normal content clear of the fixed bottom navigation. */
.mobileContainer {
  scroll-padding-bottom: 72px !important;
}
/* Home/header card should not expose the shell background while scrolling. */
.appHeader {
  position: sticky !important;
  top: 0 !important;
  z-index: 200 !important;
  overflow: hidden !important;
}
/* When a map/full-screen view is open, hide customer navigation. */
.mobileContainer.map-open .bottomNav,
.mobileContainer:has(#mapView.map-open) .bottomNav,
body.map-open .bottomNav,
body.maps-open .bottomNav {
  display: none !important;
}


/* FINAL PHONE FULL-SCREEN FRAME FIX v4 */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#d0d8d4 !important;
}
.mobileContainer {
  position:fixed !important;
  inset:0 !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
}
.mobileContainer > .scrollableMainContent {
  width:100% !important;
  max-width:none !important;
  min-width:0 !important;
  box-sizing:border-box !important;
}
.mobileContainer > .bottomNav, .bottomNav {
  position:fixed !important;
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  top:auto !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  margin:0 !important;
  z-index:99999 !important;
}
/* On a computer/laptop, preserve the phone-like width and height instead of desktop layout. */
@media (min-width:415px) {
  .mobileContainer {
    position:fixed !important;
    top:50% !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translate(-50%,-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:844px !important;
    min-height:844px !important;
    border:1px solid #c2ceca !important;
    border-radius:36px !important;
    box-shadow:0 0 40px rgba(0,0,0,.20) !important;
  }
  .mobileContainer > .bottomNav, .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}
@media (max-width:414px) {
  .mobileContainer {
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    border-radius:0 !important;
  }
}

</style>
<style>
/* ===== JAJAP FINAL FULL-SCREEN APP FRAME v5 =====
   Phone: application fills the real viewport.
   Desktop/laptop: keep a phone-width application, but use the full available height.
   No fixed 780px/844px frame height and no half-height centered card. */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  min-height:100% !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow:hidden !important;
}

html { background:#d0d8d4 !important; }

body {
  width:100% !important;
  min-height:100dvh !important;
  background:#d0d8d4 !important;
}

.mobileContainer, .box {
  position:fixed !important;
  inset:0 !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding-bottom:0 !important;
  box-sizing:border-box !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
}

/* Keep the application phone-sized on larger computer/laptop screens. */
@media (min-width:415px) {
  .mobileContainer, .box {
    top:0 !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translateX(-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:100dvh !important;
    min-height:100dvh !important;
    margin:0 !important;
    border:0 !important;
    border-radius:0 !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer, .box {
    left:0 !important;
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    transform:none !important;
    border-radius:0 !important;
  }
}

/* Bottom navigation stays attached to the visible app viewport. */
.mobileContainer > .bottomNav,
.mobileContainer .bottomNav,
.box > .bottomNav,
.box .bottomNav {
  position:fixed !important;
  top:auto !important;
  bottom:0 !important;
  z-index:99999 !important;
}

@media (min-width:415px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:0 !important;
    right:0 !important;
    width:100vw !important;
    max-width:none !important;
    transform:none !important;
  }
}
</style>

<style>
/* JAJAP UNIVERSAL APP FRAME v6 - one frame for every page */
html,body{width:100%;min-width:0;height:100%;min-height:100%;margin:0;padding:0;box-sizing:border-box;overflow:hidden}
html{background:#d0d8d4}
body{background:#d0d8d4;min-height:100dvh}
.mobileContainer,.box{
  position:fixed !important;
  top:0 !important;left:0 !important;right:auto !important;bottom:auto !important;
  width:100vw !important;max-width:none !important;
  height:100dvh !important;min-height:100dvh !important;
  margin:0 !important;box-sizing:border-box !important;
  border-radius:0 !important;border:0 !important;box-shadow:none !important;
  overflow:hidden !important;
}
/* Main pages use a single internal scrolling region; the frame itself never becomes a short card. */
.mobileContainer > .scrollableMainContent,
.mobileContainer > .scroll,
.mobileContainer > main.content,
.box > .scrollableMainContent{
  flex:1 1 auto !important;min-height:0 !important;
  overflow-y:auto !important;overflow-x:hidden !important;
  -webkit-overflow-scrolling:touch !important;
}
/* Form/landing pages without a dedicated content scroller can scroll inside the frame. */
.mobileContainer:has(> .logoBox),
.mobileContainer:has(> .welcomeText),
.box{overflow-y:auto !important;overflow-x:hidden !important;-webkit-overflow-scrolling:touch !important}
/* Keep bottom navigation pinned to the bottom of the app frame. */
.mobileContainer > .bottomNav,.box > .bottomNav{
  flex-shrink:0 !important;z-index:110 !important;
}
/* Full-screen maps must own the whole app viewport; page navigation is hidden while maps are open by existing JS/classes. */
#fullMapOverlay{position:fixed !important;inset:0 !important;width:100vw !important;height:100dvh !important;max-width:none !important;max-height:none !important;margin:0 !important;z-index:5000 !important}
/* Phones/tablets: truly edge-to-edge. A breakpoint above 414 prevents narrow mobile browsers from showing side gutters. */
@media (max-width:600px){
  .mobileContainer,.box{width:100vw !important;max-width:none !important;left:0 !important;transform:none !important}
  html,body{background:var(--bg,#f4f6f5) !important}
}
/* Computer/laptop: retain the phone-width application, centered, but use the full browser viewport height. */
@media (min-width:601px){
  .mobileContainer,.box{
    left:50% !important;right:auto !important;transform:translateX(-50%) !important;
    width:414px !important;max-width:414px !important;
    height:100dvh !important;min-height:100dvh !important;
    border-radius:28px !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

</style>
  <link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body><div class="app-container">

<div class="mobileContainer">
    <div class="scrollableMainContent">
    <header class="pageHeader">
        <a href="index.php" class="backBtn">‹</a>
        <h1>🛒 Keranjang & Pembayaran</h1>
        <?php if($cart): ?><a href="pesanan.php?action=clear" style="font-size:11px;color:#d9383a;text-decoration:none;font-weight:800">Kosongkan All</a><?php endif; ?>
    </header>

    <main class="content">
        <?php if($paymentError): ?>
            <div class="cartCard" style="text-align:center;padding:18px 16px;border-color:#f0b4b8;background:#fff5f5">
                <div style="font-size:32px;margin-bottom:6px">⚠️</div>
                <b style="font-size:13px;color:#c53030;display:block">Pembayaran Belum Berhasil</b>
                <p style="font-size:11px;color:var(--muted);line-height:1.5;margin:6px 0 0"><?=htmlspecialchars($paymentError)?></p>
            </div>
        <?php endif; ?>
        <?php if($paymentSuccess): ?>
            <!-- SUKSES PEMBAYARAN -->
            <div class="cartCard" style="text-align:center;padding:30px 16px">
                <div style="font-size:48px;margin-bottom:10px">🎉</div>
                <b style="font-size:16px;color:var(--green-dark);display:block">Pembayaran Berhasil!</b>
                <p style="font-size:11px;color:var(--muted);line-height:1.5;margin:8px 0 16px">
                    Pesanan terpilih telah berhasil dibayar dan siap dikirimkan oleh Driver.
                </p>
                <a href="pesanan.php" class="btnPay" style="display:block;text-decoration:none">Kembali ke Keranjang ›</a>
            </div>
        <?php elseif(!$cart): ?>
            <!-- KERANJANG KOSONG -->
            <div class="cartCard" style="text-align:center;padding:40px 16px">
                <div style="font-size:40px;margin-bottom:8px">🛒</div>
                <b style="font-size:13px;display:block">Keranjang Masih Kosong</b>
                <p style="font-size:11px;color:var(--muted);margin:4px 0 16px">Pilih layanan transportasi, kuliner, atau sembako terlebih dahulu.</p>
                <a href="index.php" style="color:var(--green-dark);font-size:11px;font-weight:800;text-decoration:none">← Kembali ke Beranda</a>
            </div>
        <?php else: ?>
            <!-- ITEM DALAM KERANJANG -->
            <div class="cartCard">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                    <b style="font-size:12px;color:var(--green-dark)">Pilih Produk yang Ingin Dibeli:</b>
                    <label style="font-size:11px;color:var(--muted);font-weight:700;cursor:pointer">
                        <input type="checkbox" id="checkAll" onclick="toggleSelectAll(this)" checked> Pilih Semua
                    </label>
                </div>

                <?php foreach($cart as $idx => $item): ?>
                <div class="cartItemRow">
                    <input type="checkbox" class="cartCheck itemCheckbox" value="<?=$idx?>" data-price="<?=$item['price'] * $item['qty']?>" onchange="recalculateTotal()" checked>
                    <div class="cartItemDetails">
                        <b style="font-size:12px;display:block"><?=htmlspecialchars($item['name'])?></b>
                        <small style="font-size:10px;color:var(--muted)"><?=htmlspecialchars($item['variant'])?> (x<?=$item['qty']?>)</small>
                        <div style="font-size:11px;font-weight:800;color:var(--green-dark);margin-top:2px">
                            Rp <?=number_format($item['price'] * $item['qty'], 0, ',', '.')?>
                        </div>
                    </div>
                    <a href="pesanan.php?action=remove&index=<?=$idx?>" class="btnRemoveItem" onclick="return confirm('Hapus pesanan ini dari keranjang?')" title="Hapus pesanan">🗑️</a>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="cartCard">
                <b style="font-size:12px;display:block;margin-bottom:8px">💳 Pilih Payment Gateway Simulasi:</b>
                <div class="payMethodGroup">
                    <label class="payRadio active" id="lblQRIS" onclick="setPayMethod('QRIS')">
                        <input type="radio" name="pay_type" value="QRIS" checked>
                        📱 QRIS / GoPay
                    </label>
                    <label class="payRadio" id="lblVA" onclick="setPayMethod('VA Bank')">
                        <input type="radio" name="pay_type" value="VA Bank">
                        🏦 VA Bank
                    </label>
                    <label class="payRadio" id="lblCOD" onclick="setPayMethod('COD / Tunai')">
                        <input type="radio" name="pay_type" value="COD / Tunai">
                        💵 COD / Tunai
                    </label>
                </div>
            </div>

            <div class="cartCard">
                <div class="summaryRow"><span>Subtotal Produk Terpilih</span><span id="dispSubtotal">Rp 0</span></div>
                <div class="summaryRow"><span>Ongkos Kirim & Layanan</span><span id="dispOngkir">Rp <?=number_format($deliveryFee,0,',','.')?></span></div>
                <div class="summaryTotal"><span>Total Bayar</span><span style="color:var(--green-dark)" id="dispTotal">Rp 0</span></div>
            </div>

            <button class="btnPay" id="btnPayMain" onclick="handlePayButtonClick()">Konfirmasi & Bayar Terpilih</button>
        <?php endif; ?>
    </main>

    <!-- MODAL POPUP -->
    <div class="payModal" id="payModal">
        <div class="payBox">
            <?php if($isGuest): ?>
                <!-- POPUP WAJIB LOGIN JIKA MASUK DENGAN MODE TAMU -->
                <div style="font-size:48px;margin-bottom:8px">🔐</div>
                <b style="font-size:15px;color:var(--ink);display:block">Daftar / Masuk Akun Dahulu</b>
                <p style="font-size:11px;color:var(--muted);line-height:1.5;margin:8px 0 16px">
                    Anda sedang dalam <b>Mode Tamu</b>. Silakan masuk atau daftar akun baru terlebih dahulu untuk melanjutkan proses pembayaran dan pemesanan.
                </p>
                <a href="login.php" class="btnPay" style="display:block;text-decoration:none;margin-top:0">🔑 Masuk ke Akun Saya</a>
                <a href="register.php" class="btnPay" style="display:block;text-decoration:none;background:#fff;color:var(--green-dark);border:2px solid var(--green);margin-top:8px">📝 Daftar Akun Baru</a>
                <button type="button" onclick="closePaymentGateway()" style="background:none;border:0;color:var(--muted);font-size:11px;font-weight:700;margin-top:12px;cursor:pointer">Nanti Saja</button>
            <?php else: ?>
                <!-- POPUP SIMULASI PAYMENT GATEWAY UNTUK USER TERDAFTAR -->
                <b style="font-size:14px;display:block" id="payGatewayTitle">Simulasi Payment Gateway</b>
                <div style="font-size:11px;color:var(--muted);margin-top:4px">Tekan 'Simulasi Bayar Berhasil' untuk menyelesaikan pembayaran</div>

                <div style="width:140px;height:140px;margin:14px auto;background:#eee;border-radius:12px;display:grid;place-items:center;font-size:10px;border:2px dashed #ccc">
                    <div style="font-size:28px">🏁</div>
                    <b>QRIS SIMULASI</b>
                </div>

                <b style="font-size:16px;color:var(--green-dark);display:block;margin-bottom:14px" id="modalTotalDisp">Total: Rp 0</b>

                <form method="POST" id="payForm">
                    <input type="hidden" name="process_payment" value="1">
                    <input type="hidden" name="payment_method" id="selectedPayMethodInput" value="QRIS">
                    <div id="hiddenSelectedInputs"></div>
                    <button type="submit" class="btnPay" style="margin-top:0">Simulasi Bayar Berhasil ✅</button>
                </form>
                <button type="button" onclick="closePaymentGateway()" style="background:none;border:0;color:var(--muted);font-size:11px;font-weight:700;margin-top:10px;cursor:pointer">Batal</button>
            <?php endif; ?>
        </div>
    </div>

        </div>
    <nav class="bottomNav">
        <a href="index.php" class="navTab"><i>⌂</i>Beranda</a>
        <a href="pesanan.php" class="navTab active"><i>🛒</i>Pesanan</a>
        <a href="aktivitas.php" class="navTab"><i>◷</i>Aktivitas</a>
        <a href="profil.php" class="navTab"><i>👤</i>Profil</a>
    </nav>
</div>

<script>
const isGuestUser = <?= json_encode($isGuest) ?>;
let selectedMethod = 'QRIS';
let currentTotal = 0;

function recalculateTotal() {
    const checkboxes = document.querySelectorAll('.itemCheckbox');
    let subtotal = 0;
    let count = 0;

    checkboxes.forEach(cb => {
        if (cb.checked) {
            subtotal += parseFloat(cb.getAttribute('data-price'));
            count++;
        }
    });

    const ongkir = (count > 0) ? <?=json_encode($deliveryFee)?> : 0;
    currentTotal = subtotal + ongkir;

    document.getElementById('dispSubtotal').textContent = 'Rp ' + subtotal.toLocaleString('id-ID');
    document.getElementById('dispOngkir').textContent = 'Rp ' + ongkir.toLocaleString('id-ID');
    document.getElementById('dispTotal').textContent = 'Rp ' + currentTotal.toLocaleString('id-ID');
    
    const payBtn = document.getElementById('btnPayMain');
    if (count === 0) {
        payBtn.disabled = true;
        payBtn.textContent = 'Pilih Minimal 1 Produk';
    } else {
        payBtn.disabled = false;
        payBtn.textContent = 'Konfirmasi & Bayar Terpilih — Rp ' + currentTotal.toLocaleString('id-ID');
    }
}

function toggleSelectAll(master) {
    const checkboxes = document.querySelectorAll('.itemCheckbox');
    checkboxes.forEach(cb => cb.checked = master.checked);
    recalculateTotal();
}

function setPayMethod(method) {
    selectedMethod = method;
    document.querySelectorAll('.payRadio').forEach(el => el.classList.remove('active'));
    if(method === 'QRIS') document.getElementById('lblQRIS').classList.add('active');
    if(method === 'VA Bank') document.getElementById('lblVA').classList.add('active');
    if(method === 'COD / Tunai') document.getElementById('lblCOD').classList.add('active');
    document.getElementById('selectedPayMethodInput').value = method;
}

function handlePayButtonClick() {
    if (isGuestUser) {
        // TAMPILKAN POPUP LOG IN JIKA GUEST USER
        document.getElementById('payModal').classList.add('active');
    } else {
        openPaymentGateway();
    }
}

function openPaymentGateway() {
    const hiddenContainer = document.getElementById('hiddenSelectedInputs');
    hiddenContainer.innerHTML = '';

    const checkboxes = document.querySelectorAll('.itemCheckbox');
    checkboxes.forEach(cb => {
        if (cb.checked) {
            const inp = document.createElement('input');
            inp.type = 'hidden';
            inp.name = 'selected_items[]';
            inp.value = cb.value;
            hiddenContainer.appendChild(inp);
        }
    });

    document.getElementById('payGatewayTitle').textContent = 'Simulasi Gateway (' + selectedMethod + ')';
    document.getElementById('modalTotalDisp').textContent = 'Total: Rp ' + currentTotal.toLocaleString('id-ID');
    document.getElementById('payModal').classList.add('active');
}

function closePaymentGateway() {
    document.getElementById('payModal').classList.remove('active');
}

document.addEventListener('DOMContentLoaded', recalculateTotal);
</script>

<script>
(function(){
    const theme = localStorage.getItem('jajap_theme');
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
    }
})();
</script>

</div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body>
</html>

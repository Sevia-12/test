<?php
session_start();
require_once __DIR__.'/config/database.php';

if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = ['id' => 0, 'name' => 'Tamu / Guest', 'phone' => '-', 'role' => 'guest'];
}

$msg = '';
if (!isset($_SESSION['user_addresses'])) {
    $_SESSION['user_addresses'] = [
        ['label' => '🏠 Rumah', 'address' => 'Panawuan, Cigandamekar, Kuningan'],
        ['label' => '🏢 Kantor / Tempat Kerja', 'address' => 'Alun-Alun Cirebon, Kota Cirebon']
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_address'])) {
    $lbl = trim($_POST['label']);
    $addr = trim($_POST['address']);
    if ($lbl && $addr) {
        $_SESSION['user_addresses'][] = ['label' => $lbl, 'address' => $addr];
        $msg = '✅ Alamat baru berhasil disimpan!';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Alamat Tersimpan — JAJAP</title>
<style>
:root{--green:#00a86b;--green-dark:#08794f;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#ffffff;--line:#e2ece7}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;overflow:hidden}

.mobileContainer{width:100%;max-width:100%;height:100vh;height:100dvh;margin:0 auto;background:var(--bg);position:relative;box-shadow:0 0 40px rgba(0,0,0,.2);display:flex;flex-direction:column;justify-content:space-between;overflow:hidden;box-sizing:border-box}

@media (min-width: 415px) {
    .mobileContainer { height: 844px; margin: 20px auto; border-radius: 36px; border: 1px solid #c2ceca; }
}

.pageHeader{background:var(--card);padding:14px 16px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px;position:sticky;top:0;z-index:90}
.pageHeader h1{font-size:15px;margin:0;font-weight:900}
.backBtn{text-decoration:none;color:var(--ink);font-size:18px;font-weight:900}

.scrollableMainContent{flex:1;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;padding:14px}
.cardBox{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.02)}

.formGroup{margin-bottom:10px}
.formGroup label{font-size:10px;font-weight:800;color:var(--muted);display:block;margin-bottom:4px}
.formGroup input{width:100%;padding:10px;border:1px solid var(--line);border-radius:10px;font-size:11px;outline:none;background:#fff}

.btnSave{width:100%;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;border:0;padding:12px;border-radius:12px;font-weight:800;font-size:12px;cursor:pointer}

.bottomNav{position:relative !important;bottom:0 !important;left:0 !important;width:100% !important;height:62px !important;min-height:62px !important;background:rgba(255,255,255,0.98) !important;border-top:1px solid var(--line, #e2ece7) !important;display:grid !important;grid-template-columns:repeat(4, 1fr) !important;z-index:9999 !important;flex-shrink:0 !important}
.navTab{border:0;background:transparent;color:var(--muted);font-size:9px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;text-decoration:none}
.navTab.active{color:var(--green-dark)}


/* DARK MODE ENGINE GLOBAL */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #9aa8a1 !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}
body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}
body.dark-mode .bottomNav {
    background: rgba(30, 38, 35, 0.98) !important;
    border-top-color: var(--line) !important;
}
body.dark-mode .navTab {
    color: var(--muted) !important;
}
body.dark-mode .navTab.active {
    color: #00d084 !important;
}
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #fff !important;
    border-color: var(--line) !important;
}


/* LAYOUT SIZING UNIFORMITY FIX */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden !important;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow: hidden !important;
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 780px !important;
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

.scrollableMainContent {
    flex: 1 !important;
    overflow-y: auto !important;
    overflow-x: hidden !hidden;
    -webkit-overflow-scrolling: touch;
    padding: 14px;
}

.bottomNav {
    position: relative !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 62px !important;
    min-height: 62px !important;
    background: rgba(255,255,255,0.98) !important;
    border-top: 1px solid var(--line, #e2ece7) !important;
    display: grid !important;
    grid-template-columns: repeat(4, 1fr) !important;
    z-index: 9999 !important;
    flex-shrink: 0 !important;
}


/* ENHANCED DARK MODE & LAYOUT UNIFORMITY FIX */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden !important;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow: hidden !important;
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px !important; /* DISAMAKAN PERSIS DENGAN INDEX.PHP (844px) */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

.scrollableMainContent {
    flex: 1 !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch;
}

/* DARK MODE CONTRAST FIXES */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #a0b2aa !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}

body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}

body.dark-mode .welcomeText h2,
body.dark-mode .welcomeText p,
body.dark-mode .brandTitle,
body.dark-mode label,
body.dark-mode b,
body.dark-mode span,
body.dark-mode h1, body.dark-mode h2, body.dark-mode h3 {
    color: #e8ecea !important;
}

/* FIX KHUSUS TOMBOL MODE TAMU (.btnGuest) DI TEMA GELAP */
body.dark-mode .btnGuest {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

/* FIX KHUSUS BANNER MODE TAMU DI INDEX.PHP */
body.dark-mode .guestBanner {
    background: #2a2518 !important;
    border-color: #483d22 !important;
    color: #ffc107 !important;
}

/* FIX KHUSUS INPUT & SELECT DI TEMA GELAP */
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

body.dark-mode input::placeholder {
    color: #889890 !important;
}


/* FINAL UNIFORM PAGE SIZE FIX
   Menyamakan halaman Pengaturan Profil, Metode Pembayaran, dan Alamat Tersimpan
   dengan ukuran halaman utama/Profil. */
.mobileContainer{
    width:100% !important;
    max-width:414px !important;
    height:100vh !important;
    height:100dvh !important;
    margin:0 auto !important;
    padding:0 !important;
    display:flex !important;
    flex-direction:column !important;
    overflow:hidden !important;
    box-sizing:border-box !important;
}
.pageHeader{
    width:100% !important;
    flex:0 0 auto !important;
}
.scrollableMainContent{
    width:100% !important;
    flex:1 1 auto !important;
    min-height:0 !important;
    padding:14px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    box-sizing:border-box !important;
}
.cardBox{
    width:100% !important;
    box-sizing:border-box !important;
}
.bottomNav{
    width:100% !important;
    flex:0 0 62px !important;
    height:62px !important;
    min-height:62px !important;
    box-sizing:border-box !important;
}
@media (min-width:415px){
    .mobileContainer{
        height:844px !important;
        margin:20px auto !important;
        border-radius:36px !important;
        border:1px solid #c2ceca !important;
    }
}


/* EXACT BERANDA PAGE FRAME - FINAL */
html, body {
    width: 100% !important;
    min-width: 100% !important;
    height: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow-x: hidden !important;
}

.mobileContainer {
    width: 100% !important;
    max-width: 414px !important;
    height: 100vh !important;
    height: 100dvh !important;
    min-height: 100vh !important;
    min-height: 100dvh !important;
    margin: 0 auto !important;
    padding: 0 !important;
    position: relative !important;
    display: flex !important;
    flex-direction: column !important;
    box-sizing: border-box !important;
    overflow: hidden !important;
    border-radius: 0 !important;
    border: 0 !important;
}

.pageHeader {
    width: 100% !important;
    box-sizing: border-box !important;
}

.scrollableMainContent {
    width: 100% !important;
    height: calc(100% - 0px) !important;
    max-height: 100% !important;
    min-height: 0 !important;
    margin: 0 !important;
    padding: 14px !important;
    box-sizing: border-box !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
}

.bottomNav {
    position: absolute !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100% !important;
    height: 66px !important;
    min-height: 66px !important;
    box-sizing: border-box !important;
    z-index: 9999 !important;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px !important;
        min-height: 844px !important;
        margin: 20px auto !important;
        padding-bottom: 66px !important;
        border-radius: 28px !important;
        border: 1px solid #c2ceca !important;
    }
}


/* FINAL: match Beranda frame exactly */
html, body {
    width: 100% !important;
    height: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden !important;
}
.mobileContainer {
    width: 100% !important;
    max-width: 414px !important;
    height: 100vh !important;
    height: 100dvh !important;
    min-height: 100vh !important;
    min-height: 100dvh !important;
    margin: 0 auto !important;
    padding: 0 !important;
    position: relative !important;
    display: flex !important;
    flex-direction: column !important;
    box-sizing: border-box !important;
    overflow: hidden !important;
    border-radius: 0 !important;
    border: 0 !important;
}
.pageHeader {
    width: 100% !important;
    box-sizing: border-box !important;
}
.scrollableMainContent {
    width: 100% !important;
    height: auto !important;
    flex: 1 1 auto !important;
    min-height: 0 !important;
    margin: 0 !important;
    padding: 14px !important;
    box-sizing: border-box !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
}
.bottomNav {
    position: absolute !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100% !important;
    height: 66px !important;
    min-height: 66px !important;
    box-sizing: border-box !important;
    z-index: 9999 !important;
}
@media (min-width: 415px) {
    .mobileContainer {
        height: 100vh !important;
        min-height: 100vh !important;
        margin: 20px auto !important;
        border-radius: 28px !important;
        border: 1px solid #c2ceca !important;
    }
}


/* ===== JAJAP CUSTOMER UNIFIED APP FRAME =====
   Satu sistem frame untuk seluruh halaman customer.
   Frame selalu setinggi viewport, konten panjang scroll di dalam frame,
   dan tidak ada aturan 780/844px yang dapat membuat frame terpotong.
*/
html, body {
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  overflow: hidden !important;
  background: #d0d8d4 !important;
}

.mobileContainer {
  width: 100% !important;
  max-width: 414px !important;
  height: 100dvh !important;
  min-height: 0 !important;
  margin: 0 auto !important;
  padding: 0 !important;
  box-sizing: border-box !important;
  position: relative !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  border-radius: 36px !important;
  border: 1px solid #c2ceca !important;
  box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
}

.scrollableMainContent {
  flex: 1 1 auto !important;
  min-height: 0 !important;
  width: 100% !important;
  max-width: 100% !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  -webkit-overflow-scrolling: touch !important;
  box-sizing: border-box !important;
}

/* Semua navigasi bawah berada di dalam frame dan terbagi rata. */
.bottomNav {
  flex: 0 0 auto !important;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  z-index: 9999 !important;
}

/* Desktop/tablet: tetap ada jarak luar seperti desain Profil. */
@media (min-width: 415px) {
  .mobileContainer {
    height: calc(100dvh - 40px) !important;
    min-height: 0 !important;
    margin: 20px auto !important;
    border-radius: 36px !important;
  }
}

/* Mobile: frame memenuhi tinggi viewport tanpa menjadi 780/844px. */
@media (max-width: 414px) {
  .mobileContainer {
    height: 100dvh !important;
    min-height: 0 !important;
    margin: 0 auto !important;
    border-radius: 36px !important;
  }
}


/* ===== JAJAP UNIVERSAL MOBILE VIEWPORT FRAME v3 ===== */
html, body {
  margin: 0 !important;
  width: 100% !important;
  min-height: 100% !important;
}
body {
  background: #d0d8d4 !important;
  overflow: hidden !important;
}
.mobileContainer {
  position: fixed !important;
  inset: 0 auto 0 50% !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  height: auto !important;
  min-height: 0 !important;
  margin: 0 !important;
  padding-bottom: 0 !important;
  box-sizing: border-box !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  -webkit-overflow-scrolling: touch !important;
  border-radius: 0 !important;
  border: 0 !important;
}
/* The app shell itself stays phone-sized on larger screens. */
@media (min-width: 415px) {
  .mobileContainer {
    width: 414px !important;
    max-width: 414px !important;
    border-radius: 28px !important;
    border: 1px solid #c2ceca !important;
    box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
  }
}
/* Bottom navigation belongs to the phone viewport, never to the page scroll. */
.mobileContainer > .bottomNav,
.bottomNav {
  position: fixed !important;
  left: 50% !important;
  right: auto !important;
  bottom: 0 !important;
  top: auto !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  margin: 0 !important;
  z-index: 9999 !important;
  flex-shrink: 0 !important;
}
@media (min-width: 415px) {
  .mobileContainer > .bottomNav,
  .bottomNav {
    width: 414px !important;
    max-width: 414px !important;
  }
}
/* Keep normal content clear of the fixed bottom navigation. */
.mobileContainer {
  scroll-padding-bottom: 72px !important;
}
/* Home/header card should not expose the shell background while scrolling. */
.appHeader {
  position: sticky !important;
  top: 0 !important;
  z-index: 200 !important;
  overflow: hidden !important;
}
/* When a map/full-screen view is open, hide customer navigation. */
.mobileContainer.map-open .bottomNav,
.mobileContainer:has(#mapView.map-open) .bottomNav,
body.map-open .bottomNav,
body.maps-open .bottomNav {
  display: none !important;
}


/* FINAL PHONE FULL-SCREEN FRAME FIX v4 */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#d0d8d4 !important;
}
.mobileContainer {
  position:fixed !important;
  inset:0 !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
}
.mobileContainer > .scrollableMainContent {
  width:100% !important;
  max-width:none !important;
  min-width:0 !important;
  box-sizing:border-box !important;
}
.mobileContainer > .bottomNav, .bottomNav {
  position:fixed !important;
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  top:auto !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  margin:0 !important;
  z-index:99999 !important;
}
/* On a computer/laptop, preserve the phone-like width and height instead of desktop layout. */
@media (min-width:415px) {
  .mobileContainer {
    position:fixed !important;
    top:50% !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translate(-50%,-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:844px !important;
    min-height:844px !important;
    border:1px solid #c2ceca !important;
    border-radius:36px !important;
    box-shadow:0 0 40px rgba(0,0,0,.20) !important;
  }
  .mobileContainer > .bottomNav, .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}
@media (max-width:414px) {
  .mobileContainer {
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    border-radius:0 !important;
  }
}

</style>
<style>
/* ===== JAJAP FINAL FULL-SCREEN APP FRAME v5 =====
   Phone: application fills the real viewport.
   Desktop/laptop: keep a phone-width application, but use the full available height.
   No fixed 780px/844px frame height and no half-height centered card. */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  min-height:100% !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow:hidden !important;
}

html { background:#d0d8d4 !important; }

body {
  width:100% !important;
  min-height:100dvh !important;
  background:#d0d8d4 !important;
}

.mobileContainer, .box {
  position:fixed !important;
  inset:0 !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding-bottom:0 !important;
  box-sizing:border-box !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
}

/* Keep the application phone-sized on larger computer/laptop screens. */
@media (min-width:415px) {
  .mobileContainer, .box {
    top:0 !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translateX(-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:100dvh !important;
    min-height:100dvh !important;
    margin:0 !important;
    border:0 !important;
    border-radius:0 !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer, .box {
    left:0 !important;
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    transform:none !important;
    border-radius:0 !important;
  }
}

/* Bottom navigation stays attached to the visible app viewport. */
.mobileContainer > .bottomNav,
.mobileContainer .bottomNav,
.box > .bottomNav,
.box .bottomNav {
  position:fixed !important;
  top:auto !important;
  bottom:0 !important;
  z-index:99999 !important;
}

@media (min-width:415px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:0 !important;
    right:0 !important;
    width:100vw !important;
    max-width:none !important;
    transform:none !important;
  }
}
</style>

<style>
/* JAJAP UNIVERSAL APP FRAME v6 - one frame for every page */
html,body{width:100%;min-width:0;height:100%;min-height:100%;margin:0;padding:0;box-sizing:border-box;overflow:hidden}
html{background:#d0d8d4}
body{background:#d0d8d4;min-height:100dvh}
.mobileContainer,.box{
  position:fixed !important;
  top:0 !important;left:0 !important;right:auto !important;bottom:auto !important;
  width:100vw !important;max-width:none !important;
  height:100dvh !important;min-height:100dvh !important;
  margin:0 !important;box-sizing:border-box !important;
  border-radius:0 !important;border:0 !important;box-shadow:none !important;
  overflow:hidden !important;
}
/* Main pages use a single internal scrolling region; the frame itself never becomes a short card. */
.mobileContainer > .scrollableMainContent,
.mobileContainer > .scroll,
.mobileContainer > main.content,
.box > .scrollableMainContent{
  flex:1 1 auto !important;min-height:0 !important;
  overflow-y:auto !important;overflow-x:hidden !important;
  -webkit-overflow-scrolling:touch !important;
}
/* Form/landing pages without a dedicated content scroller can scroll inside the frame. */
.mobileContainer:has(> .logoBox),
.mobileContainer:has(> .welcomeText),
.box{overflow-y:auto !important;overflow-x:hidden !important;-webkit-overflow-scrolling:touch !important}
/* Keep bottom navigation pinned to the bottom of the app frame. */
.mobileContainer > .bottomNav,.box > .bottomNav{
  flex-shrink:0 !important;z-index:110 !important;
}
/* Full-screen maps must own the whole app viewport; page navigation is hidden while maps are open by existing JS/classes. */
#fullMapOverlay{position:fixed !important;inset:0 !important;width:100vw !important;height:100dvh !important;max-width:none !important;max-height:none !important;margin:0 !important;z-index:5000 !important}
/* Phones/tablets: truly edge-to-edge. A breakpoint above 414 prevents narrow mobile browsers from showing side gutters. */
@media (max-width:600px){
  .mobileContainer,.box{width:100vw !important;max-width:none !important;left:0 !important;transform:none !important}
  html,body{background:var(--bg,#f4f6f5) !important}
}
/* Computer/laptop: retain the phone-width application, centered, but use the full browser viewport height. */
@media (min-width:601px){
  .mobileContainer,.box{
    left:50% !important;right:auto !important;transform:translateX(-50%) !important;
    width:414px !important;max-width:414px !important;
    height:100dvh !important;min-height:100dvh !important;
    border-radius:28px !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

</style>
  <link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body><div class="app-container">
<div class="mobileContainer">
    <header class="pageHeader">
        <a href="profil.php" class="backBtn">‹</a>
        <h1>📍 Alamat Tersimpan</h1>
    </header>

    <div class="scrollableMainContent">
        <?php if($msg): ?><div style="background:#e9f8f1;color:var(--green-dark);padding:10px;border-radius:12px;font-size:11px;font-weight:800;margin-bottom:12px;text-align:center"><?=$msg?></div><?php endif; ?>

        <div class="cardBox">
            <b style="font-size:12px;display:block;margin-bottom:10px;color:var(--green-dark)">➕ Tambah Alamat Baru</b>
            <form method="POST">
                <input type="hidden" name="add_address" value="1">
                <div class="formGroup">
                    <label>Label Alamat (Misal: Kos / Rumah Nenek)</label>
                    <input type="text" name="label" placeholder="Contoh: 🏠 Rumah" required>
                </div>
                <div class="formGroup">
                    <label>Alamat Lengkap</label>
                    <input type="text" name="address" placeholder="Jalan, No. Rumah, Kecamatan, Kota..." required>
                </div>
                <button type="submit" class="btnSave">+ Simpan Alamat</button>
            </form>
        </div>

        <b style="font-size:12px;display:block;margin:14px 0 8px">Daftar Alamat Saya:</b>
        <?php foreach($_SESSION['user_addresses'] as $item): ?>
        <div class="cardBox">
            <div>
                <b style="font-size:12px;display:block"><?=htmlspecialchars($item['label'])?></b>
                <small style="color:var(--muted);font-size:11px"><?=htmlspecialchars($item['address'])?></small>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <nav class="bottomNav">
        <a href="index.php" class="navTab"><i>⌂</i>Beranda</a>
        <a href="pesanan.php" class="navTab"><i>🛒</i>Pesanan</a>
        <a href="aktivitas.php" class="navTab"><i>◷</i>Aktivitas</a>
        <a href="profil.php" class="navTab active"><i>👤</i>Profil</a>
    </nav>
</div>

<script>
(function(){
    const theme = localStorage.getItem('jajap_theme');
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
    }
})();
</script>

</div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body>
</html>

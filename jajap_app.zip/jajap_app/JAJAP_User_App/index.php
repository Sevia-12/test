<?php
require_once __DIR__.'/config/services.php';
require_once __DIR__.'/config/catalog.php';
session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/pricing.php';
$jajapPricing = jajap_settings($pdo instanceof PDO ? $pdo : null);
$jajapServices = jajap_services($pdo instanceof PDO ? $pdo : null);
$jajapBaseDelivery=(float)$jajapPricing['base_delivery_fee'];
$jajapBikePerKm=(float)$jajapPricing['bike_per_km'];
$jajapCarPerKm=(float)$jajapPricing['car_per_km'];

// Handle Guest Mode link
if (isset($_GET['guest']) && $_GET['guest'] == 1) {
    $_SESSION['guest'] = true;
    $_SESSION['user'] = ['id' => 0, 'name' => 'Tamu / Guest', 'phone' => '-', 'role' => 'guest'];
}

// Jika pengguna belum login dan bukan mode guest, arahkan ke welcome.php
if (!isset($_SESSION['user'])) {
    header('Location: welcome.php');
    exit;
}

$user = $_SESSION['user'];

// Akun admin hanya menggunakan Panel Admin. Jangan tampilkan Beranda versi admin.
if (($user['role'] ?? '') === 'admin') {
    unset($_SESSION['user']);
    header('Location: welcome.php?admin=separate');
    exit;
}

// Add to Cart mengambil data produk dari katalog database, bukan harga/nama dari URL.
if (isset($_GET['add_cart'], $_GET['id'], $_GET['type'])) {
    $catalogType = $_GET['type'] === 'mart' ? 'mart' : 'food';
    $catalog = jajap_catalog($catalogType, $pdo instanceof PDO ? $pdo : null);
    $selected = null;
    foreach ($catalog as $product) { if ((int)$product['id'] === (int)$_GET['id']) { $selected = $product; break; } }
    if ($selected) {
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        $_SESSION['cart'][] = [
            'id'=>$selected['id'], 'name'=>$selected['name'], 'price'=>$selected['price'], 'qty'=>1,
            'variant'=>$selected['variants'][0] ?? 'Standar', 'notes'=>'',
            'type'=>jajap_service_name($catalogType, $pdo instanceof PDO ? $pdo : null), 'catalog_type'=>$catalogType
        ];
        header('Location: pesanan.php'); exit;
    }
}

if (!function_exists('e')) { function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');} } 
function rp($n){return 'Rp '.number_format((float)$n,0,',','.');}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>JAJAP — Beranda Customer</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
:root{--green:#00a86b;--green-dark:#08794f;--green-soft:#e9f8f1;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#ffffff;--line:#e2ece7}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}

.mobileContainer{width:100%;max-width:100%;min-height:100vh;margin:20px auto;background:var(--bg);position:relative;padding-bottom:88px;box-shadow:0 0 40px rgba(0,0,0,.2);overflow:hidden;border-radius:28px;border:1px solid #c2ceca}

.appHeader{background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;padding:20px 16px 28px;border-radius:0 0 24px 24px;width:100%;box-sizing:border-box}
.topRow{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.brandLogo{font-size:20px;font-weight:900;display:flex;align-items:center;gap:6px}
.brandBadge{background:#fff;color:var(--green-dark);width:26px;height:26px;border-radius:8px;display:grid;place-items:center;font-size:15px;font-weight:1000}
.userGreeting{font-size:16px;font-weight:800;margin:0 0 2px}

.rideCard{background:var(--card);border-radius:20px;padding:14px;margin:-18px 14px 16px;box-shadow:0 8px 20px rgba(0,0,0,.04);border:1px solid var(--line);position:relative;z-index:10}
.vehicleSelector{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px}
.vTypeBtn{border:1px solid var(--line);background:#f7faf8;color:var(--muted);border-radius:12px;padding:8px;text-align:center;font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px}
.vTypeBtn.active{background:var(--green-soft);border-color:var(--green);color:var(--green-dark)}

#mapView{width:100%;height:160px;border-radius:14px;margin-bottom:12px;border:1px solid var(--line)}

.inputGroup{display:flex;flex-direction:column;gap:8px}
.inputRow{display:flex;align-items:center;gap:10px;background:#f8faf9;border:1px solid var(--line);border-radius:12px;padding:10px 12px}
.dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.dot.green{background:#00a86b}.dot.red{background:#ef4f5f}
.inputRow input{border:0;background:transparent;width:100%;font-size:12px;font-weight:600;outline:none;color:var(--ink)}

.gpsLocBtn{background:var(--green-soft);color:var(--green-dark);border:0;padding:4px 8px;border-radius:8px;font-size:10px;font-weight:800;cursor:pointer;white-space:nowrap}
.dropLocBtn{background:#ffebe8;color:#d9383a;border:0;padding:4px 8px;border-radius:8px;font-size:10px;font-weight:800;cursor:pointer;white-space:nowrap}

.fareResult{background:var(--green-soft);border:1px dashed var(--green);border-radius:12px;padding:10px;margin-top:10px;display:none;font-size:11px;line-height:1.5;color:var(--green-dark)}
.rideBtn{width:100%;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;border:0;border-radius:12px;padding:12px;font-size:13px;font-weight:800;cursor:pointer;margin-top:10px;box-shadow:0 6px 16px rgba(0,168,107,.2)}

.section{padding:0 14px;margin-bottom:18px}
.sectionHeader{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
.sectionTitle{font-size:13px;font-weight:800;color:var(--ink);margin:0}
.sectionMore{font-size:11px;font-weight:800;color:var(--green-dark);text-decoration:none}

.serviceGrid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.serviceItem{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:12px 4px;text-align:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.02)}
.serviceItem .icon{font-size:24px;margin-bottom:4px;display:block}
.serviceItem b{font-size:10px;display:block;color:var(--ink)}

.guestBanner{background:#fff8e6;border:1px solid #ffe0b2;padding:10px 14px;border-radius:14px;margin:0 14px 14px;font-size:11px;color:#b76e00;display:flex;justify-content:space-between;align-items:center}

/* HORIZONTAL SCROLL CARD ROWS */
.horizontalScrollRow{display:flex;gap:12px;overflow-x:auto;padding-bottom:8px;scrollbar-width:none;-webkit-overflow-scrolling:touch}
.horizontalScrollRow::-webkit-scrollbar{display:none}

.productCard{min-width:140px;width:140px;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:10px;box-shadow:0 2px 8px rgba(0,0,0,.03);display:flex;flex-direction:column;justify-content:space-between;flex-shrink:0}
.productImg{width:100%;height:80px;background:var(--green-soft);border-radius:12px;display:grid;place-items:center;font-size:36px;margin-bottom:8px}
.productTitle{font-size:11px;font-weight:800;color:var(--ink);margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.productDesc{font-size:9px;color:var(--muted);margin-bottom:6px;height:22px;overflow:hidden;line-height:1.2}
.productPrice{font-size:11px;font-weight:900;color:var(--green-dark);margin-bottom:8px}

.btnBuyCard{width:100%;background:var(--green);color:#fff;border:0;padding:6px;border-radius:8px;font-size:10px;font-weight:800;cursor:pointer;text-align:center;text-decoration:none;display:block;box-sizing:border-box}

.bottomNav{position:absolute;bottom:0;left:0;width:100%;height:66px;background:rgba(255,255,255,.98);border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(4,1fr);z-index:110}
.navTab{border:0;background:transparent;color:var(--muted);font-size:9px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;text-decoration:none}
.navTab.active{color:var(--green-dark)}

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow-x: hidden;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh; /* Dynamic Viewport Height for mobile browsers */
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    overflow-y: auto; /* PERMOHONAN: BISA DI SCROLL DARI ATAS KE BAWAH / BAWAH KE ATAS */
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    box-sizing: border-box;
    padding-bottom: 90px; /* Space for fixed bottomNav */
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px; /* Standard iPhone / Android height on desktop view */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}


/* FIKSASI UKURAN HP & BOTTOM NAVIGATION MENETAP DI BAWAH */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden; /* Mencegah seluruh layar web di luar HP ikut ter-scroll */
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden; /* Area luar dikunci */
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 780px; /* Ukuran tinggi HP ideal agar tidak terlalu panjang */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

/* MENETAPKAN BOTTOM NAV DI BAWAH TIGHT & TIDAK IKUT SCROLL */
.bottomNav {
    position: relative !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 62px !important;
    min-height: 62px !important;
    background: rgba(255,255,255,0.98) !important;
    border-top: 1px solid var(--line, #e2ece7) !important;
    display: grid !important;
    grid-template-columns: repeat(4, 1fr) !important;
    z-index: 9999 !important;
    box-shadow: 0 -4px 12px rgba(0,0,0,0.05) !important;
    flex-shrink: 0 !important;
}

/* AREA KONTEN UTAMA YANG BISA DI-SCROLL BERADA DI ANTARA HEADER & BOTTOM NAV */
.scrollableMainContent {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 20px;
}


/* DARK MODE ENGINE GLOBAL */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #9aa8a1 !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}
body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}
body.dark-mode .bottomNav {
    background: rgba(30, 38, 35, 0.98) !important;
    border-top-color: var(--line) !important;
}
body.dark-mode .navTab {
    color: var(--muted) !important;
}
body.dark-mode .navTab.active {
    color: #00d084 !important;
}
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #fff !important;
    border-color: var(--line) !important;
}


/* ENHANCED DARK MODE & LAYOUT UNIFORMITY FIX */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden !important;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow: hidden !important;
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px !important; /* DISAMAKAN PERSIS DENGAN INDEX.PHP (844px) */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

.scrollableMainContent {
    flex: 1 !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch;
}

/* DARK MODE CONTRAST FIXES */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #a0b2aa !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}

body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}

body.dark-mode .welcomeText h2,
body.dark-mode .welcomeText p,
body.dark-mode .brandTitle,
body.dark-mode label,
body.dark-mode b,
body.dark-mode span,
body.dark-mode h1, body.dark-mode h2, body.dark-mode h3 {
    color: #e8ecea !important;
}

/* FIX KHUSUS TOMBOL MODE TAMU (.btnGuest) DI TEMA GELAP */
body.dark-mode .btnGuest {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

/* FIX KHUSUS BANNER MODE TAMU DI INDEX.PHP */
body.dark-mode .guestBanner {
    background: #2a2518 !important;
    border-color: #483d22 !important;
    color: #ffc107 !important;
}

/* FIX KHUSUS INPUT & SELECT DI TEMA GELAP */
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

body.dark-mode input::placeholder {
    color: #889890 !important;
}

/* FINAL UNIFIED MOBILE APP FRAME — customer home can grow with its content */
html,body{width:100%;min-height:100%;margin:0;padding:0;overflow-x:hidden!important;overflow-y:auto!important}
body{background:#d0d8d4}
.mobileContainer{width:100%;max-width:100%;min-height:calc(100dvh - 40px);height:auto!important;margin:20px auto!important;padding:0!important;display:flex!important;flex-direction:column!important;position:relative!important;overflow:visible!important;border-radius:36px!important;border:1px solid #c2ceca!important;box-shadow:0 0 40px rgba(0,0,0,.2)!important;background:var(--bg)!important}
.scrollableMainContent{flex:0 0 auto!important;min-height:calc(100dvh - 102px)!important;width:100%!important;overflow:visible!important;padding-bottom:20px!important}
.bottomNav{position:sticky!important;left:auto!important;bottom:0!important;width:100%!important;height:62px!important;min-height:62px!important;flex:0 0 62px!important;background:rgba(30,38,35,.98)!important;border-top:1px solid #2d3834!important;display:grid!important;grid-template-columns:repeat(4,1fr)!important;z-index:9999!important;box-shadow:0 -4px 12px rgba(0,0,0,.08)!important}
.navTab{height:62px!important;border:0!important;background:transparent!important;color:#9aa8a1!important;font-size:9px!important;font-weight:800!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:3px!important;text-decoration:none!important}
.navTab i{font-style:normal!important;font-size:14px!important;line-height:1!important}
.navTab.active{color:#00d084!important}
body:not(.dark-mode) .mobileContainer{background:#f4f6f5!important}
body:not(.dark-mode) .bottomNav{background:rgba(255,255,255,.98)!important;border-top-color:#e2ece7!important}
body:not(.dark-mode) .navTab{color:#6f7d76!important}
body:not(.dark-mode) .navTab.active{color:#08794f!important}
@media (min-width:415px){.mobileContainer{min-height:844px!important;height:auto!important;margin:20px auto!important;border-radius:36px!important;border:1px solid #c2ceca!important;box-shadow:0 0 40px rgba(0,0,0,.2)!important}}
/* FINAL CUSTOMER HOME + MAP LAYOUT FIX
   - Header tetap di tempat saat konten Home di-scroll
   - Frame Home terpotong rapi mengikuti sudut rounded seperti Profil
   - Bottom navigation tetap menjadi bagian frame dan tidak menutupi Maps
   - Saat Full Maps dibuka, navigasi bawah disembunyikan
*/
html,body{
    width:100%;
    height:100%;
    margin:0;
    padding:0;
    overflow:hidden!important;
    background:#d0d8d4;
}

.mobileContainer{
    width:100%;
    max-width:100%;
    height:100dvh!important;
    min-height:0!important;
    margin:0 auto!important;
    padding:0!important;
    background:var(--bg)!important;
    position:relative!important;
    display:flex!important;
    flex-direction:column!important;
    overflow:hidden!important;
    border-radius:36px!important;
    border:1px solid #c2ceca!important;
    box-shadow:0 0 40px rgba(0,0,0,.2)!important;
}

.scrollableMainContent{
    flex:1 1 auto!important;
    min-height:0!important;
    width:100%!important;
    overflow-y:auto!important;
    overflow-x:hidden!important;
    -webkit-overflow-scrolling:touch!important;
    padding:0 0 24px!important;
    position:relative!important;
}

.appHeader{
    position:sticky!important;
    top:0!important;
    z-index:120!important;
    width:100%!important;
    flex-shrink:0!important;
    border-radius:36px 36px 24px 24px!important;
    overflow:hidden!important;
}

.bottomNav{
    position:relative!important;
    inset:auto!important;
    width:100%!important;
    height:62px!important;
    min-height:62px!important;
    flex:0 0 62px!important;
    display:grid!important;
    grid-template-columns:repeat(4,1fr)!important;
    z-index:9999!important;
    border-radius:0 0 36px 36px!important;
    box-shadow:0 -4px 12px rgba(0,0,0,.08)!important;
}

.navTab{
    height:62px!important;
    min-width:0!important;
    display:flex!important;
    align-items:center!important;
    justify-content:center!important;
    text-align:center!important;
}

.navTab .homeIcon{
    font-family:Arial,sans-serif!important;
    font-style:normal!important;
    font-size:15px!important;
    line-height:1!important;
    font-weight:400!important;
    display:block!important;
}

/* Full Maps harus berada di atas seluruh UI customer, termasuk bottomNav */
#fullMapOverlay{
    position:fixed!important;
    inset:0!important;
    width:100%!important;
    max-width:414px!important;
    height:100dvh!important;
    margin:0 auto!important;
    z-index:100000!important;
    border-radius:0!important;
    overflow:hidden!important;
}

/* Navigasi disembunyikan hanya ketika Full Maps sedang terbuka */
body.map-open .bottomNav{
    display:none!important;
}

/* Jangan biarkan elemen lain dari frame menutupi Full Maps */
body.map-open .mobileContainer{
    overflow:visible!important;
}

@media (min-width:415px){
    .mobileContainer{
        height:844px!important;
        min-height:844px!important;
        margin:20px auto!important;
        border-radius:36px!important;
    }
    #fullMapOverlay{
        height:844px!important;
        top:20px!important;
        bottom:auto!important;
        border-radius:36px!important;
    }
}
@media (max-width:414px){
    .mobileContainer{
        height:calc(100dvh - 40px)!important;
        min-height:0!important;
        margin:20px auto!important;
        border-radius:36px!important;
    }
    .appHeader{
        border-radius:36px 36px 24px 24px!important;
    }
}

/* ===== JAJAP CUSTOMER UNIFIED APP FRAME =====
   Satu sistem frame untuk seluruh halaman customer.
   Frame selalu setinggi viewport, konten panjang scroll di dalam frame,
   dan tidak ada aturan 780/844px yang dapat membuat frame terpotong.
*/
html, body {
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  overflow: hidden !important;
  background: #d0d8d4 !important;
}

.mobileContainer {
  width: 100% !important;
  max-width: 414px !important;
  height: 100dvh !important;
  min-height: 0 !important;
  margin: 0 auto !important;
  padding: 0 !important;
  box-sizing: border-box !important;
  position: relative !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  border-radius: 36px !important;
  border: 1px solid #c2ceca !important;
  box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
}

.scrollableMainContent {
  flex: 1 1 auto !important;
  min-height: 0 !important;
  width: 100% !important;
  max-width: 100% !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  -webkit-overflow-scrolling: touch !important;
  box-sizing: border-box !important;
}

/* Semua navigasi bawah berada di dalam frame dan terbagi rata. */
.bottomNav {
  flex: 0 0 auto !important;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  z-index: 9999 !important;
}

/* Desktop/tablet: tetap ada jarak luar seperti desain Profil. */
@media (min-width: 415px) {
  .mobileContainer {
    height: calc(100dvh - 40px) !important;
    min-height: 0 !important;
    margin: 20px auto !important;
    border-radius: 36px !important;
  }
}

/* Mobile: frame memenuhi tinggi viewport tanpa menjadi 780/844px. */
@media (max-width: 414px) {
  .mobileContainer {
    height: 100dvh !important;
    min-height: 0 !important;
    margin: 0 auto !important;
    border-radius: 36px !important;
  }
}


/* ===== JAJAP UNIVERSAL MOBILE VIEWPORT FRAME v3 ===== */
html, body {
  margin: 0 !important;
  width: 100% !important;
  min-height: 100% !important;
}
body {
  background: #d0d8d4 !important;
  overflow: hidden !important;
}
.mobileContainer {
  position: fixed !important;
  inset: 0 auto 0 50% !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  height: auto !important;
  min-height: 0 !important;
  margin: 0 !important;
  padding-bottom: 0 !important;
  box-sizing: border-box !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  -webkit-overflow-scrolling: touch !important;
  border-radius: 0 !important;
  border: 0 !important;
}
/* The app shell itself stays phone-sized on larger screens. */
@media (min-width: 415px) {
  .mobileContainer {
    width: 414px !important;
    max-width: 414px !important;
    border-radius: 28px !important;
    border: 1px solid #c2ceca !important;
    box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
  }
}
/* Bottom navigation belongs to the phone viewport, never to the page scroll. */
.mobileContainer > .bottomNav,
.bottomNav {
  position: fixed !important;
  left: 50% !important;
  right: auto !important;
  bottom: 0 !important;
  top: auto !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  margin: 0 !important;
  z-index: 9999 !important;
  flex-shrink: 0 !important;
}
@media (min-width: 415px) {
  .mobileContainer > .bottomNav,
  .bottomNav {
    width: 414px !important;
    max-width: 414px !important;
  }
}
/* Keep normal content clear of the fixed bottom navigation. */
.mobileContainer {
  scroll-padding-bottom: 72px !important;
}
/* Home/header card should not expose the shell background while scrolling. */
.appHeader {
  position: sticky !important;
  top: 0 !important;
  z-index: 200 !important;
  overflow: hidden !important;
}
/* When a map/full-screen view is open, hide customer navigation. */
.mobileContainer.map-open .bottomNav,
.mobileContainer:has(#mapView.map-open) .bottomNav,
body.map-open .bottomNav,
body.maps-open .bottomNav {
  display: none !important;
}


/* ===== FINAL VIEWPORT MAP OVERRIDE v3 ===== */
#fullMapOverlay {
  position: fixed !important;
  inset: 0 !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  height: auto !important;
  max-height: none !important;
  margin: 0 !important;
  left: 50% !important;
  right: auto !important;
  transform: translateX(-50%) !important;
  border-radius: 0 !important;
}
@media (min-width:415px) {
  #fullMapOverlay { width: 414px !important; max-width: 414px !important; }
}


/* FINAL PHONE FULL-SCREEN FRAME FIX v4 */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#d0d8d4 !important;
}
.mobileContainer {
  position:fixed !important;
  inset:0 !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
}
.mobileContainer > .scrollableMainContent {
  width:100% !important;
  max-width:none !important;
  min-width:0 !important;
  box-sizing:border-box !important;
}
.mobileContainer > .bottomNav, .bottomNav {
  position:fixed !important;
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  top:auto !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  margin:0 !important;
  z-index:99999 !important;
}
/* On a computer/laptop, preserve the phone-like width and height instead of desktop layout. */
@media (min-width:415px) {
  .mobileContainer {
    position:fixed !important;
    top:50% !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translate(-50%,-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:844px !important;
    min-height:844px !important;
    border:1px solid #c2ceca !important;
    border-radius:36px !important;
    box-shadow:0 0 40px rgba(0,0,0,.20) !important;
  }
  .mobileContainer > .bottomNav, .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}
@media (max-width:414px) {
  .mobileContainer {
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    border-radius:0 !important;
  }
}

</style>
<style>
/* ===== JAJAP FINAL FULL-SCREEN APP FRAME v5 =====
   Phone: application fills the real viewport.
   Desktop/laptop: keep a phone-width application, but use the full available height.
   No fixed 780px/844px frame height and no half-height centered card. */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  min-height:100% !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow:hidden !important;
}

html { background:#d0d8d4 !important; }

body {
  width:100% !important;
  min-height:100dvh !important;
  background:#d0d8d4 !important;
}

.mobileContainer, .box {
  position:fixed !important;
  inset:0 !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding-bottom:0 !important;
  box-sizing:border-box !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
}

/* Keep the application phone-sized on larger computer/laptop screens. */
@media (min-width:415px) {
  .mobileContainer, .box {
    top:0 !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translateX(-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:100dvh !important;
    min-height:100dvh !important;
    margin:0 !important;
    border:0 !important;
    border-radius:0 !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer, .box {
    left:0 !important;
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    transform:none !important;
    border-radius:0 !important;
  }
}

/* Bottom navigation stays attached to the visible app viewport. */
.mobileContainer > .bottomNav,
.mobileContainer .bottomNav,
.box > .bottomNav,
.box .bottomNav {
  position:fixed !important;
  top:auto !important;
  bottom:0 !important;
  z-index:99999 !important;
}

@media (min-width:415px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:0 !important;
    right:0 !important;
    width:100vw !important;
    max-width:none !important;
    transform:none !important;
  }
}
</style>

<style>
/* JAJAP UNIVERSAL APP FRAME v6 - one frame for every page */
html,body{width:100%;min-width:0;height:100%;min-height:100%;margin:0;padding:0;box-sizing:border-box;overflow:hidden}
html{background:#d0d8d4}
body{background:#d0d8d4;min-height:100dvh}
.mobileContainer,.box{
  position:fixed !important;
  top:0 !important;left:0 !important;right:auto !important;bottom:auto !important;
  width:100vw !important;max-width:none !important;
  height:100dvh !important;min-height:100dvh !important;
  margin:0 !important;box-sizing:border-box !important;
  border-radius:0 !important;border:0 !important;box-shadow:none !important;
  overflow:hidden !important;
}
/* Main pages use a single internal scrolling region; the frame itself never becomes a short card. */
.mobileContainer > .scrollableMainContent,
.mobileContainer > .scroll,
.mobileContainer > main.content,
.box > .scrollableMainContent{
  flex:1 1 auto !important;min-height:0 !important;
  overflow-y:auto !important;overflow-x:hidden !important;
  -webkit-overflow-scrolling:touch !important;
}
/* Form/landing pages without a dedicated content scroller can scroll inside the frame. */
.mobileContainer:has(> .logoBox),
.mobileContainer:has(> .welcomeText),
.box{overflow-y:auto !important;overflow-x:hidden !important;-webkit-overflow-scrolling:touch !important}
/* Keep bottom navigation pinned to the bottom of the app frame. */
.mobileContainer > .bottomNav,.box > .bottomNav{
  flex-shrink:0 !important;z-index:110 !important;
}
/* Full-screen maps must own the whole app viewport; page navigation is hidden while maps are open by existing JS/classes. */
#fullMapOverlay{position:fixed !important;inset:0 !important;width:100vw !important;height:100dvh !important;max-width:none !important;max-height:none !important;margin:0 !important;z-index:5000 !important}
/* Phones/tablets: truly edge-to-edge. A breakpoint above 414 prevents narrow mobile browsers from showing side gutters. */
@media (max-width:600px){
  .mobileContainer,.box{width:100vw !important;max-width:none !important;left:0 !important;transform:none !important}
  html,body{background:var(--bg,#f4f6f5) !important}
}
/* Computer/laptop: retain the phone-width application, centered, but use the full browser viewport height. */
@media (min-width:601px){
  .mobileContainer,.box{
    left:50% !important;right:auto !important;transform:translateX(-50%) !important;
    width:414px !important;max-width:414px !important;
    height:100dvh !important;min-height:100dvh !important;
    border-radius:28px !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

</style>
  <link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body><div class="app-container">

<div class="mobileContainer">
    <div class="scrollableMainContent">
    <header class="appHeader">
        <div class="topRow">
            <div class="brandLogo"><span class="brandBadge">J</span>JAJAP</div>
            <div id="cityBadge" style="font-size:11px;background:rgba(255,255,255,.2);padding:4px 10px;border-radius:20px">📍 Kuningan</div>
        </div>
        <div class="userGreeting">Halo, <?=e($user['name'])?> 👋</div>
        <div style="font-size:11px;opacity:.9">Siap jalan atau order kebutuhan hari ini?</div>
    </header>

    <?php if(isset($_SESSION['guest']) && $_SESSION['guest']): ?>
    <div class="guestBanner">
        <span>👀 Anda mengakses Mode Tamu</span>
        <a href="login.php" style="background:var(--green);color:#fff;padding:4px 10px;border-radius:8px;text-decoration:none;font-weight:800;font-size:10px">Masuk / Daftar</a>
    </div>
    <?php endif; ?>

    <section class="rideCard">
        <div class="vehicleSelector">
            <a class="vTypeBtn active" id="btnBike" href="jajapbike.php" onclick="return openTransportPage('bike')">🛵 <?=e($jajapServices['service_bike_name'])?></a>
            <a class="vTypeBtn" id="btnCar" href="jajapcar.php" onclick="return openTransportPage('car')">🚗 <?=e($jajapServices['service_car_name'])?></a>
        </div>

        <div id="mapView"></div>
<div style="display:flex;gap:7px;margin:-4px 0 10px">
            <button type="button" onclick="openFullMap()" style="flex:1;border:1px solid var(--line);background:#fff;border-radius:10px;padding:8px;font-size:10px;font-weight:800;color:var(--green-dark)">🗺️ Buka Maps</button>
            <button type="button" onclick="getGPSLocation()" style="border:1px solid var(--line);background:var(--green-soft);border-radius:10px;padding:8px 10px;font-size:10px;font-weight:800;color:var(--green-dark)">⌖ GPS</button>
        </div>
        <div style="font-size:10px;color:var(--muted);margin-bottom:8px;text-align:center">💡 <i>Ketuk/Geser titik di peta untuk menentukan lokasi presisi</i></div>

        <div class="inputGroup">
            <div class="inputRow">
                <span class="dot green"></span>
                <input type="text" id="pickupLoc" placeholder="Lokasi Penjemputan..." value="Panawuan, Kuningan" onchange="geocodeLocation('pick')">
                <button class="gpsLocBtn" onclick="getGPSLocation()">📍 GPS Jemput</button>
            </div>
            <div class="inputRow">
                <span class="dot red"></span>
                <input type="text" id="dropLoc" placeholder="Ketik lokasi tujuan (Misal: Cirebon)..." value="Alun-Alun Cirebon" onchange="geocodeLocation('drop')">
                <button class="dropLocBtn" onclick="setDropCenter()">🎯 Pin Tujuan</button>
            </div>
        </div>

        <div class="fareResult" id="fareResult"></div>
        <button class="rideBtn" id="btnSubmitRide" onclick="orderRide()">Cek Ongkir & Pesan</button>
    </section>

    <!-- MENU LAYANAN UTAMA -->
    <section class="section">
        <div class="sectionHeader">
            <h2 class="sectionTitle">Layanan Utama</h2>
        </div>
        <div class="serviceGrid">
            <a class="serviceItem" href="jajapbike.php" onclick="return openTransportPage('bike')" style="text-decoration:none">
                <span class="icon">🛵</span>
                <b><?=e($jajapServices['service_bike_name'])?></b>
            </a>
            <a class="serviceItem" href="jajapcar.php" onclick="return openTransportPage('car')" style="text-decoration:none">
                <span class="icon">🚗</span>
                <b><?=e($jajapServices['service_car_name'])?></b>
            </a>
            <div class="serviceItem" onclick="location.href='kuliner.php'">
                <span class="icon">🍜</span>
                <b><?=e($jajapServices['service_food_name'])?></b>
            </div>
            <div class="serviceItem" onclick="location.href='sembako.php'">
                <span class="icon">🛍️</span>
                <b><?=e($jajapServices['service_mart_name'])?></b>
            </div>
            <a class="serviceItem" href="jajapsend.php" style="text-decoration:none">
                <span class="icon">📦</span>
                <b><?=e($jajapServices['service_send_name'])?></b>
            </a>
        </div>
    </section>

    <!-- BARIS 1: PRODUK KULINER / LAYANAN MAKANAN -->
    <section class="section">
        <div class="sectionHeader">
            <h2 class="sectionTitle">🍜 Produk <?=e($jajapServices['service_food_name'])?> Populer</h2>
            <a href="kuliner.php" class="sectionMore">Lihat Semua ›</a>
        </div>
        <div class="horizontalScrollRow">
            <?php foreach(array_slice(jajap_catalog('food',$pdo instanceof PDO ? $pdo : null),0,5) as $p): ?>
            <div class="productCard">
                <div class="productImg"><?=e($p['icon'])?></div>
                <div class="productTitle"><?=e($p['name'])?></div>
                <div class="productDesc"><?=e($p['desc'])?></div>
                <div class="productPrice">Rp <?=number_format($p['price'],0,',','.')?></div>
                <a href="index.php?add_cart=1&id=<?=$p['id']?>&type=food" class="btnBuyCard">+ Keranjang</a>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- BARIS 2: PRODUK BELANJA / SEMBAKO -->
    <section class="section">
        <div class="sectionHeader">
            <h2 class="sectionTitle">🛍️ Bahan Baku & <?=e($jajapServices['service_mart_name'])?> Harian</h2>
            <a href="sembako.php" class="sectionMore">Lihat Semua ›</a>
        </div>
        <div class="horizontalScrollRow">
            <?php foreach(array_slice(jajap_catalog('mart',$pdo instanceof PDO ? $pdo : null),0,5) as $p): ?>
            <div class="productCard">
                <div class="productImg"><?=e($p['icon'])?></div>
                <div class="productTitle"><?=e($p['name'])?></div>
                <div class="productDesc"><?=e($p['desc'])?></div>
                <div class="productPrice">Rp <?=number_format($p['price'],0,',','.')?></div>
                <a href="index.php?add_cart=1&id=<?=$p['id']?>&type=mart" class="btnBuyCard">+ Keranjang</a>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

        </div>
    <!-- MAP MODE BESAR seperti aplikasi transportasi: bisa zoom, geser, GPS, dan pilih titik -->
    <div id="fullMapOverlay" style="display:none;position:fixed;inset:0;background:#eef2ef;z-index:5000;max-width:100%;margin:auto">
        <div id="fullMap" style="position:absolute;inset:0"></div>
        <div style="position:absolute;top:14px;left:14px;right:14px;display:flex;justify-content:space-between;z-index:5010;pointer-events:none">
            <button type="button" onclick="closeFullMap()" style="pointer-events:auto;width:40px;height:40px;border:0;border-radius:50%;background:#fff;box-shadow:0 3px 12px rgba(0,0,0,.18);font-size:20px">‹</button>
            <button type="button" onclick="locateFullMap()" style="pointer-events:auto;width:40px;height:40px;border:0;border-radius:50%;background:#fff;box-shadow:0 3px 12px rgba(0,0,0,.18);font-size:18px">⌖</button>
        </div>
        <div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-100%);z-index:5005;font-size:34px;filter:drop-shadow(0 2px 3px rgba(0,0,0,.3));pointer-events:none">📍</div>
        <div style="position:absolute;left:12px;right:12px;bottom:12px;background:#fff;border-radius:20px;padding:14px;z-index:5010;box-shadow:0 -4px 20px rgba(0,0,0,.12)">
            <div style="font-size:10px;color:var(--green-dark);font-weight:900">LOKASI SAAT INI</div>
            <div id="fullMapLocation" style="font-size:15px;font-weight:900;margin:5px 0">Geser peta untuk memilih titik</div>
            <div style="font-size:10px;color:#6f7d76;margin-bottom:10px">Peta bisa diperbesar, diperkecil, dan digeser seperti aplikasi transportasi.</div>
            <button type="button" onclick="useFullMapCenter()" style="width:100%;border:0;border-radius:12px;background:#00a86b;color:#fff;padding:12px;font-weight:900">Gunakan Lokasi Ini</button>
        </div>
    </div>

    <nav class="bottomNav">
        <a href="index.php" class="navTab active"><i class="homeIcon">⌂</i>Beranda</a>
        <a href="pesanan.php" class="navTab"><i>🛵</i>Pesanan</a>
        <a href="aktivitas.php" class="navTab"><i>◌</i>Aktivitas</a>
        <a href="profil.php" class="navTab"><i>👤</i>Profil</a>
    </nav>
</div>

<script>
let map, pickMarker, dropMarker;
let currentVehicle = 'bike';

let pickLat = -6.8794, pickLng = 108.5098;
let dropLat = -6.7252, dropLng = 108.5562;

function initMap() {
    map = L.map('mapView', { zoomControl: false }).setView([pickLat, pickLng], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

    const redIcon = L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
        iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
    });

    pickMarker = L.marker([pickLat, pickLng], {draggable: true}).addTo(map).bindPopup('📍 Lokasi Jemput').openPopup();
    dropMarker = L.marker([dropLat, dropLng], {icon: redIcon, draggable: true}).addTo(map).bindPopup('🎯 Lokasi Tujuan');

    pickMarker.on('dragend', function(e) {
        updateCityBadge(pickLat, pickLng);
        const pt = pickMarker.getLatLng();
        pickLat = pt.lat; pickLng = pt.lng;
        document.getElementById('pickupLoc').value = `Jemput: Presisi (${pickLat.toFixed(4)}, ${pickLng.toFixed(4)})`;
        calculateFare();
    });

    dropMarker.on('dragend', function(e) {
        const pt = dropMarker.getLatLng();
        dropLat = pt.lat; dropLng = pt.lng;
        document.getElementById('dropLoc').value = `Tujuan: Presisi (${dropLat.toFixed(4)}, ${dropLng.toFixed(4)})`;
        calculateFare();
    });

    calculateFare();
}

function getRealDistanceKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return (R * c * 1.2).toFixed(1);
}

function getGPSLocation() {
        setTimeout(() => updateCityBadge(pickLat, pickLng), 500);
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(pos => {
            pickLat = pos.coords.latitude; pickLng = pos.coords.longitude;
            map.setView([pickLat, pickLng], 14);
            pickMarker.setLatLng([pickLat, pickLng]);
            document.getElementById('pickupLoc').value = `GPS Jemput (${pickLat.toFixed(4)}, ${pickLng.toFixed(4)})`;
            calculateFare();
        }, () => alert('Aktifkan izin GPS pada HP Anda.'));
    }
}

function setDropCenter() {
    const center = map.getCenter();
    dropLat = center.lat; dropLng = center.lng;
    dropMarker.setLatLng([dropLat, dropLng]).openPopup();
    document.getElementById('dropLoc').value = `Tujuan Pin (${dropLat.toFixed(4)}, ${dropLng.toFixed(4)})`;
    calculateFare();
}

function geocodeLocation(type) {
    const val = (type === 'pick' ? document.getElementById('pickupLoc') : document.getElementById('dropLoc')).value.toLowerCase();
    if (val.includes('cirebon')) {
        if (type === 'drop') { dropLat = -6.7252; dropLng = 108.5562; dropMarker.setLatLng([dropLat, dropLng]); }
    } else if (val.includes('kuningan') || val.includes('panawuan')) {
        if (type === 'pick') { pickLat = -6.8794; pickLng = 108.5098; pickMarker.setLatLng([pickLat, pickLng]); }
    }
    fitMapBounds();
    calculateFare();
}

function fitMapBounds() {
    const bounds = L.latLngBounds([[pickLat, pickLng], [dropLat, dropLng]]);
    map.fitBounds(bounds, {padding: [30, 30]});
}

function setVehicle(type) {
    currentVehicle = type;
    document.getElementById('btnBike').classList.toggle('active', type === 'bike');
    document.getElementById('btnCar').classList.toggle('active', type === 'car');
    calculateFare();
}


function updateCityBadge(lat, lng) {
    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`)
        .then(res => res.json())
        .then(data => {
            if (data && data.address) {
                const city = data.address.city || data.address.town || data.address.regency || data.address.county || 'Lokasi Saya';
                document.getElementById('cityBadge').textContent = '📍 ' + city.replace('Kabupaten ', '');
            }
        }).catch(err => {});
}

function calculateFare() {
    const pickStr = document.getElementById('pickupLoc').value.trim();
    const dropStr = document.getElementById('dropLoc').value.trim();
    const resBox = document.getElementById('fareResult');
    const submitBtn = document.getElementById('btnSubmitRide');

    if (!pickStr || !dropStr) return;

    const distance = parseFloat(getRealDistanceKm(pickLat, pickLng, dropLat, dropLng));
    const baseFare = <?=json_encode($jajapBaseDelivery)?>;
    const perKm = currentVehicle === 'bike' ? <?=json_encode($jajapBikePerKm)?> : <?=json_encode($jajapCarPerKm)?>;
    const totalFare = Math.round(baseFare + (distance * perKm));

    resBox.style.display = 'block';
    resBox.innerHTML = `
        <div style="font-weight:800;color:var(--green-dark)">${currentVehicle === 'bike' ? '🛵 ' + <?=json_encode($jajapServices['service_bike_name'])?> : '🚗 ' + <?=json_encode($jajapServices['service_car_name'])?>}</div>
        <div>Estimasi Jarak: <b>${distance} KM</b></div>
        <div>Tarif: Rp ${baseFare.toLocaleString('id-ID')} + (${distance} KM x Rp ${perKm.toLocaleString('id-ID')})</div>
        <div style="font-size:13px;font-weight:900;color:var(--green-dark);margin-top:4px">Total Ongkir: Rp ${totalFare.toLocaleString('id-ID')}</div>
    `;
    submitBtn.textContent = 'Pesan ' + (currentVehicle === 'bike' ? 'Motor' : 'Mobil') + ' — Rp ' + totalFare.toLocaleString('id-ID');
}

function openTransportPage(type) {
    const page = type === 'car' ? 'jajapcar.php' : 'jajapbike.php';
    const pickText = document.getElementById('pickupLoc').value.trim();
    const dropText = document.getElementById('dropLoc').value.trim();
    const distance = parseFloat(getRealDistanceKm(pickLat, pickLng, dropLat, dropLng));
    const params = new URLSearchParams({
        pick: pickText,
        drop: dropText,
        distance_km: Number.isFinite(distance) ? distance.toFixed(1) : '0',
        pick_lat: String(pickLat), pick_lng: String(pickLng),
        drop_lat: String(dropLat), drop_lng: String(dropLng)
    });
    window.location.href = page + '?' + params.toString();
    return false;
}

function orderRide() {
    const pick = document.getElementById('pickupLoc').value.trim();
    const drop = document.getElementById('dropLoc').value.trim();
    const distance = parseFloat(getRealDistanceKm(pickLat, pickLng, dropLat, dropLng));
    const baseFare = <?=json_encode($jajapBaseDelivery)?>;
    const perKm = currentVehicle === 'bike' ? <?=json_encode($jajapBikePerKm)?> : <?=json_encode($jajapCarPerKm)?>;
    const fare = Math.round(baseFare + (distance * perKm));
    window.location.href = 'pesanan.php?action=ride&type=' + currentVehicle + '&pick=' + encodeURIComponent(pick) + '&drop=' + encodeURIComponent(drop) + '&distance_km=' + encodeURIComponent(distance) + '&fare=' + encodeURIComponent(fare);
}

let fullMap;
function openFullMap(){
    document.body.classList.add('map-open');
    document.getElementById('fullMapOverlay').style.display='block';
    setTimeout(function(){
        if(!fullMap){
            fullMap=L.map('fullMap',{zoomControl:true,zoomControlPosition:'bottomright'}).setView([pickLat,pickLng],14);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(fullMap);
            fullMap.on('moveend',updateFullMapLocation);
        } else { fullMap.invalidateSize(); fullMap.setView([pickLat,pickLng],Math.max(fullMap.getZoom(),14)); }
        updateFullMapLocation();
    },80);
}
function closeFullMap(){
    document.getElementById('fullMapOverlay').style.display='none';
    document.body.classList.remove('map-open');
}
function updateFullMapLocation(){if(!fullMap)return;const c=fullMap.getCenter();document.getElementById('fullMapLocation').textContent='Titik: '+c.lat.toFixed(5)+', '+c.lng.toFixed(5);}
function locateFullMap(){if(navigator.geolocation){navigator.geolocation.getCurrentPosition(function(pos){pickLat=pos.coords.latitude;pickLng=pos.coords.longitude;if(fullMap){fullMap.setView([pickLat,pickLng],16);}if(pickMarker)pickMarker.setLatLng([pickLat,pickLng]);document.getElementById('pickupLoc').value='GPS Jemput ('+pickLat.toFixed(4)+', '+pickLng.toFixed(4)+')';calculateFare();},function(){alert('Aktifkan izin GPS pada HP Anda.');});}}
function useFullMapCenter(){if(!fullMap)return;const c=fullMap.getCenter();pickLat=c.lat;pickLng=c.lng;if(pickMarker)pickMarker.setLatLng([pickLat,pickLng]);document.getElementById('pickupLoc').value='Lokasi Presisi ('+pickLat.toFixed(4)+', '+pickLng.toFixed(4)+')';calculateFare();closeFullMap();}

document.addEventListener('DOMContentLoaded', initMap);
</script>

<script>
(function(){
    const theme = localStorage.getItem('jajap_theme');
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
    }
})();
</script>

</div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body>
</html>

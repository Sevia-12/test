# JAJAP User App
Aplikasi utama untuk customer dan driver. Tidak menyediakan file admin.php; akses admin dipisahkan ke JAJAP_Admin_Panel.
Fitur tambahan: About Us, legal/privacy consent saat registrasi, dan rating/ulasan.

## Sinkronisasi tarif Admin Panel → User App
- Sumber tarif resmi: tabel `system_settings` pada database JAJAP.
- `base_delivery_fee` dipakai sebagai ongkir dasar layanan.
- `bike_per_km` dipakai untuk JAJAPBike.
- `car_per_km` dipakai untuk JAJAPCar.
- Halaman checkout menghitung ulang tarif transport dari database, sehingga nilai `fare` dari browser tidak menjadi sumber tarif final.
- Perubahan tarif di `JAJAP_Admin_Panel` otomatis dipakai oleh `JAJAP_User_App` selama kedua aplikasi terhubung ke database yang sama (`jajap_db` atau database JAJAP yang dikonfigurasi).

## Platform Upgrade — 3 Fondasi Utama

Versi ini menambahkan tiga lapisan tanpa mengganti halaman lama secara paksa:

1. **Backend & Order Engine**
   - `config/platform.php` sebagai lapisan platform.
   - Dispatch driver berdasarkan beban order aktif, tipe kendaraan, dan data lokasi bila tersedia.
   - State order: pending → accepted → delivering → completed/cancelled.
   - Riwayat status dan notifikasi tersimpan di database.

2. **Realtime Driver Tracking**
   - Driver mengirim GPS dari `driver.php` ke `api.php?action=driver_location`.
   - Customer dapat membuka `tracking.php?order_id=...` untuk melihat lokasi driver yang diperbarui berkala.
   - `aktivitas.php` mendapat tombol Lacak untuk order aktif.

3. **Payment Ledger + Notification + Safety**
   - `payment_transactions` menyimpan ledger transaksi dan reference.
   - Payment adapter saat ini menggunakan **provider sandbox** agar tidak mengubah perilaku checkout lama dan tidak berpura-pura terhubung ke gateway eksternal.
   - `notifications.php` menampilkan status order.
   - `safety.php` menyediakan pencatatan SOS/insiden/support dan tautan panggilan darurat (jika tersedia di wilayah pengguna).

### Sebelum produksi online
Payment provider sandbox harus diganti dengan gateway resmi (mis. Midtrans/Xendit/QRIS acquiring) melalui webhook dan signature verification. Realtime production sebaiknya dipindahkan ke WebSocket/managed realtime service, dan fitur SOS perlu operator/mitra keselamatan yang benar-benar aktif.

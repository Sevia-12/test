<?php require_once __DIR__.'/config/database.php'; require_once __DIR__.'/config/platform.php'; require_customer(); $st=$pdo->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50');$st->execute([$_SESSION['user']['id']]);$items=$st->fetchAll();$pdo->prepare('UPDATE notifications SET read_at=NOW() WHERE user_id=? AND read_at IS NULL')->execute([$_SESSION['user']['id']]); ?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Notifikasi — JAJAP</title><link rel="stylesheet" href="app-frame.css"><style>:root{--bg:#f4f6f5;--card:#fff;--ink:#1c2520;--muted:#6f7d76;--line:#e2ece7;--green:#00a86b}body{margin:0;background:#d0d8d4;color:var(--ink);font-family:system-ui}.mobileContainer{max-width:100%;height:100vh;margin:auto;background:var(--bg)}.head{padding:14px 16px;background:var(--card);border-bottom:1px solid var(--line);display:flex;gap:12px}.head a{font-size:22px;text-decoration:none;color:var(--ink)}.content{padding:12px}.item{background:var(--card);border:1px solid var(--line);border-radius:15px;padding:12px;margin-bottom:9px}.item b{font-size:12px}.item p{font-size:11px;color:var(--muted);line-height:1.5;margin:5px 0}.time{font-size:9px;color:var(--muted)}body.dark-mode{--bg:#121816;--card:#1e2623;--ink:#e8ecea;--muted:#a0b2aa;--line:#2d3834}body.dark-mode .mobileContainer{background:var(--bg)}</style><link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head><body><div class="app-container"><div class="mobileContainer"><header class="head"><a href="index.php">‹</a><b>🔔 Notifikasi</b></header><main class="content"><?php if(!$items):?><div class="item" style="text-align:center">Belum ada notifikasi.</div><?php endif;?><?php foreach($items as $n):?><div class="item"><b><?=htmlspecialchars($n['title'])?></b><p><?=nl2br(htmlspecialchars($n['body']))?></p><span class="time"><?=htmlspecialchars($n['created_at'])?></span><?php if($n['order_id']):?> · <a href="tracking.php?order_id=<?=$n['order_id']?>">Lihat order</a><?php endif;?></div><?php endforeach;?></main></div><script>if(localStorage.getItem('jajap_theme')==='dark')document.body.classList.add('dark-mode');</script></div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body></html>

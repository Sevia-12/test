<?php
require_once __DIR__.'/config/services.php';
session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/pricing.php';
if (!isset($_SESSION['user'])) { $_SESSION['user']=['id'=>2,'name'=>'Pengguna JAJAP','phone'=>'080000000002','role'=>'customer']; }
$type='car';
$title=jajap_service_name($type,$pdo instanceof PDO ? $pdo : null);
$baseFare=jajap_setting('base_delivery_fee'); $perKm=$type==='bike'?jajap_setting('bike_per_km'):jajap_setting('car_per_km'); $initialPick=trim((string)($_GET['pick']??'Panawuan, Kuningan')); $initialDrop=trim((string)($_GET['drop']??'Alun-Alun Cirebon')); $initialPickLat=(float)($_GET['pick_lat']??-6.8794); $initialPickLng=(float)($_GET['pick_lng']??108.5098); $initialDropLat=(float)($_GET['drop_lat']??-6.7252); $initialDropLng=(float)($_GET['drop_lng']??108.5562);
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['confirm_ride'])){
  $pick=trim($_POST['pickup']??'Lokasi Jemput'); $drop=trim($_POST['dropoff']??'Lokasi Tujuan'); $distanceKm=max(0,(float)($_POST['distance_km']??0)); $fare=jajap_transport_fare($pdo,$type,$distanceKm);
  $_SESSION['cart']=[['id'=>999,'name'=>($type==='bike'?'🛵 '.jajap_service_name('bike',$pdo instanceof PDO ? $pdo : null):'🚗 '.jajap_service_name('car',$pdo instanceof PDO ? $pdo : null)),'price'=>$fare,'qty'=>1,'variant'=>'Dari: '.$pick.' | Ke: '.$drop.' | Jarak: '.$distanceKm.' KM','distance_km'=>$distanceKm,'transport_type'=>$type,'notes'=>'','type'=>'Transport']];
  header('Location: pesanan.php'); exit;
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>JAJAP — <?=$title?></title><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><link rel="stylesheet" href="app-frame.css"><style>
:root{--green:#00a86b;--green-dark:#08794f;--green-soft:#e9f8f1;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#fff;--line:#e2ece7}
html,body{margin:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}.mobileContainer{background:var(--bg);display:flex;flex-direction:column}.pageHeader{height:52px;flex:0 0 52px;background:var(--card);border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px;padding:0 14px;z-index:100}.pageHeader a{text-decoration:none;color:var(--ink);font-size:22px}.pageHeader h1{font-size:15px;margin:0;font-weight:900}.rideScroll{flex:1;min-height:0;overflow-y:auto;padding:12px 14px 92px}.fieldCard,.previewCard{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:12px;margin-bottom:10px}.label{font-size:10px;font-weight:900;color:var(--muted);margin-bottom:6px}.locRow{display:flex;gap:7px;align-items:center}.locDot{width:10px;height:10px;border-radius:50%;flex:0 0 10px}.greenDot{background:#00a86b}.redDot{background:#ef4f5f}.locInput{flex:1;min-width:0;border:1px solid var(--line);background:#f8faf9;border-radius:10px;padding:10px;font-size:11px;outline:none;color:var(--ink)}.mapPickBtn{border:1px solid var(--green);background:var(--green-soft);color:var(--green-dark);border-radius:10px;padding:9px 10px;font-size:10px;font-weight:900;white-space:nowrap}.searchResults{display:none;margin-top:7px;border:1px solid var(--line);border-radius:10px;overflow:hidden}.searchResults button{width:100%;border:0;border-bottom:1px solid var(--line);background:var(--card);padding:9px;text-align:left;font-size:10px;color:var(--ink)}.searchResults button:last-child{border-bottom:0}.previewMap{height:190px;border-radius:14px;overflow:hidden;margin-bottom:10px;border:1px solid var(--line)}.summary{display:grid;grid-template-columns:1fr 1fr;gap:8px}.metric{background:var(--green-soft);border:1px dashed var(--green);border-radius:11px;padding:10px}.metric small{display:block;color:var(--muted);font-size:9px}.metric b{font-size:12px;color:var(--green-dark)}.vehicleChoice{display:flex;gap:8px;margin-top:10px}.vehicleChoice div{flex:1;background:#f8faf9;border:1px solid var(--line);border-radius:10px;padding:9px;text-align:center;font-size:10px;font-weight:900}.vehicleChoice .selected{background:var(--green-soft);border-color:var(--green);color:var(--green-dark)}.rideConfirm{position:absolute;left:0;right:0;bottom:66px;background:var(--card);border-top:1px solid var(--line);padding:10px 14px;z-index:100}.rideConfirm button{width:100%;border:0;border-radius:12px;padding:13px;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;font-size:12px;font-weight:900}.mapOverlay{display:none;position:absolute;inset:0;background:#eaf0ed;z-index:5000}.mobileContainer.map-open .mapOverlay{display:block}.mobileContainer.map-open .bottomNav{display:none!important}.mapCanvas{position:absolute;inset:0}.mapTop{position:absolute;top:12px;left:12px;right:12px;display:flex;gap:8px;z-index:20}.mapTop input{flex:1;border:1px solid #ddd;border-radius:12px;padding:11px 12px;background:#fff;box-shadow:0 3px 12px rgba(0,0,0,.14);font-size:11px}.mapTop button,.mapBottom button{border:0;background:#fff;border-radius:12px;padding:10px 12px;box-shadow:0 3px 12px rgba(0,0,0,.14);font-weight:900}.mapBottom{position:absolute;left:12px;right:12px;bottom:14px;z-index:20;background:rgba(255,255,255,.96);border-radius:16px;padding:10px;box-shadow:0 5px 18px rgba(0,0,0,.18);display:flex;gap:8px;align-items:center}.mapBottom span{flex:1;font-size:10px;color:#4b5751}.mapBottom button.confirm{background:var(--green);color:#fff}.centerPin{position:absolute;left:50%;top:50%;transform:translate(-50%,-100%);z-index:10;font-size:34px;filter:drop-shadow(0 2px 2px rgba(0,0,0,.2))}
body.dark-mode{--bg:#121816;--card:#1e2623;--ink:#e8ecea;--muted:#a0b2aa;--line:#2d3834;--green-soft:#183329}body.dark-mode .mobileContainer{background:var(--bg)}body.dark-mode .locInput,body.dark-mode .searchResults button,body.dark-mode .mapTop input{background:#25302c;color:#fff;border-color:var(--line)}

/* JAJAP transport bottom navigation: clean SVG icons, centered in the app frame. */
.rideBottomNav{position:absolute!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:66px!important;min-height:66px!important;background:#1e1e1e!important;border-top:1px solid rgba(255,255,255,.08)!important;display:grid!important;grid-template-columns:repeat(4,1fr)!important;z-index:99999!important;padding:0!important;margin:0!important;box-sizing:border-box!important;}
.rideNavItem{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:4px!important;width:100%!important;height:66px!important;padding:0!important;margin:0!important;text-decoration:none!important;color:#aeb7b3!important;font-size:9px!important;font-weight:800!important;line-height:1!important;box-sizing:border-box!important;}
.rideNavItem svg{width:21px!important;height:21px!important;display:block!important;fill:none!important;stroke:currentColor!important;stroke-width:1.9!important;stroke-linecap:round!important;stroke-linejoin:round!important;flex:0 0 21px!important;margin:0!important;}
.rideNavItem span{display:block!important;margin:0!important;padding:0!important;white-space:nowrap!important;}
.rideNavItem:hover,.rideNavItem:focus{color:#00d084!important;}
@media (max-width:414px){.rideBottomNav{height:66px!important}.rideNavItem{height:66px!important}}

/* MAP PICKER — Gojek/Grab-style centered pin UI */
.mapOverlay{
  display:none!important;
  position:absolute!important;
  inset:0!important;
  width:100%!important;
  height:100%!important;
  background:#eef2f0!important;
  z-index:2147483000!important;
  overflow:hidden!important;
}
.mobileContainer.map-open .mapOverlay{display:block!important}
.mobileContainer.map-open .rideBottomNav,
.mobileContainer.map-open .bottomNav{display:none!important}
.mapCanvas{
  position:absolute!important;
  inset:0!important;
  width:100%!important;
  height:100%!important;
  z-index:1!important;
}
.mapTop{
  position:absolute!important;
  top:12px!important;
  left:12px!important;
  right:12px!important;
  min-height:50px!important;
  display:flex!important;
  align-items:center!important;
  gap:8px!important;
  padding:7px!important;
  background:#fff!important;
  border:1px solid rgba(0,0,0,.10)!important;
  border-radius:16px!important;
  box-shadow:0 5px 18px rgba(0,0,0,.20)!important;
  z-index:10000!important;
}
.mapTop button{
  flex:0 0 42px!important;
  width:42px!important;
  height:38px!important;
  border:0!important;
  border-radius:11px!important;
  background:#f3f5f4!important;
  color:#202622!important;
  box-shadow:none!important;
  font-size:20px!important;
  font-weight:900!important;
  line-height:1!important;
  cursor:pointer!important;
}
.mapTop button.mapSearchSubmit{
  flex-basis:54px!important;
  width:54px!important;
  font-size:11px!important;
  background:#00a86b!important;
  color:#fff!important;
}
.mapTop input#mapSearch{
  flex:1 1 auto!important;
  min-width:0!important;
  width:auto!important;
  height:38px!important;
  border:1px solid #d8dedb!important;
  border-radius:11px!important;
  background:#fff!important;
  color:#111!important;
  -webkit-text-fill-color:#111!important;
  outline:none!important;
  box-shadow:none!important;
  padding:0 12px!important;
  font-size:12px!important;
  font-weight:600!important;
}
.mapTop input#mapSearch::placeholder{color:#69736e!important;opacity:1!important}
.centerPin{
  position:absolute!important;
  left:50%!important;
  top:50%!important;
  transform:translate(-50%,-100%)!important;
  z-index:9000!important;
  width:46px!important;
  height:58px!important;
  display:flex!important;
  align-items:flex-start!important;
  justify-content:center!important;
  pointer-events:none!important;
  filter:drop-shadow(0 3px 4px rgba(0,0,0,.28))!important;
}
.centerPin svg{width:46px!important;height:58px!important;display:block!important}
.mapBottom{
  position:absolute!important;
  left:12px!important;
  right:12px!important;
  bottom:12px!important;
  z-index:10000!important;
  display:grid!important;
  grid-template-columns:1fr auto!important;
  gap:8px!important;
  align-items:center!important;
  padding:11px!important;
  background:rgba(255,255,255,.98)!important;
  border:1px solid rgba(0,0,0,.10)!important;
  border-radius:17px!important;
  box-shadow:0 6px 20px rgba(0,0,0,.22)!important;
}
.mapBottom span{
  grid-column:1/-1!important;
  display:block!important;
  min-width:0!important;
  color:#27312d!important;
  font-size:10px!important;
  font-weight:700!important;
  line-height:1.35!important;
  padding:0 2px 2px!important;
}
.mapBottom button{
  min-height:44px!important;
  border:0!important;
  border-radius:12px!important;
  padding:0 14px!important;
  background:#f0f3f2!important;
  color:#26302c!important;
  box-shadow:none!important;
  font-size:11px!important;
  font-weight:900!important;
}
.mapBottom button.confirm{
  grid-column:1/-1!important;
  width:100%!important;
  background:linear-gradient(135deg,#00b875,#08794f)!important;
  color:#fff!important;
  font-size:13px!important;
}
body.dark-mode .mapTop,
body.dark-mode .mapBottom{background:rgba(255,255,255,.98)!important}
@media (max-height:650px){
  .mapTop{top:8px!important}
  .mapBottom{bottom:8px!important}
}
</style><link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head><body><div class="app-container"><div class="mobileContainer" id="app"><header class="pageHeader"><a href="index.php">‹</a><h1><?=$title?> — Pesan Perjalanan</h1></header><main class="rideScroll"><div class="fieldCard"><div class="label">📍 LOKASI PENJEMPUTAN</div><div class="locRow"><span class="locDot greenDot"></span><input class="locInput" id="pickup" value="<?=e($initialPick)?>" placeholder="Cari lokasi penjemputan"></div><div class="locRow" style="margin-top:7px"><span style="width:10px"></span><button type="button" class="mapPickBtn" onclick="openMap('pickup')">📍 Pilih lewat Maps</button></div><div class="searchResults" id="pickupResults"></div></div><div class="fieldCard"><div class="label">🔴 LOKASI TUJUAN</div><div class="locRow"><span class="locDot redDot"></span><input class="locInput" id="dropoff" value="<?=e($initialDrop)?>" placeholder="Cari lokasi tujuan"></div><div class="locRow" style="margin-top:7px"><span style="width:10px"></span><button type="button" class="mapPickBtn" onclick="openMap('dropoff')">📍 Pilih lewat Maps</button></div><div class="searchResults" id="dropoffResults"></div></div><div class="previewCard"><div class="label">PREVIEW PERJALANAN</div><div id="previewMap" class="previewMap"></div><div class="summary"><div class="metric"><small>Estimasi Jarak</small><b id="distance">Menghitung...</b></div><div class="metric"><small>Estimasi Tarif</small><b id="fare">Menghitung...</b></div></div><div class="vehicleChoice"><div class="selected"><?=$type==='bike'?'🛵 '.e(jajap_service_name('bike',$pdo instanceof PDO ? $pdo : null)):'🚗 '.e(jajap_service_name('car',$pdo instanceof PDO ? $pdo : null))?></div><div><?=$type==='bike'?'Motor':'Mobil'?></div></div></div></main><form method="POST" class="rideConfirm"><input type="hidden" name="confirm_ride" value="1"><input type="hidden" name="pickup" id="formPickup"><input type="hidden" name="dropoff" id="formDropoff"><input type="hidden" name="fare" id="formFare"><input type="hidden" name="distance_km" id="formDistanceKm" value="0"><button type="submit" id="orderBtn">Pesan <?=$title?></button></form><nav class="rideBottomNav" aria-label="Navigasi utama JAJAP">
<a href="index.php" class="rideNavItem"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10.8 12 3l9 7.8v9.2a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z"/></svg><span>Beranda</span></a>
<a href="pesanan.php" class="rideNavItem"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4h12l1 3H5zM5 7h14v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1zM9 11h6M9 15h6"/></svg><span>Pesanan</span></a>
<a href="aktivitas.php" class="rideNavItem"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/></svg><span>Aktivitas</span></a>
<a href="profil.php" class="rideNavItem"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.2"/><path d="M5.5 20c.7-3.5 3-5.2 6.5-5.2s5.8 1.7 6.5 5.2"/></svg><span>Profil</span></a>
</nav><div class="mapOverlay" id="mapOverlay" aria-hidden="true">
  <div id="mapCanvas" class="mapCanvas"></div>
  <div class="mapTop" role="search">
    <button type="button" onclick="closeMap()" aria-label="Kembali">‹</button>
    <input id="mapSearch" type="search" autocomplete="off" autocapitalize="words" enterkeyhint="search" placeholder="Cari lokasi di Maps">
    <button type="button" class="mapSearchSubmit" onclick="searchMap()">Cari</button>
  </div>
  <div class="centerPin" aria-hidden="true">
    <svg viewBox="0 0 48 60" xmlns="http://www.w3.org/2000/svg">
      <path d="M24 58S7 38.5 7 23.5C7 14.1 14.6 6.5 24 6.5s17 7.6 17 17C41 38.5 24 58 24 58Z" fill="#00a86b" stroke="#fff" stroke-width="3"/>
      <circle cx="24" cy="23.5" r="7" fill="#fff"/>
    </svg>
  </div>
  <div class="mapBottom">
    <span id="mapLabel">Geser peta sampai pin berada di lokasi yang dipilih.</span>
    <button type="button" onclick="useGPS()" aria-label="Gunakan lokasi saya">⌖ GPS</button>
    <button type="button" class="confirm" onclick="confirmMapLocation()">Konfirmasi Lokasi</button>
  </div>
</div></div><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>
let map=null,preview=null,activeField='pickup',pick=[<?=json_encode($initialPickLat)?>,<?=json_encode($initialPickLng)?>],drop=[<?=json_encode($initialDropLat)?>,<?=json_encode($initialDropLng)?>],routeLayer=null;const base=<?=$baseFare?>,perKm=<?=$perKm?>;function init(){preview=L.map('previewMap',{zoomControl:false}).setView(pick,11);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(preview);updatePreview();}function geocode(q){return fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q='+encodeURIComponent(q)).then(r=>r.json()).then(a=>a[0]?{lat:+a[0].lat,lng:+a[0].lon,name:a[0].display_name}:null).catch(()=>null)}function reverse(lat,lng){return fetch('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='+lat+'&lon='+lng).then(r=>r.json()).then(a=>a.display_name||('Titik '+lat.toFixed(5)+', '+lng.toFixed(5))).catch(()=>('Titik '+lat.toFixed(5)+', '+lng.toFixed(5)))}async function updatePreview(){
  preview.eachLayer(l=>{if(l instanceof L.Marker||l instanceof L.Polyline||l instanceof L.GeoJSON)preview.removeLayer(l)});
  L.marker(pick).addTo(preview).bindPopup('Penjemputan').openPopup();
  L.marker(drop).addTo(preview).bindPopup('Tujuan');
  // Gunakan rumus jarak yang sama persis dengan Beranda JAJAP. OSRM hanya
  // dipakai untuk menggambar jalur pada peta, bukan untuk mengubah tarif.
  const R=6371, dLat=(drop[0]-pick[0])*Math.PI/180, dLon=(drop[1]-pick[1])*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(pick[0]*Math.PI/180)*Math.cos(drop[0]*Math.PI/180)*Math.sin(dLon/2)**2;
  const straight=R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
  const km=parseFloat((straight*1.2).toFixed(1));
  const fare=Math.round(base+(km*perKm));
  document.getElementById('distance').textContent=km.toFixed(1).replace('.',',')+' km';
  document.getElementById('fare').textContent='Rp '+fare.toLocaleString('id-ID');
  document.getElementById('formFare').value=fare;
  document.getElementById('formDistanceKm').value=km;
  document.getElementById('orderBtn').textContent='Pesan <?=$title?> — Rp '+fare.toLocaleString('id-ID');
  try{
    const u='https://router.project-osrm.org/route/v1/driving/'+pick[1]+','+pick[0]+';'+drop[1]+','+drop[0]+'?overview=full&geometries=geojson';
    const j=await fetch(u).then(r=>r.json());
    if(j.routes&&j.routes[0]){
      routeLayer=L.geoJSON(j.routes[0].geometry).addTo(preview);
      preview.fitBounds(routeLayer.getBounds(),{padding:[18,18]});
      return;
    }
  }catch(e){}
  preview.fitBounds(L.latLngBounds([pick,drop]),{padding:[18,18]});
}function openMap(field){
  activeField=field;
  const overlay=document.getElementById('mapOverlay');
  document.getElementById('app').classList.add('map-open');
  overlay.setAttribute('aria-hidden','false');
  setTimeout(()=>{
    if(!map){
      map=L.map('mapCanvas',{zoomControl:true,attributionControl:true}).setView(field==='pickup'?pick:drop,15);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
      map.on('moveend',()=>updateMapLabel());
      map.on('zoomend',()=>updateMapLabel());
    }else{
      map.invalidateSize(true);
      map.setView(field==='pickup'?pick:drop,15,{animate:false});
    }
    updateMapLabel();
    setTimeout(()=>map && map.invalidateSize(true),120);
  },60);
}function updateMapLabel(){if(!map)return;const c=map.getCenter();document.getElementById('mapLabel').textContent=(activeField==='pickup'?'Penjemputan: ':'Tujuan: ')+c.lat.toFixed(5)+', '+c.lng.toFixed(5)}function closeMap(){
  document.getElementById('app').classList.remove('map-open');
  document.getElementById('mapOverlay').setAttribute('aria-hidden','true');
}async function confirmMapLocation(){if(!map)return;const c=map.getCenter();const label=await reverse(c.lat,c.lng);if(activeField==='pickup'){pick=[c.lat,c.lng];document.getElementById('pickup').value=label}else{drop=[c.lat,c.lng];document.getElementById('dropoff').value=label}document.getElementById('formPickup').value=document.getElementById('pickup').value;document.getElementById('formDropoff').value=document.getElementById('dropoff').value;closeMap();updatePreview()}async function searchMap(){
  const input=document.getElementById('mapSearch');
  const q=input.value.trim();
  if(!q)return;
  input.blur();
  const r=await geocode(q);
  if(!r){document.getElementById('mapLabel').textContent='Lokasi tidak ditemukan. Coba kata kunci lain.';return;}
  if(map){map.setView([r.lat,r.lng],16,{animate:true});}
  updateMapLabel();
}function useGPS(){if(!navigator.geolocation){return alert('GPS tidak tersedia di perangkat ini.')}navigator.geolocation.getCurrentPosition(pos=>{if(map){map.setView([pos.coords.latitude,pos.coords.longitude],17);updateMapLabel()}},()=>alert('Izin lokasi belum diberikan.'))}async function searchField(field){const input=document.getElementById(field==='pickup'?'pickup':'dropoff');const box=document.getElementById(field==='pickup'?'pickupResults':'dropoffResults');const q=input.value.trim();if(!q)return;const url='https://nominatim.openstreetmap.org/search?format=jsonv2&limit=4&q='+encodeURIComponent(q);try{const arr=await fetch(url).then(r=>r.json());box.innerHTML='';arr.forEach(x=>{const b=document.createElement('button');b.type='button';b.textContent=x.display_name;b.onclick=()=>{input.value=x.display_name;box.style.display='none';if(field==='pickup')pick=[+x.lat,+x.lon];else drop=[+x.lat,+x.lon];updatePreview()};box.appendChild(b)});box.style.display=arr.length?'block':'none'}catch(e){box.style.display='none'}}document.getElementById('mapSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchMap()}});document.getElementById('pickup').addEventListener('change',()=>searchField('pickup'));document.getElementById('dropoff').addEventListener('change',()=>searchField('dropoff'));document.getElementById('formPickup').value=document.getElementById('pickup').value;document.getElementById('formDropoff').value=document.getElementById('dropoff').value;(function(){if(localStorage.getItem('jajap_theme')==='dark')document.body.classList.add('dark-mode');init()})();
</script></div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body></html>
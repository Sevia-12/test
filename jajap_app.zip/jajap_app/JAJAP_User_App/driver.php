<?php
require_once __DIR__.'/config/services.php';
session_start();
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/platform.php';

$user = $_SESSION['user'] ?? null;
if (!$user || ($user['role'] ?? '') !== 'driver') {
    header('Location: login.php');
    exit;
}

$driverId = (int)$user['id'];
$driverName = $user['name'];
$msg = '';
$realOrder = null;

// Driver order state controls: accepted -> delivering -> completed, plus cancellation.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order_status']) && $pdo instanceof PDO && csrf_check($_POST['csrf'] ?? '')) {
    $orderId=(int)($_POST['order_id']??0); $newStatus=$_POST['new_status']??'';
    if($orderId>0 && in_array($newStatus,['delivering','completed','cancelled'],true)) {
        try {
            $st=$pdo->prepare("SELECT * FROM orders WHERE id=? AND driver_id=? LIMIT 1"); $st->execute([$orderId,$driverId]); $o=$st->fetch();
            $allowed=$o && (($o['status']==='accepted' && in_array($newStatus,['delivering','cancelled'],true)) || ($o['status']==='delivering' && in_array($newStatus,['completed','cancelled'],true)));
            if($allowed){
                $pdo->beginTransaction();
                $fields="status=?,last_status_at=NOW()";$params=[$newStatus]; if($newStatus==='completed'){$fields.=',completed_at=NOW()';}
                $params[]=$orderId;$params[]=$driverId; $pdo->prepare("UPDATE orders SET $fields WHERE id=? AND driver_id=?")->execute($params);
                $pdo->commit();
                $o['status']=$newStatus; jajap_order_status_notify($pdo,$o,$newStatus);
                $msg='✅ Status order diperbarui menjadi '.strtoupper($newStatus).'.';
            } else { $msg='ℹ️ Perubahan status belum tersedia untuk order ini.'; }
        } catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); $msg='❌ Status order gagal diperbarui.'; }
    }
}

// Accept a real order assigned to this driver.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accept_order']) && $pdo instanceof PDO && csrf_check($_POST['csrf'] ?? '')) {
    $orderId = (int)($_POST['order_id'] ?? 0);
    if ($orderId > 0) {
        try {
            $st = $pdo->prepare("UPDATE orders SET status='accepted', assigned_at=COALESCE(assigned_at,NOW()) WHERE id=? AND driver_id=? AND status='pending'");
            $st->execute([$orderId, $driverId]);
            $msg = $st->rowCount() ? '✅ Orderan berhasil diambil! Silakan meluncur ke lokasi jemput.' : 'ℹ️ Orderan sudah diambil atau tidak lagi tersedia.';
        } catch (Throwable $ignore) {
            $msg = '❌ Orderan belum dapat diperbarui. Silakan coba lagi.';
        }
    }
}

// Read the latest real order assigned to this driver.
if ($pdo instanceof PDO) {
    try {
        $st = $pdo->prepare("SELECT o.*, u.name AS customer_name FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE o.driver_id=? AND o.status IN ('pending','accepted','delivering') ORDER BY o.id DESC LIMIT 1");
        $st->execute([$driverId]);
        $realOrder = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $ignore) {}
}

// Fallback demo order is kept only when there is no database order yet.
$sampleOrders = [
    ['id'=>1001,'type'=>'🛵 '.jajap_service_name('bike',$pdo instanceof PDO ? $pdo : null).' (Motor)','fare'=>17000,'pick'=>'Panawuan, Kuningan','drop'=>'Alun-Alun Cirebon (22 KM)','customer'=>'Siti Aisyah'],
    ['id'=>1002,'type'=>'🚗 '.jajap_service_name('car',$pdo instanceof PDO ? $pdo : null).' (Mobil)','fare'=>38000,'pick'=>'Sangkanurip, Kuningan','drop'=>'Grage Mall Cirebon (25 KM)','customer'=>'Budi Pratama'],
    ['id'=>1003,'type'=>'🍜 '.jajap_service_name('food',$pdo instanceof PDO ? $pdo : null).' (Kuliner)','fare'=>26000,'pick'=>'Ayam Geprek Sambal Korek','drop'=>'Klampok, Cirebon','customer'=>'Rina Dewi'],
    ['id'=>1004,'type'=>'🛍️ '.jajap_service_name('mart',$pdo instanceof PDO ? $pdo : null).' (Belanja)','fare'=>42000,'pick'=>'Toko Sembako Jaya','drop'=>'Bandorasa Kulon','customer'=>'Hendra']
];
$demoOrder = $sampleOrders[$driverId % count($sampleOrders)];

$assignedOrder = $realOrder ? [
    'id'=>(int)$realOrder['id'],
    'type'=>(($realOrder['order_type']??'food')==='bike'?'🛵 '.jajap_service_name('bike',$pdo instanceof PDO ? $pdo : null).' (Motor)':(($realOrder['order_type']??'food')==='car'?'🚗 '.jajap_service_name('car',$pdo instanceof PDO ? $pdo : null).' (Mobil)':(($realOrder['order_type']??'food')==='mart'?'🛍️ '.jajap_service_name('mart',$pdo instanceof PDO ? $pdo : null).' (Belanja)':'🍜 '.jajap_service_name('food',$pdo instanceof PDO ? $pdo : null).' (Kuliner)'))),
    'fare'=>(float)($realOrder['driver_earning'] ?: $realOrder['delivery_fee'] ?: $realOrder['total_price']),
    'pick'=>$realOrder['pickup_address'] ?: 'Lokasi Jemput',
    'drop'=>$realOrder['dropoff_address'] ?: 'Lokasi Tujuan',
    'customer'=>$realOrder['customer_name'] ?: 'Pengguna JAJAP',
    'real'=>true,
    'status'=>$realOrder['status']
] : array_merge($demoOrder,['real'=>false,'status'=>'demo']);

// Today's real earnings/count for this driver.
$todayEarning = 0; $todayCount = 0;
if ($pdo instanceof PDO) {
    try {
        $st = $pdo->prepare("SELECT COALESCE(SUM(driver_earning),0), COUNT(*) FROM orders WHERE driver_id=? AND status='completed' AND DATE(created_at)=CURDATE()");
        $st->execute([$driverId]);
        [$todayEarning,$todayCount] = $st->fetch(PDO::FETCH_NUM) ?: [0,0];
    } catch (Throwable $ignore) {}
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>JAJAP — Dashboard Driver</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
:root{--green:#00a86b;--green-dark:#08794f;--green-soft:#e9f8f1;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#ffffff;--line:#e2ece7}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}

.mobileContainer{width:100%;max-width:100%;min-height:100vh;margin:20px auto;background:var(--bg);position:relative;padding-bottom:30px;box-shadow:0 0 40px rgba(0,0,0,.2);overflow:hidden;border-radius:28px;border:1px solid #c2ceca}

.driverHeader{background:#111815;color:#fff;padding:14px 16px;display:flex;justify-content:space-between;align-items:center}
.driverHeader h1{font-size:14px;margin:0;font-weight:900}

.content{padding:14px}
.incomeCard{background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;padding:16px;border-radius:18px;margin-bottom:14px;box-shadow:0 4px 14px rgba(0,168,107,.2)}
.incomeRow{display:flex;justify-content:space-between;align-items:flex-end}

.statusToggle{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}

#driverMap{width:100%;height:150px;border-radius:16px;border:1px solid var(--line);margin-bottom:14px}

.orderCard{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,.02)}
.orderType{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}

.btnAccept{width:100%;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;border:0;padding:14px;border-radius:12px;font-weight:900;font-size:13px;cursor:pointer;margin-top:10px}
.msgBox{background:#e9f8f1;color:var(--green-dark);padding:10px;border-radius:10px;font-size:11px;font-weight:800;margin-bottom:12px;text-align:center}

.logoutBtn{display:block;text-align:center;color:#ef4f5f;font-size:11px;font-weight:800;text-decoration:none;margin-top:20px}

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow-x: hidden;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh; /* Dynamic Viewport Height for mobile browsers */
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    overflow-y: auto; /* PERMOHONAN: BISA DI SCROLL DARI ATAS KE BAWAH / BAWAH KE ATAS */
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    box-sizing: border-box;
    padding-bottom: 90px; /* Space for fixed bottomNav */
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px; /* Standard iPhone / Android height on desktop view */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}


/* FIKSASI UKURAN HP & BOTTOM NAVIGATION MENETAP DI BAWAH */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden; /* Mencegah seluruh layar web di luar HP ikut ter-scroll */
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden; /* Area luar dikunci */
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 780px; /* Ukuran tinggi HP ideal agar tidak terlalu panjang */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

/* MENETAPKAN BOTTOM NAV DI BAWAH TIGHT & TIDAK IKUT SCROLL */
.bottomNav {
    position: relative !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 62px !important;
    min-height: 62px !important;
    background: rgba(255,255,255,0.98) !important;
    border-top: 1px solid var(--line, #e2ece7) !important;
    display: grid !important;
    grid-template-columns: repeat(4, 1fr) !important;
    z-index: 9999 !important;
    box-shadow: 0 -4px 12px rgba(0,0,0,0.05) !important;
    flex-shrink: 0 !important;
}

/* AREA KONTEN UTAMA YANG BISA DI-SCROLL BERADA DI ANTARA HEADER & BOTTOM NAV */
.scrollableMainContent {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 20px;
}


/* DARK MODE ENGINE GLOBAL */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #9aa8a1 !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}
body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}
body.dark-mode .bottomNav {
    background: rgba(30, 38, 35, 0.98) !important;
    border-top-color: var(--line) !important;
}
body.dark-mode .navTab {
    color: var(--muted) !important;
}
body.dark-mode .navTab.active {
    color: #00d084 !important;
}
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #fff !important;
    border-color: var(--line) !important;
}


/* ENHANCED DARK MODE & LAYOUT UNIFORMITY FIX */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden !important;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow: hidden !important;
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px !important; /* DISAMAKAN PERSIS DENGAN INDEX.PHP (844px) */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

.scrollableMainContent {
    flex: 1 !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch;
}

/* DARK MODE CONTRAST FIXES */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #a0b2aa !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}

body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}

body.dark-mode .welcomeText h2,
body.dark-mode .welcomeText p,
body.dark-mode .brandTitle,
body.dark-mode label,
body.dark-mode b,
body.dark-mode span,
body.dark-mode h1, body.dark-mode h2, body.dark-mode h3 {
    color: #e8ecea !important;
}

/* FIX KHUSUS TOMBOL MODE TAMU (.btnGuest) DI TEMA GELAP */
body.dark-mode .btnGuest {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

/* FIX KHUSUS BANNER MODE TAMU DI INDEX.PHP */
body.dark-mode .guestBanner {
    background: #2a2518 !important;
    border-color: #483d22 !important;
    color: #ffc107 !important;
}

/* FIX KHUSUS INPUT & SELECT DI TEMA GELAP */
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

body.dark-mode input::placeholder {
    color: #889890 !important;
}


/* ===== JAJAP CUSTOMER UNIFIED APP FRAME =====
   Satu sistem frame untuk seluruh halaman customer.
   Frame selalu setinggi viewport, konten panjang scroll di dalam frame,
   dan tidak ada aturan 780/844px yang dapat membuat frame terpotong.
*/
html, body {
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  overflow: hidden !important;
  background: #d0d8d4 !important;
}

.mobileContainer {
  width: 100% !important;
  max-width: 414px !important;
  height: 100dvh !important;
  min-height: 0 !important;
  margin: 0 auto !important;
  padding: 0 !important;
  box-sizing: border-box !important;
  position: relative !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  border-radius: 36px !important;
  border: 1px solid #c2ceca !important;
  box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
}

.scrollableMainContent {
  flex: 1 1 auto !important;
  min-height: 0 !important;
  width: 100% !important;
  max-width: 100% !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  -webkit-overflow-scrolling: touch !important;
  box-sizing: border-box !important;
}

/* Semua navigasi bawah berada di dalam frame dan terbagi rata. */
.bottomNav {
  flex: 0 0 auto !important;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  z-index: 9999 !important;
}

/* Desktop/tablet: tetap ada jarak luar seperti desain Profil. */
@media (min-width: 415px) {
  .mobileContainer {
    height: calc(100dvh - 40px) !important;
    min-height: 0 !important;
    margin: 20px auto !important;
    border-radius: 36px !important;
  }
}

/* Mobile: frame memenuhi tinggi viewport tanpa menjadi 780/844px. */
@media (max-width: 414px) {
  .mobileContainer {
    height: 100dvh !important;
    min-height: 0 !important;
    margin: 0 auto !important;
    border-radius: 36px !important;
  }
}


/* ===== JAJAP UNIVERSAL MOBILE VIEWPORT FRAME v3 ===== */
html, body {
  margin: 0 !important;
  width: 100% !important;
  min-height: 100% !important;
}
body {
  background: #d0d8d4 !important;
  overflow: hidden !important;
}
.mobileContainer {
  position: fixed !important;
  inset: 0 auto 0 50% !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  height: auto !important;
  min-height: 0 !important;
  margin: 0 !important;
  padding-bottom: 0 !important;
  box-sizing: border-box !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  -webkit-overflow-scrolling: touch !important;
  border-radius: 0 !important;
  border: 0 !important;
}
/* The app shell itself stays phone-sized on larger screens. */
@media (min-width: 415px) {
  .mobileContainer {
    width: 414px !important;
    max-width: 414px !important;
    border-radius: 28px !important;
    border: 1px solid #c2ceca !important;
    box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
  }
}
/* Bottom navigation belongs to the phone viewport, never to the page scroll. */
.mobileContainer > .bottomNav,
.bottomNav {
  position: fixed !important;
  left: 50% !important;
  right: auto !important;
  bottom: 0 !important;
  top: auto !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  margin: 0 !important;
  z-index: 9999 !important;
  flex-shrink: 0 !important;
}
@media (min-width: 415px) {
  .mobileContainer > .bottomNav,
  .bottomNav {
    width: 414px !important;
    max-width: 414px !important;
  }
}
/* Keep normal content clear of the fixed bottom navigation. */
.mobileContainer {
  scroll-padding-bottom: 72px !important;
}
/* Home/header card should not expose the shell background while scrolling. */
.appHeader {
  position: sticky !important;
  top: 0 !important;
  z-index: 200 !important;
  overflow: hidden !important;
}
/* When a map/full-screen view is open, hide customer navigation. */
.mobileContainer.map-open .bottomNav,
.mobileContainer:has(#mapView.map-open) .bottomNav,
body.map-open .bottomNav,
body.maps-open .bottomNav {
  display: none !important;
}


/* FINAL PHONE FULL-SCREEN FRAME FIX v4 */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#d0d8d4 !important;
}
.mobileContainer {
  position:fixed !important;
  inset:0 !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
}
.mobileContainer > .scrollableMainContent {
  width:100% !important;
  max-width:none !important;
  min-width:0 !important;
  box-sizing:border-box !important;
}
.mobileContainer > .bottomNav, .bottomNav {
  position:fixed !important;
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  top:auto !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  margin:0 !important;
  z-index:99999 !important;
}
/* On a computer/laptop, preserve the phone-like width and height instead of desktop layout. */
@media (min-width:415px) {
  .mobileContainer {
    position:fixed !important;
    top:50% !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translate(-50%,-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:844px !important;
    min-height:844px !important;
    border:1px solid #c2ceca !important;
    border-radius:36px !important;
    box-shadow:0 0 40px rgba(0,0,0,.20) !important;
  }
  .mobileContainer > .bottomNav, .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}
@media (max-width:414px) {
  .mobileContainer {
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    border-radius:0 !important;
  }
}

</style>
<style>
/* ===== JAJAP FINAL FULL-SCREEN APP FRAME v5 =====
   Phone: application fills the real viewport.
   Desktop/laptop: keep a phone-width application, but use the full available height.
   No fixed 780px/844px frame height and no half-height centered card. */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  min-height:100% !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow:hidden !important;
}

html { background:#d0d8d4 !important; }

body {
  width:100% !important;
  min-height:100dvh !important;
  background:#d0d8d4 !important;
}

.mobileContainer, .box {
  position:fixed !important;
  inset:0 !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding-bottom:0 !important;
  box-sizing:border-box !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
}

/* Keep the application phone-sized on larger computer/laptop screens. */
@media (min-width:415px) {
  .mobileContainer, .box {
    top:0 !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translateX(-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:100dvh !important;
    min-height:100dvh !important;
    margin:0 !important;
    border:0 !important;
    border-radius:0 !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer, .box {
    left:0 !important;
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    transform:none !important;
    border-radius:0 !important;
  }
}

/* Bottom navigation stays attached to the visible app viewport. */
.mobileContainer > .bottomNav,
.mobileContainer .bottomNav,
.box > .bottomNav,
.box .bottomNav {
  position:fixed !important;
  top:auto !important;
  bottom:0 !important;
  z-index:99999 !important;
}

@media (min-width:415px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:0 !important;
    right:0 !important;
    width:100vw !important;
    max-width:none !important;
    transform:none !important;
  }
}
</style>

<style>
/* JAJAP UNIVERSAL APP FRAME v6 - one frame for every page */
html,body{width:100%;min-width:0;height:100%;min-height:100%;margin:0;padding:0;box-sizing:border-box;overflow:hidden}
html{background:#d0d8d4}
body{background:#d0d8d4;min-height:100dvh}
.mobileContainer,.box{
  position:fixed !important;
  top:0 !important;left:0 !important;right:auto !important;bottom:auto !important;
  width:100vw !important;max-width:none !important;
  height:100dvh !important;min-height:100dvh !important;
  margin:0 !important;box-sizing:border-box !important;
  border-radius:0 !important;border:0 !important;box-shadow:none !important;
  overflow:hidden !important;
}
/* Main pages use a single internal scrolling region; the frame itself never becomes a short card. */
.mobileContainer > .scrollableMainContent,
.mobileContainer > .scroll,
.mobileContainer > main.content,
.box > .scrollableMainContent{
  flex:1 1 auto !important;min-height:0 !important;
  overflow-y:auto !important;overflow-x:hidden !important;
  -webkit-overflow-scrolling:touch !important;
}
/* Form/landing pages without a dedicated content scroller can scroll inside the frame. */
.mobileContainer:has(> .logoBox),
.mobileContainer:has(> .welcomeText),
.box{overflow-y:auto !important;overflow-x:hidden !important;-webkit-overflow-scrolling:touch !important}
/* Keep bottom navigation pinned to the bottom of the app frame. */
.mobileContainer > .bottomNav,.box > .bottomNav{
  flex-shrink:0 !important;z-index:110 !important;
}
/* Full-screen maps must own the whole app viewport; page navigation is hidden while maps are open by existing JS/classes. */
#fullMapOverlay{position:fixed !important;inset:0 !important;width:100vw !important;height:100dvh !important;max-width:none !important;max-height:none !important;margin:0 !important;z-index:5000 !important}
/* Phones/tablets: truly edge-to-edge. A breakpoint above 414 prevents narrow mobile browsers from showing side gutters. */
@media (max-width:600px){
  .mobileContainer,.box{width:100vw !important;max-width:none !important;left:0 !important;transform:none !important}
  html,body{background:var(--bg,#f4f6f5) !important}
}
/* Computer/laptop: retain the phone-width application, centered, but use the full browser viewport height. */
@media (min-width:601px){
  .mobileContainer,.box{
    left:50% !important;right:auto !important;transform:translateX(-50%) !important;
    width:414px !important;max-width:414px !important;
    height:100dvh !important;min-height:100dvh !important;
    border-radius:28px !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

</style>
  <link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body><div class="app-container">

<div class="mobileContainer">
    <header class="driverHeader">
        <div style="display:flex;align-items:center;gap:8px">
            <div style="width:28px;height:28px;background:var(--green);border-radius:50%;display:grid;place-items:center;font-weight:900;font-size:12px">
                <?=strtoupper(substr($driverName,0,1))?>
            </div>
            <div>
                <b style="font-size:12px;display:block"><?=htmlspecialchars($driverName)?></b>
                <span style="font-size:9px;opacity:.7">Mitra Driver JAJAP</span>
            </div>
        </div>

    </header>

    <div style="background:#e9f8f1;border:1px solid #bfe8d5;padding:10px;border-radius:12px;margin-bottom:12px;font-size:10px;color:#08794f;font-weight:800">📝 Ingin jadi driver JAJAP? <a href="daftar_driver.php" style="color:#08794f">Daftar Ojek / Mobil →</a></div>
<main class="content">
        <?php if($msg): ?><div class="msgBox"><?=$msg?></div><?php endif; ?>

        <div class="incomeCard">
            <div class="incomeRow">
                <div>
                    <span style="font-size:10px;opacity:.9">Pendapatan Hari Ini</span>
                    <b style="font-size:20px;display:block">Rp <?=number_format((float)$todayEarning,0,",",".")?></b>
                </div>
                <div style="text-align:right">
                    <span style="font-size:10px;opacity:.9">Selesai</span>
                    <b style="font-size:14px;display:block"><?= (int)$todayCount ?> Order</b>
                </div>
            </div>
        </div>

        <div class="statusToggle">
            <div>
                <b style="font-size:11px;display:block">Status Layanan</b>
                <small style="font-size:9px;color:var(--muted)">Siap Menerima Orderan</small>
            </div>
            <span style="background:var(--green-soft);color:var(--green-dark);padding:4px 10px;border-radius:12px;font-size:10px;font-weight:800">🟢 ONLINE</span>
        </div>

        <div id="driverMap"></div>

        <div style="font-size:11px;font-weight:800;color:var(--muted);margin-bottom:8px"><?= $assignedOrder['real'] ? '📦 Orderan yang Ditugaskan ke Anda:' : '🎲 Contoh Orderan Driver:' ?></div>

        <div class="orderCard">
            <div class="orderType">
                <span style="font-size:11px;font-weight:800;background:var(--green-soft);color:var(--green-dark);padding:3px 8px;border-radius:8px">
                    <?=$assignedOrder['type']?>
                </span>
                <b style="font-size:13px;color:var(--green-dark)">Rp <?=number_format($assignedOrder['fare'],0,',','.')?></b>
            </div>

            <div style="font-size:11px;line-height:1.6;margin-bottom:10px">
                <div>📍 <b>Jemput:</b> <?=htmlspecialchars($assignedOrder['pick'])?></div>
                <div>🎯 <b>Tujuan:</b> <?=htmlspecialchars($assignedOrder['drop'])?></div>
                <div>👤 <b>Pemesan:</b> <?=htmlspecialchars($assignedOrder['customer'])?></div>
            </div>

            <form method="POST">
                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                <?php if ($assignedOrder['real'] && $assignedOrder['status'] === 'pending'): ?>
                    <input type="hidden" name="accept_order" value="1">
                    <input type="hidden" name="order_id" value="<?= (int)$assignedOrder['id'] ?>">
                    <button type="submit" class="btnAccept">Terima & Ambil Orderan Ini</button>
                <?php elseif ($assignedOrder['real']): ?>
                    <button type="button" class="btnAccept" disabled>Order Sudah <?= htmlspecialchars(strtoupper($assignedOrder['status'])) ?></button>
                <?php else: ?>
                    <button type="button" class="btnAccept" onclick="alert('Mode simulasi: belum ada order database yang ditugaskan ke driver ini.')">Simulasi Terima Orderan</button>
                <?php endif; ?>
            </form>
            <?php if($assignedOrder['real'] && in_array($assignedOrder['status'],['accepted','delivering'],true)): ?>
            <div class="actions" style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:8px">
                <?php if($assignedOrder['status']==='accepted'): ?>
                <form method="POST"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="update_order_status" value="1"><input type="hidden" name="order_id" value="<?=$assignedOrder['id']?>"><input type="hidden" name="new_status" value="delivering"><button class="btnAccept" type="submit">🚗 Mulai Antar</button></form>
                <?php else: ?>
                <form method="POST"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="update_order_status" value="1"><input type="hidden" name="order_id" value="<?=$assignedOrder['id']?>"><input type="hidden" name="new_status" value="completed"><button class="btnAccept" type="submit">✅ Selesaikan</button></form>
                <?php endif; ?>
                <form method="POST"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="update_order_status" value="1"><input type="hidden" name="order_id" value="<?=$assignedOrder['id']?>"><input type="hidden" name="new_status" value="cancelled"><button class="btnAccept" type="submit" style="background:#b4232f">Batalkan</button></form>
            </div>
            <?php endif; ?>
        </div>

        <a href="profil.php?logout=1" class="logoutBtn">🚪 Logout Akun Driver</a>
    </main>

    <nav class="bottomNav" aria-label="Navigasi utama JAJAP">
        <a href="driver.php" class="navTab active"><i>⌂</i>Beranda</a>
        <a href="aktivitas.php" class="navTab"><i>◷</i>Aktivitas</a>
        <a href="profil.php" class="navTab"><i>👤</i>Profil</a>
    </nav>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const map = L.map('driverMap', { zoomControl: false }).setView([-6.8794, 108.5098], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
    const marker=L.marker([-6.8794,108.5098]).addTo(map).bindPopup('Posisi Anda (Driver)');
    const csrf=<?=json_encode(csrf_token())?>;
    async function sendLocation(pos){
      const f=new FormData(); f.append('csrf',csrf);f.append('lat',pos.coords.latitude);f.append('lng',pos.coords.longitude);f.append('accuracy',pos.coords.accuracy||'');f.append('heading',pos.coords.heading??'');f.append('speed',pos.coords.speed??'');
      try{const r=await fetch('api.php?action=driver_location',{method:'POST',body:f,credentials:'same-origin'});const j=await r.json();if(j.ok){marker.setLatLng([pos.coords.latitude,pos.coords.longitude]);map.setView([pos.coords.latitude,pos.coords.longitude],15);}}catch(e){}
    }
    if(navigator.geolocation){navigator.geolocation.watchPosition(sendLocation,()=>{}, {enableHighAccuracy:true,maximumAge:5000,timeout:10000});}
});
</script>

<script>
(function(){
    const theme = localStorage.getItem('jajap_theme');
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
    }
})();
</script>

</div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body>
</html>

<style>
/* Driver navigation: only work-area routes. */
.bottomNav{display:flex !important;justify-content:space-around !important;align-items:stretch !important;width:100% !important;left:0 !important;right:0 !important;}
.bottomNav .navTab{flex:1 1 0 !important;min-width:0 !important;text-decoration:none !important;}
</style>

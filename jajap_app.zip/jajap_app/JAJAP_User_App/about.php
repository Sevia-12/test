<?php
session_start();
$role = $_SESSION['user']['role'] ?? 'user';
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JAJAP — About Us</title>
<script>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode-preload');})();</script>
<link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="theme.css">
<style>
.aboutPage{min-height:100vh;background:var(--bg-color);color:var(--text-color);padding-bottom:90px}
.aboutHeader{position:sticky;top:0;z-index:10;display:flex;align-items:center;gap:12px;padding:14px 18px;background:var(--card-bg);color:var(--text-color);border-bottom:1px solid var(--border-color)}
.aboutBack{display:inline-flex;align-items:center;justify-content:center;min-width:44px;min-height:44px;border:1px solid var(--border-color);border-radius:12px;background:var(--card-bg);color:var(--text-color);text-decoration:none;font-size:22px;font-weight:800}
.aboutHeader h1{margin:0;font-size:clamp(1.15rem,2.5vw,1.5rem)}
.aboutContent{width:100%;max-width:760px;margin:0 auto;padding:clamp(18px,4vw,32px)}
.aboutCard{background:var(--card-bg);color:var(--text-color);border:1px solid var(--border-color);border-radius:18px;padding:clamp(18px,3vw,28px);margin-bottom:16px}
.aboutCard h2{margin:0 0 8px;font-size:clamp(1rem,2vw,1.25rem)}
.aboutCard p,.aboutCard li{font-size:clamp(.9rem,1.4vw,1.05rem);line-height:1.65;color:var(--text-color)}
.aboutMeta{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}
.aboutMeta .meta{background:var(--input-bg);border:1px solid var(--border-color);border-radius:14px;padding:14px;color:var(--text-color)}
.aboutMeta strong{display:block;margin-bottom:4px}
</style>
<script>document.documentElement.classList.toggle('dark-mode',localStorage.getItem('jajap_theme')==='dark');</script>
<script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body>
<div class="app-container">
<main class="aboutPage">
<header class="aboutHeader"><a class="aboutBack" href="profil.php" aria-label="Kembali">‹</a><h1>About Us</h1></header>
<section class="aboutContent">
<div class="aboutCard"><h2>Tentang JAJAP</h2><p>JAJAP adalah aplikasi layanan lokal yang menghubungkan pengguna, driver, dan mitra untuk kebutuhan perjalanan, pengantaran, kuliner, serta sembako.</p></div>
<div class="aboutCard"><h2>Visi</h2><p>Menjadi platform layanan lokal yang mudah digunakan, aman, transparan, dan dapat diandalkan oleh masyarakat.</p></div>
<div class="aboutCard"><h2>Misi</h2><ul><li>Menghubungkan pengguna dan mitra melalui layanan yang praktis.</li><li>Mendukung proses pemesanan dan pengantaran secara jelas.</li><li>Memberikan pengalaman aplikasi yang nyaman bagi User, Driver, dan Admin.</li></ul></div>
<div class="aboutCard"><h2>Kontak Bantuan</h2><p>Untuk bantuan akun, pesanan, pembayaran, atau keamanan, gunakan kanal bantuan resmi yang tersedia di aplikasi atau hubungi pengelola JAJAP.</p></div>
<div class="aboutCard"><h2>Informasi Aplikasi</h2><div class="aboutMeta"><div class="meta"><strong>Nama</strong>JAJAP</div><div class="meta"><strong>Versi</strong>1.0.0</div><div class="meta"><strong>Peran</strong><?=htmlspecialchars(ucfirst($role),ENT_QUOTES,'UTF-8')?></div></div></div>
</section>
</main>
</div>
<script>document.body.classList.toggle('dark-mode',localStorage.getItem('jajap_theme')==='dark');</script>
</body></html>

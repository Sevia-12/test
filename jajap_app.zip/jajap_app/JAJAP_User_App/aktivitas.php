<?php
require_once __DIR__.'/config/services.php';
session_start();
require_once __DIR__.'/config/database.php';

$user = $_SESSION['user'] ?? ['id'=>0,'name'=>'Tamu / Guest','phone'=>'-','role'=>'guest'];
$isGuest = ($user['role'] ?? '') === 'guest' || !empty($_SESSION['guest']);
$isDriver = (($user['role'] ?? '') === 'driver');
$activities = [];

if (!$isGuest && ($pdo instanceof PDO) && !empty($user['id'])) {
    try {
        $st = $pdo->prepare("SELECT o.*, d.name AS driver_name FROM orders o LEFT JOIN users d ON d.id=o.driver_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 50");
        $st->execute([(int)$user['id']]);
        $activities = $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $ignore) {}
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Aktivitas — JAJAP</title>
<style>
:root{--green:#00a86b;--green-dark:#08794f;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#ffffff;--line:#e2ece7}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.mobileContainer{width:100%;max-width:100%;min-height:100vh;margin:20px auto;background:var(--bg);position:relative;padding-bottom:88px;box-shadow:0 0 40px rgba(0,0,0,.2);overflow:hidden;border-radius:28px;border:1px solid #c2ceca}
.pageHeader{background:var(--card);padding:16px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between}
.pageHeader h1{font-size:16px;margin:0;font-weight:900;color:var(--ink)}
.content{padding:16px}
.actCard{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.02)}
.bottomNav{position:absolute;bottom:0;left:0;width:100%;height:66px;background:rgba(255,255,255,.98);border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(4,1fr);z-index:110}
.navTab{border:0;background:transparent;color:var(--muted);font-size:9px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;text-decoration:none}
.navTab.active{color:var(--green-dark)}

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow-x: hidden;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh; /* Dynamic Viewport Height for mobile browsers */
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    overflow-y: auto; /* PERMOHONAN: BISA DI SCROLL DARI ATAS KE BAWAH / BAWAH KE ATAS */
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    box-sizing: border-box;
    padding-bottom: 90px; /* Space for fixed bottomNav */
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px; /* Standard iPhone / Android height on desktop view */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}


/* FIKSASI UKURAN HP & BOTTOM NAVIGATION MENETAP DI BAWAH */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden; /* Mencegah seluruh layar web di luar HP ikut ter-scroll */
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh;
    height: 100dvh;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden; /* Area luar dikunci */
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 780px; /* Ukuran tinggi HP ideal agar tidak terlalu panjang */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

/* MENETAPKAN BOTTOM NAV DI BAWAH TIGHT & TIDAK IKUT SCROLL */
.bottomNav {
    position: relative !important;
    bottom: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 62px !important;
    min-height: 62px !important;
    background: rgba(255,255,255,0.98) !important;
    border-top: 1px solid var(--line, #e2ece7) !important;
    display: grid !important;
    grid-template-columns: repeat(4, 1fr) !important;
    z-index: 9999 !important;
    box-shadow: 0 -4px 12px rgba(0,0,0,0.05) !important;
    flex-shrink: 0 !important;
}

/* AREA KONTEN UTAMA YANG BISA DI-SCROLL BERADA DI ANTARA HEADER & BOTTOM NAV */
.scrollableMainContent {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 20px;
}


/* DARK MODE ENGINE GLOBAL */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #9aa8a1 !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}
body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}
body.dark-mode .bottomNav {
    background: rgba(30, 38, 35, 0.98) !important;
    border-top-color: var(--line) !important;
}
body.dark-mode .navTab {
    color: var(--muted) !important;
}
body.dark-mode .navTab.active {
    color: #00d084 !important;
}
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #fff !important;
    border-color: var(--line) !important;
}


/* ENHANCED DARK MODE & LAYOUT UNIFORMITY FIX */
html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    background: #d0d8d4;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif;
    overflow: hidden !important;
}

.mobileContainer {
    width: 100%;
    max-width: 414px;
    height: 100vh !important;
    height: 100dvh !important;
    margin: 0 auto;
    background: var(--bg, #f4f6f5);
    position: relative;
    box-shadow: 0 0 40px rgba(0,0,0,.2);
    display: flex !important;
    flex-direction: column !important;
    justify-content: space-between !important;
    overflow: hidden !important;
    box-sizing: border-box;
}

@media (min-width: 415px) {
    .mobileContainer {
        height: 844px !important; /* DISAMAKAN PERSIS DENGAN INDEX.PHP (844px) */
        margin: 20px auto;
        border-radius: 36px;
        border: 1px solid #c2ceca;
    }
}

.scrollableMainContent {
    flex: 1 !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    -webkit-overflow-scrolling: touch;
}

/* DARK MODE CONTRAST FIXES */
body.dark-mode {
    --bg: #121816 !important;
    --card: #1e2623 !important;
    --ink: #e8ecea !important;
    --muted: #a0b2aa !important;
    --line: #2d3834 !important;
    --green-soft: #183329 !important;
}

body.dark-mode .mobileContainer {
    background: var(--bg, #121816) !important;
    border-color: #2a3531 !important;
}

body.dark-mode .welcomeText h2,
body.dark-mode .welcomeText p,
body.dark-mode .brandTitle,
body.dark-mode label,
body.dark-mode b,
body.dark-mode span,
body.dark-mode h1, body.dark-mode h2, body.dark-mode h3 {
    color: #e8ecea !important;
}

/* FIX KHUSUS TOMBOL MODE TAMU (.btnGuest) DI TEMA GELAP */
body.dark-mode .btnGuest {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

/* FIX KHUSUS BANNER MODE TAMU DI INDEX.PHP */
body.dark-mode .guestBanner {
    background: #2a2518 !important;
    border-color: #483d22 !important;
    color: #ffc107 !important;
}

/* FIX KHUSUS INPUT & SELECT DI TEMA GELAP */
body.dark-mode input, body.dark-mode select {
    background: #25302c !important;
    color: #ffffff !important;
    border-color: #384842 !important;
}

body.dark-mode input::placeholder {
    color: #889890 !important;
}


/* ===== JAJAP CUSTOMER UNIFIED APP FRAME =====
   Satu sistem frame untuk seluruh halaman customer.
   Frame selalu setinggi viewport, konten panjang scroll di dalam frame,
   dan tidak ada aturan 780/844px yang dapat membuat frame terpotong.
*/
html, body {
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  overflow: hidden !important;
  background: #d0d8d4 !important;
}

.mobileContainer {
  width: 100% !important;
  max-width: 414px !important;
  height: 100dvh !important;
  min-height: 0 !important;
  margin: 0 auto !important;
  padding: 0 !important;
  box-sizing: border-box !important;
  position: relative !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  border-radius: 36px !important;
  border: 1px solid #c2ceca !important;
  box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
}

.scrollableMainContent {
  flex: 1 1 auto !important;
  min-height: 0 !important;
  width: 100% !important;
  max-width: 100% !important;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  -webkit-overflow-scrolling: touch !important;
  box-sizing: border-box !important;
}

/* Semua navigasi bawah berada di dalam frame dan terbagi rata. */
.bottomNav {
  flex: 0 0 auto !important;
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  z-index: 9999 !important;
}

/* Desktop/tablet: tetap ada jarak luar seperti desain Profil. */
@media (min-width: 415px) {
  .mobileContainer {
    height: calc(100dvh - 40px) !important;
    min-height: 0 !important;
    margin: 20px auto !important;
    border-radius: 36px !important;
  }
}

/* Mobile: frame memenuhi tinggi viewport tanpa menjadi 780/844px. */
@media (max-width: 414px) {
  .mobileContainer {
    height: 100dvh !important;
    min-height: 0 !important;
    margin: 0 auto !important;
    border-radius: 36px !important;
  }
}


/* ===== JAJAP UNIVERSAL MOBILE VIEWPORT FRAME v3 ===== */
html, body {
  margin: 0 !important;
  width: 100% !important;
  min-height: 100% !important;
}
body {
  background: #d0d8d4 !important;
  overflow: hidden !important;
}
.mobileContainer {
  position: fixed !important;
  inset: 0 auto 0 50% !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  height: auto !important;
  min-height: 0 !important;
  margin: 0 !important;
  padding-bottom: 0 !important;
  box-sizing: border-box !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  -webkit-overflow-scrolling: touch !important;
  border-radius: 0 !important;
  border: 0 !important;
}
/* The app shell itself stays phone-sized on larger screens. */
@media (min-width: 415px) {
  .mobileContainer {
    width: 414px !important;
    max-width: 414px !important;
    border-radius: 28px !important;
    border: 1px solid #c2ceca !important;
    box-shadow: 0 0 40px rgba(0,0,0,.20) !important;
  }
}
/* Bottom navigation belongs to the phone viewport, never to the page scroll. */
.mobileContainer > .bottomNav,
.bottomNav {
  position: fixed !important;
  left: 50% !important;
  right: auto !important;
  bottom: 0 !important;
  top: auto !important;
  transform: translateX(-50%) !important;
  width: min(100vw, 414px) !important;
  max-width: 414px !important;
  margin: 0 !important;
  z-index: 9999 !important;
  flex-shrink: 0 !important;
}
@media (min-width: 415px) {
  .mobileContainer > .bottomNav,
  .bottomNav {
    width: 414px !important;
    max-width: 414px !important;
  }
}
/* Keep normal content clear of the fixed bottom navigation. */
.mobileContainer {
  scroll-padding-bottom: 72px !important;
}
/* Home/header card should not expose the shell background while scrolling. */
.appHeader {
  position: sticky !important;
  top: 0 !important;
  z-index: 200 !important;
  overflow: hidden !important;
}
/* When a map/full-screen view is open, hide customer navigation. */
.mobileContainer.map-open .bottomNav,
.mobileContainer:has(#mapView.map-open) .bottomNav,
body.map-open .bottomNav,
body.maps-open .bottomNav {
  display: none !important;
}


/* FINAL PHONE FULL-SCREEN FRAME FIX v4 */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#d0d8d4 !important;
}
.mobileContainer {
  position:fixed !important;
  inset:0 !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
}
.mobileContainer > .scrollableMainContent {
  width:100% !important;
  max-width:none !important;
  min-width:0 !important;
  box-sizing:border-box !important;
}
.mobileContainer > .bottomNav, .bottomNav {
  position:fixed !important;
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  top:auto !important;
  transform:none !important;
  width:100vw !important;
  max-width:none !important;
  margin:0 !important;
  z-index:99999 !important;
}
/* On a computer/laptop, preserve the phone-like width and height instead of desktop layout. */
@media (min-width:415px) {
  .mobileContainer {
    position:fixed !important;
    top:50% !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translate(-50%,-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:844px !important;
    min-height:844px !important;
    border:1px solid #c2ceca !important;
    border-radius:36px !important;
    box-shadow:0 0 40px rgba(0,0,0,.20) !important;
  }
  .mobileContainer > .bottomNav, .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}
@media (max-width:414px) {
  .mobileContainer {
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    border-radius:0 !important;
  }
}

</style>
<style>
/* ===== JAJAP FINAL FULL-SCREEN APP FRAME v5 =====
   Phone: application fills the real viewport.
   Desktop/laptop: keep a phone-width application, but use the full available height.
   No fixed 780px/844px frame height and no half-height centered card. */
html, body {
  width:100% !important;
  min-width:0 !important;
  height:100% !important;
  min-height:100% !important;
  margin:0 !important;
  padding:0 !important;
  box-sizing:border-box !important;
  overflow:hidden !important;
}

html { background:#d0d8d4 !important; }

body {
  width:100% !important;
  min-height:100dvh !important;
  background:#d0d8d4 !important;
}

.mobileContainer, .box {
  position:fixed !important;
  inset:0 !important;
  width:100vw !important;
  max-width:none !important;
  height:100dvh !important;
  min-height:100dvh !important;
  margin:0 !important;
  padding-bottom:0 !important;
  box-sizing:border-box !important;
  border:0 !important;
  border-radius:0 !important;
  box-shadow:none !important;
  overflow-x:hidden !important;
  overflow-y:auto !important;
  -webkit-overflow-scrolling:touch !important;
}

/* Keep the application phone-sized on larger computer/laptop screens. */
@media (min-width:415px) {
  .mobileContainer, .box {
    top:0 !important;
    left:50% !important;
    right:auto !important;
    bottom:auto !important;
    transform:translateX(-50%) !important;
    width:414px !important;
    max-width:414px !important;
    height:100dvh !important;
    min-height:100dvh !important;
    margin:0 !important;
    border:0 !important;
    border-radius:0 !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer, .box {
    left:0 !important;
    width:100vw !important;
    max-width:none !important;
    height:100dvh !important;
    min-height:100dvh !important;
    transform:none !important;
    border-radius:0 !important;
  }
}

/* Bottom navigation stays attached to the visible app viewport. */
.mobileContainer > .bottomNav,
.mobileContainer .bottomNav,
.box > .bottomNav,
.box .bottomNav {
  position:fixed !important;
  top:auto !important;
  bottom:0 !important;
  z-index:99999 !important;
}

@media (min-width:415px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:50% !important;
    right:auto !important;
    width:414px !important;
    max-width:414px !important;
    transform:translateX(-50%) !important;
  }
}

@media (max-width:414px) {
  .mobileContainer > .bottomNav,
  .mobileContainer .bottomNav,
  .box > .bottomNav,
  .box .bottomNav {
    left:0 !important;
    right:0 !important;
    width:100vw !important;
    max-width:none !important;
    transform:none !important;
  }
}
</style>

<style>
/* JAJAP UNIVERSAL APP FRAME v6 - one frame for every page */
html,body{width:100%;min-width:0;height:100%;min-height:100%;margin:0;padding:0;box-sizing:border-box;overflow:hidden}
html{background:#d0d8d4}
body{background:#d0d8d4;min-height:100dvh}
.mobileContainer,.box{
  position:fixed !important;
  top:0 !important;left:0 !important;right:auto !important;bottom:auto !important;
  width:100vw !important;max-width:none !important;
  height:100dvh !important;min-height:100dvh !important;
  margin:0 !important;box-sizing:border-box !important;
  border-radius:0 !important;border:0 !important;box-shadow:none !important;
  overflow:hidden !important;
}
/* Main pages use a single internal scrolling region; the frame itself never becomes a short card. */
.mobileContainer > .scrollableMainContent,
.mobileContainer > .scroll,
.mobileContainer > main.content,
.box > .scrollableMainContent{
  flex:1 1 auto !important;min-height:0 !important;
  overflow-y:auto !important;overflow-x:hidden !important;
  -webkit-overflow-scrolling:touch !important;
}
/* Form/landing pages without a dedicated content scroller can scroll inside the frame. */
.mobileContainer:has(> .logoBox),
.mobileContainer:has(> .welcomeText),
.box{overflow-y:auto !important;overflow-x:hidden !important;-webkit-overflow-scrolling:touch !important}
/* Keep bottom navigation pinned to the bottom of the app frame. */
.mobileContainer > .bottomNav,.box > .bottomNav{
  flex-shrink:0 !important;z-index:110 !important;
}
/* Full-screen maps must own the whole app viewport; page navigation is hidden while maps are open by existing JS/classes. */
#fullMapOverlay{position:fixed !important;inset:0 !important;width:100vw !important;height:100dvh !important;max-width:none !important;max-height:none !important;margin:0 !important;z-index:5000 !important}
/* Phones/tablets: truly edge-to-edge. A breakpoint above 414 prevents narrow mobile browsers from showing side gutters. */
@media (max-width:600px){
  .mobileContainer,.box{width:100vw !important;max-width:none !important;left:0 !important;transform:none !important}
  html,body{background:var(--bg,#f4f6f5) !important}
}
/* Computer/laptop: retain the phone-width application, centered, but use the full browser viewport height. */
@media (min-width:601px){
  .mobileContainer,.box{
    left:50% !important;right:auto !important;transform:translateX(-50%) !important;
    width:414px !important;max-width:414px !important;
    height:100dvh !important;min-height:100dvh !important;
    border-radius:28px !important;
    box-shadow:0 0 40px rgba(0,0,0,.18) !important;
  }
}

</style>
  <link rel="stylesheet" href="app-frame.css">
<link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head>
<body><div class="app-container">
<div class="mobileContainer">
    <div class="scrollableMainContent">
    <header class="pageHeader">
        <div style="width:20px"></div>
        <h1>Aktivitas Saya</h1>
        <div style="width:20px"></div>
    </header>
    <main class="content">
        <?php if (!$activities): ?>
            <div class="actCard" style="text-align:center;color:var(--muted);font-size:11px">
                <?= $isGuest ? 'Masuk ke akun untuk melihat aktivitas pesanan Anda.' : 'Belum ada aktivitas pesanan.' ?>
            </div>
        <?php else: foreach ($activities as $a):
            $type = strtolower((string)($a['order_type'] ?? 'food'));
            $icon = $type==='bike' ? '🛵' : ($type==='car' ? '🚗' : ($type==='mart' ? '🛍️' : '🍜'));
            $label = $type==='bike' ? 'Perjalanan '.jajap_service_name('bike',$pdo instanceof PDO ? $pdo : null) : ($type==='car' ? 'Perjalanan '.jajap_service_name('car',$pdo instanceof PDO ? $pdo : null) : ($type==='mart' ? 'Pesanan '.jajap_service_name('mart',$pdo instanceof PDO ? $pdo : null) : 'Pesanan '.jajap_service_name('food',$pdo instanceof PDO ? $pdo : null)));
            $status = htmlspecialchars((string)($a['status'] ?? 'pending'));
            $created = !empty($a['created_at']) ? date('d M Y • H:i', strtotime($a['created_at'])) : '-';
        ?>
        <div class="actCard">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;gap:8px">
                <b style="font-size:12px"><?= $icon ?> <?= $label ?></b>
                <span style="font-size:10px;color:var(--green-dark);background:#e9f8f1;padding:2px 8px;border-radius:12px;font-weight:800"><?= $status ?></span>
            </div>
            <div style="font-size:11px;color:var(--muted)"><?= htmlspecialchars($created) ?><?php if(!empty($a['dropoff_address'])): ?> • <?= htmlspecialchars($a['dropoff_address']) ?><?php endif; ?></div>
            <div style="font-size:12px;font-weight:800;color:var(--green-dark);margin-top:6px">Rp <?= number_format((float)($a['total_price'] ?? 0),0,',','.') ?></div>
            <div style="display:flex;gap:7px;margin-top:9px"><?php if(!in_array($a['status'],['completed','cancelled'],true)): ?><a href="tracking.php?order_id=<?=$a['id']?>" style="flex:1;text-align:center;background:#00a86b;color:#fff;padding:8px;border-radius:9px;text-decoration:none;font-size:10px;font-weight:900">📍 Lacak</a><?php endif; ?><a href="safety.php?order_id=<?=$a['id']?>" style="flex:1;text-align:center;background:#b4232f;color:#fff;padding:8px;border-radius:9px;text-decoration:none;font-size:10px;font-weight:900">🛡️ Keamanan</a></div>
        </div>
        <?php endforeach; endif; ?>
    </main>
        </div>
    <nav class="bottomNav">
        <a href="<?= $isDriver ? 'driver.php' : 'index.php' ?>" class="navTab"><i>⌂</i>Beranda</a>
        <?php if (!$isDriver): ?><a href="pesanan.php" class="navTab"><i>🛒</i>Pesanan</a><?php endif; ?>
        <a href="aktivitas.php" class="navTab active"><i>◷</i>Aktivitas</a>
        <a href="profil.php" class="navTab"><i>👤</i>Profil</a>
    </nav>
</div>

<script>
(function(){
    const theme = localStorage.getItem('jajap_theme');
    if (theme === 'dark') {
        document.body.classList.add('dark-mode');
    }
})();
</script>

</div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body>
</html>

<style>
.bottomNav{display:flex !important;justify-content:space-around !important;align-items:stretch !important;width:100% !important;left:0 !important;right:0 !important;}
.bottomNav .navTab{flex:1 1 0 !important;min-width:0 !important;text-decoration:none !important;}
</style>

<?php
require_once __DIR__.'/config/services.php';
require_once __DIR__.'/config/catalog.php';
session_start();
require_once __DIR__.'/config/database.php';

if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = ['id'=>2,'name'=>'Pengguna JAJAP','phone'=>'080000000002','role'=>'customer'];
}

$foods = jajap_catalog('food', $pdo instanceof PDO ? $pdo : null);
$marts = jajap_catalog('mart', $pdo instanceof PDO ? $pdo : null);
$type = strtolower($_GET['type'] ?? 'food');
$id = (int)($_GET['id'] ?? 0);


$catalog = $type === 'mart' ? $marts : $foods;
$selected = null;
foreach ($catalog as $item) { if ($item['id'] === $id) { $selected = $item; break; } }
if (!$selected) { header('Location: '.($type === 'mart' ? 'sembako.php' : 'kuliner.php')); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_to_cart'])) {
    $qty=max(1,(int)($_POST['quantity']??1));
    $variant=$_POST['variant']??($selected['variants'][0]??'Default');
    $notes=$_POST['notes']??'';
    if (!isset($_SESSION['cart'])) $_SESSION['cart']=[];
    $_SESSION['cart'][]=['id'=>$selected['id'],'name'=>$selected['name'],'price'=>$selected['price'],'qty'=>$qty,'variant'=>$variant,'notes'=>$notes,'type'=>jajap_service_name($type==='mart'?'mart':'food',$pdo instanceof PDO ? $pdo : null),'catalog_type'=>($type==='mart'?'mart':'food')];
    header('Location: pesanan.php'); exit;
}
if (!function_exists('e')) { function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');} }
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>JAJAP — Detail Pesanan</title><link rel="stylesheet" href="app-frame.css"><style>
:root{--green:#00a86b;--green-dark:#08794f;--green-soft:#e9f8f1;--ink:#1c2520;--muted:#6f7d76;--bg:#f4f6f5;--card:#fff;--line:#e2ece7}
html,body{margin:0;background:#d0d8d4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.mobileContainer{background:var(--bg);display:flex;flex-direction:column}
.detailScroll{flex:1;min-height:0;overflow-y:auto;padding:14px 14px 92px}
.detailHeader{display:flex;align-items:center;gap:10px;background:var(--card);padding:14px 16px;border-bottom:1px solid var(--line)}
.detailHeader a{text-decoration:none;color:var(--ink);font-size:22px;font-weight:900}
.detailHeader h1{font-size:15px;margin:0;font-weight:900}
.productHero{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:16px;display:flex;gap:14px;align-items:center;margin-bottom:12px}
.productIcon{width:76px;height:76px;border-radius:16px;background:var(--green-soft);display:grid;place-items:center;font-size:42px;flex-shrink:0}
.productHero h2{font-size:15px;margin:0 0 4px}.price{font-size:15px;font-weight:900;color:var(--green-dark);margin-bottom:5px}.desc{font-size:10px;color:var(--muted);line-height:1.5}
.box{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:12px}.label{font-size:10px;font-weight:900;color:var(--muted);margin-bottom:8px}.variants{display:flex;gap:7px;flex-wrap:wrap;position:relative;z-index:5;pointer-events:auto}.variant-btn{border:1px solid var(--line);background:#f8faf9;border-radius:10px;padding:8px 10px;font-size:10px;font-weight:800;cursor:pointer;pointer-events:auto;touch-action:manipulation;position:relative;z-index:10;-webkit-tap-highlight-color:transparent;transition:all 0.3s ease}.variant-btn:active{transform:scale(0.95)}.variant-btn.selected,.variant-btn.active{background:rgba(34,197,94,0.2);border:1px solid #22c55e;color:#4ade80}textarea{width:100%;min-height:76px;resize:vertical;border:1px solid var(--line);border-radius:10px;padding:10px;font:inherit;font-size:11px;box-sizing:border-box;background:#f8faf9}.qtyRow{display:flex;align-items:center;justify-content:space-between}.qty{display:flex;align-items:center;gap:16px;border:1px solid var(--line);border-radius:12px;padding:5px 8px;background:#f8faf9}.qty button{width:30px;height:30px;border:0;border-radius:9px;background:var(--green-soft);color:var(--green-dark);font-size:18px;font-weight:900;cursor:pointer;pointer-events:auto;touch-action:manipulation;position:relative;z-index:10;-webkit-tap-highlight-color:transparent}.qty b{min-width:18px;text-align:center;font-size:12px}.confirmBar{position:absolute;left:0;right:0;bottom:66px;background:var(--card);border-top:1px solid var(--line);padding:10px 14px;z-index:100}.confirmBar button{width:100%;border:0;border-radius:12px;padding:13px;background:linear-gradient(135deg,#00a86b,#08794f);color:#fff;font-size:12px;font-weight:900}
body.dark-mode{--bg:#121816;--card:#1e2623;--ink:#e8ecea;--muted:#a0b2aa;--line:#2d3834;--green-soft:#183329}body.dark-mode .mobileContainer{background:var(--bg)}body.dark-mode .variant-btn,body.dark-mode textarea,body.dark-mode .qty{background:#25302c;color:var(--ink);border-color:var(--line)}

/* Detail checkout cards must remain normal flow elements; app-frame.css uses .box for app shells. */
.detailScroll .box{position:relative!important;top:auto!important;left:auto!important;right:auto!important;bottom:auto!important;width:auto!important;max-width:none!important;height:auto!important;min-height:0!important;margin:0 0 12px!important;transform:none!important;overflow:visible!important;box-shadow:none!important;border-radius:16px!important;}
/* Checkout action is the only bottom action on this page; no bottom navigation. */
.confirmBar{position:absolute!important;left:0!important;right:0!important;bottom:0!important;height:auto!important;min-height:66px!important;padding:10px 14px!important;display:flex!important;align-items:center!important;background:var(--card)!important;border-top:1px solid var(--line)!important;z-index:99999!important;box-sizing:border-box!important;}
.detailScroll{padding-bottom:100px!important;}
body.dark-mode .confirmBar{background:#1e2623!important;border-top-color:#2d3834!important;}
</style><link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head><body><div class="app-container"><div class="mobileContainer"><header class="detailHeader"><a href="<?=e($type==='mart'?'sembako.php':'kuliner.php')?>">‹</a><h1>Detail Pesanan</h1></header><main class="detailScroll"><div class="productHero"><div class="productIcon"><?=e($selected['icon'])?></div><div><h2><?=e($selected['name'])?></h2><div class="price">Rp <?=number_format($selected['price'],0,',','.')?></div><div class="desc"><?=e($selected['desc'])?></div></div></div><form method="POST" id="orderForm"><input type="hidden" name="add_to_cart" value="1"><input type="hidden" name="item_id" value="<?=$selected['id']?>"><input type="hidden" name="variant" id="variantInput" value="<?=e($selected['variants'][0]??'Default')?>"><input type="hidden" name="quantity" id="qtyInput" value="1"><div class="box"><div class="label"><?= $type==='mart' ? 'PILIH UKURAN / KEMASAN' : 'PILIH VARIAN RASA / OPSIONAL' ?></div><div class="variants"><?php foreach($selected['variants'] as $i=>$v): ?><button type="button" class="variant-btn <?=$i===0?'selected active':''?>" aria-pressed="<?=$i===0?'true':'false'?>" data-value="<?=e($v)?>"><?=e($v)?></button><?php endforeach; ?></div></div><div class="box"><?php if($type!=='mart'): ?><div class="label">CATATAN KHUSUS (OPSIONAL)</div><textarea name="notes" placeholder="Contoh: Jangan terlalu pedas / tanpa kecap..."></textarea><?php else: ?><div class="label">CATATAN KHUSUS (OPSIONAL)</div><textarea name="notes" placeholder="Contoh: pilih barang yang masih segar..."></textarea><?php endif; ?></div><div class="box"><div class="qtyRow"><span style="font-size:12px;font-weight:900">Jumlah Pesanan</span><div class="qty"><button type="button" id="minus">−</button><b id="qtyDisp">1</b><button type="button" id="plus">+</button></div></div></div></form></main><div class="confirmBar"><button type="submit" form="orderForm" id="confirmBtn">Masukkan ke Keranjang — Rp <?=number_format($selected['price'],0,',','.')?></button></div></div><script>
document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  const basePrice = parseInt(<?=json_encode((int)$selected['price'])?>, 10) || 0;
  const variantButtons = document.querySelectorAll('.variant-btn');
  const variantInput = document.getElementById('variantInput');
  const qtyInput = document.getElementById('qtyInput');
  const qtyDisplay = document.getElementById('qtyDisp');
  const minusButton = document.getElementById('minus');
  const plusButton = document.getElementById('plus');
  const confirmButton = document.getElementById('confirmBtn');

  let quantity = parseInt(qtyInput ? qtyInput.value : '1', 10);
  if (Number.isNaN(quantity) || quantity < 1) quantity = 1;

  function updateTotal() {
    quantity = parseInt(quantity, 10);
    if (Number.isNaN(quantity) || quantity < 1) quantity = 1;

    const total = basePrice * quantity;

    if (qtyInput) qtyInput.value = String(quantity);
    if (qtyDisplay) qtyDisplay.textContent = String(quantity);
    if (confirmButton) {
      confirmButton.textContent = 'Masukkan ke Keranjang — Rp ' + total.toLocaleString('id-ID');
    }
  }

  // Varian: hanya satu pilihan yang aktif dalam satu waktu.
  variantButtons.forEach(function (button) {
    button.addEventListener('click', function (event) {
      event.preventDefault();

      variantButtons.forEach(function (item) {
        item.classList.remove('active');
        item.classList.remove('selected');
        item.setAttribute('aria-pressed', 'false');
      });

      this.classList.add('active');
      this.setAttribute('aria-pressed', 'true');

      if (variantInput) {
        variantInput.value = this.dataset.value || this.textContent.trim();
      }
    });
  });

  // Jumlah pesanan: minimum 1.
  if (minusButton) {
    minusButton.addEventListener('click', function (event) {
      event.preventDefault();
      quantity = parseInt(quantity, 10) || 1;
      quantity = Math.max(1, quantity - 1);
      updateTotal();
    });
  }

  if (plusButton) {
    plusButton.addEventListener('click', function (event) {
      event.preventDefault();
      quantity = parseInt(quantity, 10) || 1;
      quantity += 1;
      updateTotal();
    });
  }

  // Tetapkan varian pertama sebagai pilihan awal.
  if (variantButtons.length > 0) {
    variantButtons.forEach(function (item) {
      item.classList.remove('active');
      item.classList.remove('selected');
      item.setAttribute('aria-pressed', 'false');
    });
    variantButtons[0].classList.add('active');
    variantButtons[0].setAttribute('aria-pressed', 'true');
    if (variantInput) {
      variantInput.value = variantButtons[0].dataset.value || variantButtons[0].textContent.trim();
    }
  }

  updateTotal();

  if (localStorage.getItem('jajap_theme') === 'dark') {
    document.body.classList.add('dark-mode');
  }
});
</script></div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body></html>
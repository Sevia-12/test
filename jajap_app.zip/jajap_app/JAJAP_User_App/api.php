<?php
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/config/platform.php';
header('Content-Type: application/json; charset=utf-8');
function api_out(array $data,int $code=200){http_response_code($code);echo json_encode($data,JSON_UNESCAPED_UNICODE);exit;}
$user=$_SESSION['user']??null;
if(!$user) api_out(['ok'=>false,'message'=>'Login diperlukan.'],401);
if(!$pdo instanceof PDO) api_out(['ok'=>false,'message'=>'Database tidak tersedia.'],503);
$action=$_GET['action']??$_POST['action']??'';
if($_SERVER['REQUEST_METHOD']==='POST' && !csrf_check($_POST['csrf']??'')) api_out(['ok'=>false,'message'=>'CSRF tidak valid.'],419);
try{
  if($action==='driver_location'){
    if(($user['role']??'')!=='driver') api_out(['ok'=>false],403);
    $lat=(float)($_POST['lat']??0);$lng=(float)($_POST['lng']??0);
    if(abs($lat)>90||abs($lng)>180) api_out(['ok'=>false,'message'=>'Koordinat tidak valid.'],422);
    $st=$pdo->prepare("INSERT INTO driver_locations(driver_id,latitude,longitude,accuracy,heading,speed) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE latitude=VALUES(latitude),longitude=VALUES(longitude),accuracy=VALUES(accuracy),heading=VALUES(heading),speed=VALUES(speed)");
    $st->execute([(int)$user['id'],$lat,$lng,isset($_POST['accuracy'])?(float)$_POST['accuracy']:null,isset($_POST['heading'])?(float)$_POST['heading']:null,isset($_POST['speed'])?(float)$_POST['speed']:null]);
    api_out(['ok'=>true,'updated_at'=>date('c')]);
  }
  if($action==='order_status'){
    $id=(int)($_POST['order_id']??$_GET['order_id']??0);$status=$_POST['status']??'';
    if(!in_array($status,['accepted','delivering','completed','cancelled'],true)) api_out(['ok'=>false,'message'=>'Status tidak valid.'],422);
    $where=($user['role']??'')==='driver'?'driver_id=?':'user_id=?';
    $st=$pdo->prepare("SELECT * FROM orders WHERE id=? AND $where LIMIT 1");$st->execute([$id,(int)$user['id']]);$order=$st->fetch();
    if(!$order) api_out(['ok'=>false,'message'=>'Order tidak ditemukan.'],404);
    $allowed=['accepted'=>['delivering','cancelled'],'delivering'=>['completed','cancelled']];
    if($status==='accepted' && $user['role']==='driver') $ok=($order['status']==='pending');
    elseif($user['role']==='driver') $ok=in_array($status,$allowed[$order['status']]??[],true);
    else $ok=($status==='cancelled' && in_array($order['status'],['pending','accepted'],true));
    if(!$ok) api_out(['ok'=>false,'message'=>'Perubahan status tidak diizinkan.'],409);
    $fields="status=?,last_status_at=NOW()";$params=[$status];
    if($status==='accepted') $fields.=',assigned_at=COALESCE(assigned_at,NOW())';
    if($status==='completed') $fields.=',completed_at=NOW()';
    $params[]=$id;$params[]=(int)$user['id'];
    $pdo->prepare("UPDATE orders SET $fields WHERE id=? AND $where")->execute($params);
    $order['status']=$status;jajap_order_status_notify($pdo,$order,$status);
    api_out(['ok'=>true,'status'=>$status]);
  }
  if($action==='tracking'){
    $id=(int)($_GET['order_id']??0);$st=$pdo->prepare("SELECT o.id,o.status,o.order_type,o.pickup_address,o.dropoff_address,o.driver_id,d.name driver_name,d.vehicle_type,d.vehicle_plate,dl.latitude,dl.longitude,dl.accuracy,dl.updated_at FROM orders o LEFT JOIN users d ON d.id=o.driver_id LEFT JOIN driver_locations dl ON dl.driver_id=o.driver_id WHERE o.id=? AND o.user_id=? LIMIT 1");$st->execute([$id,(int)$user['id']]);$o=$st->fetch();if(!$o)api_out(['ok'=>false,'message'=>'Order tidak ditemukan.'],404);api_out(['ok'=>true,'order'=>$o]);
  }
  if($action==='notifications'){
    $st=$pdo->prepare("SELECT id,order_id,type,title,body,read_at,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 30");$st->execute([(int)$user['id']]);api_out(['ok'=>true,'items'=>$st->fetchAll()]);
  }
  if($action==='read_notification'){
    $id=(int)($_POST['id']??0);$st=$pdo->prepare('UPDATE notifications SET read_at=NOW() WHERE id=? AND user_id=?');$st->execute([$id,(int)$user['id']]);api_out(['ok'=>true]);
  }
  if($action==='safety'){
    if(($user['role']??'')!=='customer') api_out(['ok'=>false,'message'=>'Fitur keselamatan ini tersedia untuk pelanggan.'],403);
    $orderId=(int)($_POST['order_id']??0);$type=$_POST['type']??'incident';if(!in_array($type,['sos','incident','share_trip','support'],true))$type='incident';
    $driverId=null;if($orderId){$st=$pdo->prepare('SELECT driver_id FROM orders WHERE id=? AND user_id=?');$st->execute([$orderId,(int)$user['id']]);$driverId=$st->fetchColumn()?:null;}
    $msg=trim($_POST['message']??'');$st=$pdo->prepare('INSERT INTO safety_incidents(order_id,user_id,driver_id,type,message) VALUES(?,?,?,?,?)');$st->execute([$orderId?:null,(int)$user['id'],$driverId?:null,$type,$msg]);
    jajap_platform_notify($pdo,(int)$user['id'],'safety','Laporan keselamatan diterima','Laporan Anda telah tercatat. Hubungi layanan darurat setempat jika Anda berada dalam bahaya.', $orderId?:null);
    api_out(['ok'=>true,'message'=>'Laporan keselamatan tercatat.']);
  }
  api_out(['ok'=>false,'message'=>'Action tidak dikenali.'],404);
}catch(Throwable $e){api_out(['ok'=>false,'message'=>'Permintaan gagal diproses.'],500);}

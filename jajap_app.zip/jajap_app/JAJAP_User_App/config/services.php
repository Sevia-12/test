<?php
/**
 * JAJAP Service Catalog
 * Nama layanan adalah data terpusat di jajap_db.system_settings.
 * Admin Panel menulis ke tabel ini, User App hanya membaca.
 */
if (!function_exists('jajap_service_defaults')) {
    function jajap_service_defaults(): array {
        return [
            'service_bike_name' => 'JAJAPBike',
            'service_car_name'  => 'JAJAPCar',
            'service_food_name' => 'Kuliner',
            'service_mart_name' => 'Sembako',
            'service_send_name' => 'JAJAPSend',
        ];
    }
}
if (!function_exists('jajap_services')) {
    function jajap_services(?PDO $db = null): array {
        global $pdo;
        $db = $db instanceof PDO ? $db : $pdo;
        $out = jajap_service_defaults();
        if (!($db instanceof PDO)) return $out;
        try {
            $st = $db->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('service_bike_name','service_car_name','service_food_name','service_mart_name','service_send_name')");
            $st->execute();
            foreach ($st as $row) {
                if (isset($out[$row['setting_key']]) && trim((string)$row['setting_value']) !== '') {
                    $out[$row['setting_key']] = trim((string)$row['setting_value']);
                }
            }
        } catch (Throwable $e) {}
        return $out;
    }
}
if (!function_exists('jajap_service_name')) {
    function jajap_service_name(string $type, ?PDO $db = null): string {
        $map = ['bike'=>'service_bike_name','car'=>'service_car_name','food'=>'service_food_name','mart'=>'service_mart_name','send'=>'service_send_name'];
        $settings = jajap_services($db);
        $key = $map[$type] ?? 'service_food_name';
        return $settings[$key] ?? $key;
    }
}

<?php
$host = getenv('JAJAP_DB_HOST') ?: '127.0.0.1';
$user = getenv('JAJAP_DB_USER') ?: 'root';
$pass = getenv('JAJAP_DB_PASS') ?: '';
$db = getenv('JAJAP_DB_NAME') ?: 'jajap_db';
$charset = 'utf8mb4';

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

$pdo = null;

// User App dan Admin Panel wajib memakai database yang sama: jajap_db.
// Tidak ada fallback ke database lain agar data kedua aplikasi tidak terpisah.
try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (Throwable $e) {
    // Koneksi gagal dibuat non-fatal agar halaman publik/demo tetap dapat dimuat.
}

/* JAJAP ADD-ON: tabel kontrol admin, pendaftaran driver/kuliner, dan sinkronisasi pembayaran.
   Dibuat otomatis supaya instalasi lama tetap bisa memakai fitur baru tanpa menghapus data lama. */
if ($pdo instanceof PDO) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS driver_applications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL, phone VARCHAR(20) NOT NULL, email VARCHAR(100) DEFAULT NULL,
            password VARCHAR(255) NOT NULL, vehicle_type ENUM('bike','car') NOT NULL DEFAULT 'bike',
            vehicle_plate VARCHAR(30) DEFAULT NULL, status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS merchant_applications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL, phone VARCHAR(20) NOT NULL, address VARCHAR(255) DEFAULT NULL,
            category VARCHAR(80) DEFAULT 'Kuliner', status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        /* Pastikan tabel orders selalu ada sebelum proses checkout/ALTER TABLE.
           Database lama sebelumnya bisa tidak memiliki tabel ini sehingga checkout
           berhenti dengan "Base table or view not found". */
        $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            driver_id INT NULL,
            order_type ENUM('bike','car','food','mart') NOT NULL DEFAULT 'food',
            pickup_address TEXT,
            dropoff_address TEXT,
            total_price DECIMAL(12,2) NOT NULL DEFAULT 0,
            product_subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
            delivery_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
            driver_earning DECIMAL(12,2) NOT NULL DEFAULT 0,
            status ENUM('pending','accepted','delivering','completed','cancelled') NOT NULL DEFAULT 'pending',
            payment_method VARCHAR(20) DEFAULT 'qris',
            payment_status ENUM('pending','paid','failed','synced') NOT NULL DEFAULT 'pending',
            payment_reference VARCHAR(100) DEFAULT NULL,
            assigned_at TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_orders_user_id (user_id),
            INDEX idx_orders_driver_id (driver_id),
            INDEX idx_orders_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS payment_sync_logs (
            id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, action VARCHAR(40) NOT NULL DEFAULT 'sync',
            reference_code VARCHAR(100) DEFAULT NULL, synced_by INT DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX(order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        foreach ([
            "ALTER TABLE orders ADD COLUMN payment_status ENUM('pending','paid','failed','synced') NOT NULL DEFAULT 'pending' AFTER payment_method",
            "ALTER TABLE orders ADD COLUMN payment_reference VARCHAR(100) DEFAULT NULL AFTER payment_status",
            "ALTER TABLE orders ADD COLUMN assigned_at TIMESTAMP NULL DEFAULT NULL AFTER driver_id"
        ] as $sql) { try { $pdo->exec($sql); } catch (Throwable $ignore) {} }
        // Sumber tarif resmi dikelola JAJAP_Admin_Panel melalui system_settings.
        // Hanya membuat nilai yang belum ada; nilai yang sudah diubah Admin tidak pernah ditimpa.
        $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
            setting_key VARCHAR(80) PRIMARY KEY,
            setting_value VARCHAR(255) NOT NULL DEFAULT '',
            description VARCHAR(255) DEFAULT NULL,
            updated_by INT DEFAULT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        // Migrasi aman untuk instalasi lama yang masih memakai DECIMAL.
        try { $pdo->exec("ALTER TABLE system_settings MODIFY setting_value VARCHAR(255) NOT NULL DEFAULT ''"); } catch (Throwable $ignore) {}
        foreach ([
            ['service_bike_name','JAJAPBike','Nama layanan transportasi motor'],
            ['service_car_name','JAJAPCar','Nama layanan transportasi mobil'],
            ['service_food_name','Kuliner','Nama layanan makanan'],
            ['service_mart_name','Sembako','Nama layanan belanja'],
            ['service_send_name','JAJAPSend','Nama layanan kurir/pengantaran']
        ] as $svc) {
            try { $st=$pdo->prepare("INSERT IGNORE INTO system_settings(setting_key,setting_value,description) VALUES(?,?,?)"); $st->execute($svc); } catch (Throwable $ignore) {}
        }
                foreach ([
            ['send_delivery_fee','10000','Ongkir JAJAPSend yang ditentukan Admin'],
            ['send_driver_share_percent','50','Persentase ongkir JAJAPSend untuk driver yang ditentukan Admin']
        ] as $tariff) {
            try { $st=$pdo->prepare("INSERT IGNORE INTO system_settings(setting_key,setting_value,description) VALUES(?,?,?)"); $st->execute($tariff); } catch (Throwable $ignore) {}
        }
        try { $pdo->exec("ALTER TABLE orders ADD COLUMN driver_share_percent DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER driver_earning"); } catch (Throwable $ignore) {}
// Nilai tarif tidak di-seed dari kode runtime. Tarif awal/operasional
        // dikelola melalui database.sql dan selanjutnya hanya dapat diubah
        // melalui JAJAP_Admin_Panel.
        // Kompatibilitas instalasi lama: migrasikan ongkir lama hanya jika tarif baru belum bernilai.
        try {
            $old = $pdo->query("SELECT setting_value FROM admin_settings WHERE setting_key='delivery_fee' LIMIT 1")->fetchColumn();
            if ($old !== false) {
                $pdo->prepare("UPDATE system_settings SET setting_value=? WHERE setting_key='base_delivery_fee' AND setting_value=0")->execute([(float)$old]);
            }
        } catch (Throwable $ignore) {}
        foreach ([
            "ALTER TABLE orders ADD COLUMN product_subtotal DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER total_price",
            "ALTER TABLE orders ADD COLUMN delivery_fee DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER product_subtotal",
            "ALTER TABLE orders ADD COLUMN driver_earning DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER delivery_fee"
        ] as $sql) { try { $pdo->exec($sql); } catch (Throwable $ignore) {} }
        foreach ([
            "ALTER TABLE users ADD COLUMN vehicle_type ENUM('bike','car') DEFAULT NULL AFTER is_driver_active",
            "ALTER TABLE users ADD COLUMN vehicle_plate VARCHAR(30) DEFAULT NULL AFTER vehicle_type"
        ] as $sql) { try { $pdo->exec($sql); } catch (Throwable $ignore) {} }
    } catch (Throwable $ignore) {
        // Fitur tambahan tetap non-fatal bila database lama belum bisa diubah.
    }
}

// JAJAP platform upgrade: realtime dispatch, payment ledger, notifications and safety.
if ($pdo instanceof PDO) { require_once __DIR__.'/platform.php'; jajap_platform_bootstrap($pdo); }
?>

<?php
require_once __DIR__.'/pricing.php';

// JAJAP platform upgrade: realtime dispatch, payment ledger, notifications and safety.
if ($pdo instanceof PDO) { require_once __DIR__.'/platform.php'; jajap_platform_bootstrap($pdo); }
?>

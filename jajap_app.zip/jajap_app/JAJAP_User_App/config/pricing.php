<?php
/**
 * JAJAP central tariff source.
 * Semua angka bisnis dibaca dari system_settings yang dikelola Admin Panel.
 * Kode ini hanya menjalankan aturan yang sudah ditentukan Admin.
 */
if (!function_exists('jajap_settings')) {
    function jajap_settings(?PDO $db = null): array {
        global $pdo;
        $db = $db instanceof PDO ? $db : $pdo;
        $out = [
            'base_delivery_fee' => 0.0,
            'bike_per_km' => 0.0,
            'car_per_km' => 0.0,
            'merchant_commission_percent' => 0.0,
            'send_delivery_fee' => 0.0,
            'send_per_km' => 10000.0,
            'send_driver_share_percent' => 0.0,
        ];
        if (!($db instanceof PDO)) return $out;
        try {
            $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('base_delivery_fee','bike_per_km','car_per_km','merchant_commission_percent','send_delivery_fee','send_per_km','send_driver_share_percent')");
            foreach ($stmt as $row) {
                if (array_key_exists($row['setting_key'], $out)) {
                    $out[$row['setting_key']] = (float)$row['setting_value'];
                }
            }
        } catch (Throwable $e) {}
        return $out;
    }
}

if (!function_exists('jajap_setting')) {
    function jajap_setting(string $key, float $default = 0.0): float {
        $settings = jajap_settings();
        return array_key_exists($key, $settings) ? (float)$settings[$key] : $default;
    }
}

if (!function_exists('jajap_transport_fare')) {
    function jajap_transport_fare(PDO $db, string $type, float $distanceKm): float {
        $settings = jajap_settings($db);
        // Transportasi memakai satu rumus yang sama dengan Beranda: ongkos dasar
        // + (jarak layanan x tarif per KM). Jarak yang tampil di UI dibulatkan
        // ke 1 angka desimal, sehingga halaman Beranda, Bike, Car, dan checkout
        // menghasilkan angka yang sama. Tidak ada pembulatan per-KM tersembunyi.
        $distanceKm = round(max(0, $distanceKm), 1);
        $base = (float)$settings['base_delivery_fee'];
        $perKm = $type === 'car' ? (float)$settings['car_per_km'] : (float)$settings['bike_per_km'];
        return max(0, round($base + ($distanceKm * $perKm), 2));
    }
}

if (!function_exists('jajap_send_pricing')) {
    function jajap_send_pricing(PDO $db, float $distanceKm = 0.0, string $packageType = 'Kecil'): array {
        $settings = jajap_settings($db);
        $distanceKm = max(0, $distanceKm);
        $sendPerKm = max(0, (float)$settings['send_per_km']);
        // JAJAPSend memakai blok KM: 0,1 KM tetap dihitung 1 KM; 1,1 KM dihitung 2 KM.
        $billableKm = $distanceKm > 0 ? (int)ceil($distanceKm) : 0;
        // Biaya ukuran paket tetap: Kecil +Rp1.000, Sedang +Rp2.000, Besar +Rp3.000.
        $packageType = in_array($packageType, ['Kecil','Sedang','Besar'], true) ? $packageType : 'Kecil';
        $packageFee = ['Kecil'=>1000.0,'Sedang'=>2000.0,'Besar'=>3000.0][$packageType];
        $distanceFee = $billableKm * $sendPerKm;
        $fee = max(0, $distanceFee + ($billableKm > 0 ? $packageFee : 0));
        $sharePercent = min(100, max(0, (float)$settings['send_driver_share_percent']));
        $driver = round($fee * ($sharePercent / 100), 2);
        return [
            'delivery_fee' => $fee,
            'distance_fee' => $distanceFee,
            'package_fee' => $billableKm > 0 ? $packageFee : 0.0,
            'package_type' => $packageType,
            'billable_km' => $billableKm,
            'send_per_km' => $sendPerKm,
            'driver_share_percent' => $sharePercent,
            'driver_earning' => $driver,
            'platform_earning' => round($fee - $driver, 2),
            'distance_km' => $distanceKm,
        ];
    }
}

if (!function_exists('jajap_product_delivery_fee')) {
    function jajap_product_delivery_fee(?PDO $db = null): float {
        return jajap_settings($db)['base_delivery_fee'];
    }
}

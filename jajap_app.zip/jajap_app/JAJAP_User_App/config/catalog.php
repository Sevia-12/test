<?php
/** Dynamic product catalog. Admin product CRUD is the source of truth. */
if (!function_exists('jajap_catalog')) {
    function jajap_catalog(string $type, ?PDO $db = null): array {
        global $pdo;
        $db = $db instanceof PDO ? $db : $pdo;
        $type = $type === 'mart' ? 'mart' : 'food';
        $fallback = $type === 'mart' ? [
            ['id'=>201,'name'=>'Beras Premium Ramos 5 Kg','price'=>72000,'rating'=>4.9,'sold'=>'800+','icon'=>'🍚','desc'=>'Beras putih bersih, pulen alami, tanpa pengawet atau pemutih.','variants'=>['Kemasan 5 Kg','Kemasan 10 Kg']],
            ['id'=>202,'name'=>'Minyak Goreng Pouch 2 Liter','price'=>34000,'rating'=>4.8,'sold'=>'3.1rb+','icon'=>'🧴','desc'=>'Minyak kelapa sawit murni berkualitas.','variants'=>['Pouch 1 Liter','Pouch 2 Liter','Botol 2 Liter']],
            ['id'=>203,'name'=>'Gula Pasir Putih 1 Kg','price'=>17500,'rating'=>5.0,'sold'=>'1.5rb+','icon'=>'🍬','desc'=>'Gula murni tebu pilihan.','variants'=>['Bungkus 1 Kg','Bungkus 500g']],
            ['id'=>204,'name'=>'Telur Ayam Negeri 1 Kg','price'=>28000,'rating'=>4.7,'sold'=>'600+','icon'=>'🥚','desc'=>'Telur segar dari peternakan lokal.','variants'=>['Mika 1 Kg','Tray 1/2 Kg']],
        ] : [
            ['id'=>101,'name'=>'Ayam Geprek Sambal Korek','price'=>18000,'rating'=>4.8,'sold'=>'1.2rb+','icon'=>'🍗','desc'=>'Nasi hangat + ayam crispy dengan sambal korek.','variants'=>['Level 1 (Pedas Manis)','Level 2 (Pedas Sedang)','Level 3 (Pedas Banget)']],
            ['id'=>102,'name'=>'Nasi Goreng Spesial Telur','price'=>20000,'rating'=>4.9,'sold'=>'2.5rb+','icon'=>'🍚','desc'=>'Nasi goreng racikan khas dengan ayam dan telur.','variants'=>['Ori / Tidak Pedas','Sedang','Pedas Cabai Hijau']],
            ['id'=>103,'name'=>'Mie Ayam Bakso Urat','price'=>17000,'rating'=>4.7,'sold'=>'900+','icon'=>'🍜','desc'=>'Mie kenyal dengan topping ayam dan bakso.','variants'=>['Kuah Dipisah','Kuah Dicampur','Yamin Manis']],
            ['id'=>104,'name'=>'Es Teh Manis Jumbo','price'=>5000,'rating'=>5.0,'sold'=>'5rb+','icon'=>'🥤','desc'=>'Es teh segar dengan porsi jumbo.','variants'=>['Manis Normal','Less Sugar','Tanpa Es']],
        ];
        if (!($db instanceof PDO)) return $fallback;
        try {
            $st=$db->prepare("SELECT id,name,description,price,icon FROM products WHERE type=? AND active=1 ORDER BY id ASC");
            $st->execute([$type]);
            $rows=$st->fetchAll();
            if (!$rows) return $fallback;
            $out=[];
            foreach($rows as $r){
                $out[]=[
                    'id'=>(int)$r['id'],
                    'name'=>(string)$r['name'],
                    'price'=>(float)$r['price'],
                    'rating'=>null,
                    'sold'=>null,
                    'icon'=>($r['icon']!==null && $r['icon']!=='')?(string)$r['icon']:($type==='mart'?'🛍️':'🍽️'),
                    'desc'=>(string)($r['description']??''),
                    'variants'=>$type==='mart'?['Pilihan sesuai stok','Kemasan sesuai stok']:['Pilihan standar','Sesuai catatan pesanan'],
                ];
            }
            return $out;
        } catch(Throwable $e) { return $fallback; }
    }
}

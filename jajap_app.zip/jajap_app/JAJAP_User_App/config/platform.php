<?php
/** JAJAP platform layer: order dispatch, realtime locations, notifications, payments and safety.
 *  All functions are additive and fail-safe so existing screens continue to work.
 */
require_once __DIR__.'/security.php';

function jajap_platform_bootstrap(PDO $pdo): void {
    $tables = [
        "CREATE TABLE IF NOT EXISTS driver_locations (
            driver_id INT PRIMARY KEY, latitude DECIMAL(10,7) NOT NULL, longitude DECIMAL(10,7) NOT NULL,
            accuracy DECIMAL(8,2) DEFAULT NULL, heading DECIMAL(7,2) DEFAULT NULL, speed DECIMAL(8,2) DEFAULT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY(driver_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS notifications (
            id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, order_id INT NULL, type VARCHAR(40) NOT NULL DEFAULT 'general',
            title VARCHAR(160) NOT NULL, body TEXT NOT NULL, read_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_notifications_user(user_id,read_at,created_at), INDEX idx_notifications_order(order_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS payment_transactions (
            id BIGINT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, provider VARCHAR(40) NOT NULL DEFAULT 'sandbox',
            method VARCHAR(30) NOT NULL, reference_code VARCHAR(120) NOT NULL UNIQUE, amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            status ENUM('pending','paid','failed','refunded','expired') NOT NULL DEFAULT 'pending',
            expires_at DATETIME NULL, paid_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_payment_order(order_id), INDEX idx_payment_status(status), FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        "CREATE TABLE IF NOT EXISTS safety_incidents (
            id BIGINT AUTO_INCREMENT PRIMARY KEY, order_id INT NULL, user_id INT NOT NULL, driver_id INT NULL,
            type ENUM('sos','incident','share_trip','support') NOT NULL DEFAULT 'incident', message TEXT,
            status ENUM('open','acknowledged','resolved') NOT NULL DEFAULT 'open', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_safety_order(order_id), INDEX idx_safety_user(user_id), FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(driver_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    ];
    foreach ($tables as $sql) { try { $pdo->exec($sql); } catch (Throwable $e) {} }
    $alter = [
        "ALTER TABLE orders ADD COLUMN distance_km DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER dropoff_address",
        "ALTER TABLE orders ADD COLUMN pickup_lat DECIMAL(10,7) DEFAULT NULL AFTER distance_km",
        "ALTER TABLE orders ADD COLUMN pickup_lng DECIMAL(10,7) DEFAULT NULL AFTER pickup_lat",
        "ALTER TABLE orders ADD COLUMN dropoff_lat DECIMAL(10,7) DEFAULT NULL AFTER pickup_lng",
        "ALTER TABLE orders ADD COLUMN dropoff_lng DECIMAL(10,7) DEFAULT NULL AFTER dropoff_lat",
        "ALTER TABLE orders ADD COLUMN payment_provider VARCHAR(40) DEFAULT NULL AFTER payment_method",
        "ALTER TABLE orders ADD COLUMN payment_expires_at DATETIME DEFAULT NULL AFTER payment_reference",
        "ALTER TABLE orders ADD COLUMN last_status_at DATETIME DEFAULT NULL AFTER completed_at",
        "ALTER TABLE orders ADD COLUMN dispatch_attempts INT NOT NULL DEFAULT 0 AFTER assigned_at"
    ];
    foreach ($alter as $sql) { try { $pdo->exec($sql); } catch (Throwable $e) {} }
}

function jajap_platform_notify(PDO $pdo, int $userId, string $type, string $title, string $body, ?int $orderId=null): void {
    if ($userId <= 0) return;
    try { $st=$pdo->prepare('INSERT INTO notifications(user_id,order_id,type,title,body) VALUES(?,?,?,?,?)'); $st->execute([$userId,$orderId,$type,$title,$body]); } catch(Throwable $e) {}
}

function jajap_assign_driver(PDO $pdo, string $orderType, ?float $lat=null, ?float $lng=null): ?int {
    $vehicle = in_array($orderType,['bike','car'],true) ? $orderType : null;
    $sql = "SELECT u.id,
        (SELECT COUNT(*) FROM orders ao WHERE ao.driver_id=u.id AND ao.status IN ('accepted','delivering')) active_orders,
        (SELECT MAX(assigned_at) FROM orders lo WHERE lo.driver_id=u.id) last_assigned,
        dl.latitude,dl.longitude
        FROM users u LEFT JOIN driver_locations dl ON dl.driver_id=u.id
        WHERE u.role='driver' AND u.is_driver_active=1 AND u.is_blocked=0";
    $params=[];
    if ($vehicle) { $sql.=' AND u.vehicle_type=?'; $params[]=$vehicle; }
    $sql .= " HAVING active_orders < 3 ORDER BY active_orders ASC, last_assigned ASC";
    if ($lat !== null && $lng !== null) {
        // A bounded geographic score is calculated in SQL; load remains the first priority.
        $sql = "SELECT q.* FROM ($sql) q ORDER BY q.active_orders ASC,
            CASE WHEN q.latitude IS NULL OR q.longitude IS NULL THEN 999999
            ELSE (6371 * 2 * ASIN(SQRT(POWER(SIN(RADIANS(q.latitude-?)/2),2)+COS(RADIANS(?))*COS(RADIANS(q.latitude))*POWER(SIN(RADIANS(q.longitude-?)/2),2)))) END ASC,
            q.last_assigned ASC LIMIT 1";
        array_push($params,$lat,$lat,$lng);
    } else { $sql .= ' LIMIT 1'; }
    try { $st=$pdo->prepare($sql); $st->execute($params); $id=$st->fetchColumn(); return $id ? (int)$id : null; } catch(Throwable $e) { return null; }
}

function jajap_create_payment(PDO $pdo, int $orderId, string $method, float $amount): string {
    $ref='JJP-'.date('YmdHis').'-'.bin2hex(random_bytes(3));
    try {
        $st=$pdo->prepare("INSERT INTO payment_transactions(order_id,provider,method,reference_code,amount,status,expires_at) VALUES(?,?,?,?,?,'paid',DATE_ADD(NOW(),INTERVAL 15 MINUTE))");
        $st->execute([$orderId,'sandbox',$method,$ref,$amount]);
        $pdo->prepare("UPDATE orders SET payment_provider='sandbox',payment_status='paid',payment_reference=? WHERE id=?")->execute([$ref,$orderId]);
    } catch(Throwable $e) {}
    return $ref;
}

function jajap_order_status_notify(PDO $pdo, array $order, string $status): void {
    $map=[
        'pending'=>['Pesanan diterima','Pesanan sedang mencari driver yang tersedia.'],
        'accepted'=>['Driver ditemukan','Driver sudah menerima pesanan Anda.'],
        'delivering'=>['Perjalanan berlangsung','Driver sedang menuju tujuan Anda.'],
        'completed'=>['Pesanan selesai','Pesanan telah selesai. Terima kasih telah menggunakan JAJAP.'],
        'cancelled'=>['Pesanan dibatalkan','Pesanan Anda telah dibatalkan.']
    ];
    if(isset($map[$status])) jajap_platform_notify($pdo,(int)$order['user_id'],'order',$map[$status][0],$map[$status][1],(int)$order['id']);
}

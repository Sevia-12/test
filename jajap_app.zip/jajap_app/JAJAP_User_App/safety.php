<?php require_once __DIR__.'/config/database.php'; require_once __DIR__.'/config/platform.php'; require_customer(); $orderId=(int)($_GET['order_id']??$_POST['order_id']??0);$msg='';if($_SERVER['REQUEST_METHOD']==='POST'&&csrf_check($_POST['csrf']??'')){try{$type=$_POST['type']??'incident';$message=trim($_POST['message']??'');$driverId=null;if($orderId){$st=$pdo->prepare('SELECT driver_id FROM orders WHERE id=? AND user_id=?');$st->execute([$orderId,$_SESSION['user']['id']]);$driverId=$st->fetchColumn()?:null;}$st=$pdo->prepare('INSERT INTO safety_incidents(order_id,user_id,driver_id,type,message) VALUES(?,?,?,?,?)');$st->execute([$orderId?:null,$_SESSION['user']['id'],$driverId?:null,$type,$message]);$msg='Laporan keselamatan sudah tercatat.';}catch(Throwable $e){$msg='Laporan belum dapat disimpan.';}}?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pusat Keamanan — JAJAP</title><link rel="stylesheet" href="app-frame.css"><style>:root{--bg:#f4f6f5;--card:#fff;--ink:#1c2520;--muted:#6f7d76;--line:#e2ece7}body{margin:0;background:#d0d8d4;color:var(--ink);font-family:system-ui}.mobileContainer{max-width:100%;min-height:100vh;margin:auto;background:var(--bg)}.head{padding:14px 16px;background:var(--card);border-bottom:1px solid var(--line);display:flex;gap:12px}.head a{font-size:22px;text-decoration:none;color:var(--ink)}.content{padding:14px}.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:10px}label{font-size:11px;font-weight:800;display:block;margin-bottom:7px}textarea,select{width:100%;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--bg);color:var(--ink);box-sizing:border-box}.btn{width:100%;border:0;border-radius:12px;padding:13px;font-weight:900;color:#fff;background:#b4232f;margin-top:8px}.info{font-size:11px;line-height:1.5;color:var(--muted)}body.dark-mode{--bg:#121816;--card:#1e2623;--ink:#e8ecea;--muted:#a0b2aa;--line:#2d3834}</style><link rel="stylesheet" href="theme.css">
<link rel="stylesheet" href="layout.css"><script data-jajap-theme-bootstrap>(function(){var t=localStorage.getItem('jajap_theme');if(t==='dark')document.documentElement.classList.add('dark-mode');if(t==='light')document.documentElement.classList.add('light-mode');})();</script>
</head><body><div class="app-container"><div class="mobileContainer"><header class="head"><a href="<?= $orderId?'tracking.php?order_id='.$orderId:'index.php'?>">‹</a><b>🛡️ Pusat Keamanan</b></header><main class="content"><div class="card"><b>Jika Anda dalam bahaya</b><p class="info">Hubungi layanan darurat setempat terlebih dahulu. Tombol di bawah hanya mencatat laporan ke sistem JAJAP; bukan pengganti layanan darurat.</p><a href="tel:112" class="btn" style="display:block;text-align:center;text-decoration:none;box-sizing:border-box">📞 Hubungi 112</a></div><div class="card"><?php if($msg):?><div style="background:#e9f8f1;padding:10px;border-radius:10px;margin-bottom:10px;font-size:11px;font-weight:800;color:#08794f"><?=htmlspecialchars($msg)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="order_id" value="<?=$orderId?>"><label>Jenis laporan<select name="type"><option value="sos">SOS / keadaan darurat</option><option value="incident">Insiden</option><option value="support">Butuh bantuan</option><option value="share_trip">Permintaan bantuan perjalanan</option></select></label><label>Pesan<textarea name="message" rows="5" placeholder="Jelaskan masalah yang terjadi..."></textarea></label><button class="btn" type="submit">Kirim Laporan</button></form></div><div class="card"><b>Fitur keselamatan yang disiapkan</b><p class="info">Pelacakan perjalanan, laporan insiden, dan pencatatan kejadian sudah disiapkan sebagai fondasi. Integrasi SOS operator, masking nomor, dan partner asuransi perlu konfigurasi layanan eksternal sebelum produksi.</p></div></main></div><script>if(localStorage.getItem('jajap_theme')==='dark')document.body.classList.add('dark-mode');</script></div>
<script>
(function(){
  function fixLayout(){
    document.documentElement.style.setProperty('height','auto','important');
    document.documentElement.style.setProperty('min-height','100vh','important');
    document.documentElement.style.setProperty('overflow-y','auto','important');
    document.documentElement.style.setProperty('overflow-x','hidden','important');
    document.body.style.setProperty('height','auto','important');
    document.body.style.setProperty('min-height','100vh','important');
    document.body.style.setProperty('overflow-y','auto','important');
    document.body.style.setProperty('overflow-x','hidden','important');
    document.querySelectorAll('.app-container, .app-container > .mobileContainer, .app-container > .box, .app-container > .app, .app-container > .shell').forEach(function(el){
      el.style.setProperty('width','100%','important');
      el.style.setProperty('max-width','100%','important');
      el.style.setProperty('height','auto','important');
      el.style.setProperty('min-height','100vh','important');
      el.style.setProperty('overflow-x','hidden','important');
      el.style.setProperty('overflow-y','visible','important');
      el.style.setProperty('box-shadow','none','important');
      el.style.setProperty('border-radius','0','important');
    });
    document.querySelectorAll('.bottomNav, .rideBottomNav, .adminBottomNav').forEach(function(nav){
      nav.style.setProperty('position','fixed','important');
      nav.style.setProperty('left','0','important');
      nav.style.setProperty('right','0','important');
      nav.style.setProperty('bottom','0','important');
      nav.style.setProperty('top','auto','important');
      nav.style.setProperty('width','100%','important');
      nav.style.setProperty('max-width','none','important');
      nav.style.setProperty('transform','none','important');
      nav.style.setProperty('display','flex','important');
      nav.style.setProperty('justify-content','space-around','important');
      nav.style.setProperty('align-items','stretch','important');
      nav.style.setProperty('z-index','99999','important');
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fixLayout); else fixLayout();
  window.addEventListener('resize',fixLayout);
})();
</script>
</body></html>
